<?php
/*
Plugin Name: Newsy NSFW
Plugin URI: http://akbilisim.com
Description: NSFW (Not Safe For Work) Plugin for Newsy Theme
Version: 2.0.0
Author: akbilisim
Author URI: http://akbilisim.com
License: GPL2
*/

defined( 'NEWSY_NSFW' ) or define( 'NEWSY_NSFW', 'newsy-nsfw' );
defined( 'NEWSY_NSFW_VERSION' ) or define( 'NEWSY_NSFW_VERSION', '2.0.0' );
defined( 'NEWSY_NSFW_URI' ) or define( 'NEWSY_NSFW_URI', plugins_url( NEWSY_NSFW ) );
defined( 'NEWSY_NSFW_PATH' ) or define( 'NEWSY_NSFW_PATH', plugin_dir_path( __FILE__ ) );

/**
 * Newsy Social Share init.
 */
if ( ! function_exists( 'newsy_nsfw_load' ) ) {
	function newsy_nsfw_load() {
		require_once 'class.newsy-nsfw.php';
		Newsy_NSWF::get_instance();

		/**
		 * Load Text Domain
		 */
		load_plugin_textdomain( NEWSY_NSFW, false, basename( __DIR__ ) . '/languages/' );
	}
}

add_action( 'plugins_loaded', 'newsy_nsfw_load' );
