<?php
/**
 * @author akbilisim
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Newsy_NSWF {

	/**
	 * The Newsy NSWF object instance.
	 *
	 * @var Newsy_NSWF
	 */
	private static $instance;

	/**
	 * Contains plugin option panel ID
	 *
	 * @var string
	 */
	private $option_id = 'newsy-nsfw-options';

	public $nsfw_categories = array();

	/**
	 * @return Newsy_NSWF
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
			static::$instance->register_hooks();
		}

		return static::$instance;
	}

	/**
	 * Setup hooks.
	 *
	 * @return void
	 */
	private function register_hooks() {
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ), 999 );
		add_filter( 'ak-framework/product/pages', array( $this, 'register_product_pages' ), 11 );
		add_filter( 'ak-framework/register/translation', array( $this, 'register_translation_fields' ), 30 );
		add_filter( 'ak-framework/setup/after', array( $this, 'setup_hooks' ), 30 );
	}

	public function setup_hooks() {
		$this->nsfw_categories = explode( ',', $this->get_option( 'nsfw_categories' ) );
		if ( 'hide' === $this->get_option( 'enable_nsfw' ) || empty( $this->nsfw_categories ) ) {
			return;
		}

		add_filter( 'newsy_module_featured_after', array( $this, 'add_nsfw_module' ), 10, 6 );
		add_filter( 'newsy_single_featured_after', array( $this, 'add_nsfw_single' ), 10, 2 );
		add_filter( 'newsy_user_dropdown', array( $this, 'user_dropdown' ), 99, 1 );
	}

	public function add_nsfw_module( $output, $post, $image_size, $inline, $auto_wrap, $video ) {
		if ( empty( $output ) ) {
			return $output;
		}

		$show_button = false;

		if ( $video || $auto_wrap ) {
			$show_button = true;
		}

		return $this->add_nsfw_wrap( $output, $post, $show_button );
	}

	public function add_nsfw_single( $output, $post ) {
		if ( empty( $output ) || 'hide' === $this->get_option( 'nsfw_hide_on_single' ) ) {
			return $output;
		}

		return $this->add_nsfw_wrap( $output, $post, true );
	}

	public function add_nsfw_wrap( $output, $post, $show_button = false ) {
		$post = get_post( $post );

		if ( ! $post || ! has_category( $this->nsfw_categories, $post ) ) {
			return $output;
		}

		$icon     = ak_get_icon( $this->get_option( 'nsfw_icon', 'fa-shield' ) );
		$text     = ak_get_translation( 'Not Safe For Work', 'newsy-nsfw', 'nsfw' );
		$text_alt = ak_get_translation( 'Click to view this post', 'newsy-nsfw', 'nsfw_alt' );
		$button   = '';

		if ( $show_button && 'hide' !== $this->get_option( 'enable_nsfw_button' ) ) {
			$text_btn_text = ak_get_translation( 'View', 'newsy-nsfw', 'nsfw_btn_text' );
			$button        = '<button type="button" href="' . esc_url( get_permalink( $post ) ) . '" class="btn rounded ak-nsfw-view-button">' . $text_btn_text . '</button>';
		}

		$nsfw_output = sprintf(
			'<div class="ak-nsfw-inner">%s<div class="h4 ak-nsfw-title">%s</div><div class="ak-nsfw-desc">%s</div>%s</div>',
			$icon,
			esc_html( $text ),
			esc_html( $text_alt ),
			$button
		);

		if ( $show_button ) {
			$output .= "<div class=\"ak-nsfw\">{$nsfw_output}</div>";
		} else {
			$output .= sprintf(
				'<a href="%s" class="ak-nsfw">%s</a>',
				esc_url( get_permalink( $post ) ),
				$nsfw_output
			);
		}

		return $output;
	}

	public function user_dropdown( $dropdown ) {
		if ( 'hide' === $this->get_option( 'enable_nsfw_button' ) ) {
			return $dropdown;
		}

		$btn = '<label class="ak-toggle-container" for="nsfw-checkbox"><input id="nsfw-checkbox" class="ak-nsfw-toggle" type="checkbox"><span class="slider round"></span></label>';

		$dropdown['nswf'] = array(
			'text' => ak_get_translation( 'NSFW', 'newsy-nsfw', 'nsfw_menu_item' ) . $btn,
			'url'  => '#',
		);

		return $dropdown;
	}

	public function register_assets() {
		// styles
		wp_enqueue_style( 'newsy-nsfw', NEWSY_NSFW_URI . '/css/style.css', array(), NEWSY_NSFW_VERSION );
		// script
		wp_enqueue_script( 'newsy-nsfw', NEWSY_NSFW_URI . '/js/plugin.js', array( 'jquery' ), NEWSY_NSFW_VERSION, true );
	}

	public function register_product_pages( $pages ) {
		$pages[ NEWSY_NSFW ] = array(
			'product'    => 'newsy',
			'page_title' => __( 'NSFW Options', 'newsy-nsfw' ),
			'capability' => 'manage_options',
			'module'     => 'option-panel',
			'hide_tab'   => true,
			'global_css' => true,
			'position'   => 155,
			'config'     => array(
				'panel_title'   => __( 'NSFW Options', 'newsy-nsfw' ),
				'panel_options' => array(
					'option_id'   => $this->option_id,
					'file'        => NEWSY_NSFW_PATH . 'includes/panel.php',
					'panel_class' => 'ak-panel-menu-top ',
				),
			),
		);

		return $pages;
	}

	/**
	 * Register the Newsy NSFW translations to framework.
	 *
	 * @return array
	 */
	public function register_translation_fields( $fields ) {
		$fields[ NEWSY_NSFW ] = array(
			'name' => __( 'Newsy NSFW', 'newsy-nsfw' ),
			'file' => NEWSY_NSFW_PATH . 'includes/translation.php',
		);

		return $fields;
	}

	/**
	 * Used for retrieving options simply and safely for next versions
	 *
	 * @param $option_key
	 *
	 * @return mixed|null
	 */
	public function get_option( $option_key, $default_value = '' ) {
		if ( ! function_exists( 'ak_get_option' ) ) {
			return $default_value;
		}

		return ak_get_option( $this->option_id, $option_key, $default_value );
	}

	/**
	 * Used for accessing plugin directory URL
	 *
	 * @param string $address
	 *
	 * @return string
	 */
	public function dir_url( $address = '' ) {
		return NEWSY_NSFW_URI . $address;
	}

	/**
	 * Used for accessing plugin directory path
	 *
	 * @param string $address
	 *
	 * @return string
	 */
	public function dir_path( $address = '' ) {
		return NEWSY_NSFW_PATH . $address;
	}
}
