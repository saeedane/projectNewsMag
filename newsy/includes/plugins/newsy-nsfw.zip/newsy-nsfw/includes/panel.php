<?php
$fields[] = array(
	'heading' => esc_html__( 'Settings', 'newsy-nsfw' ),
	'id'      => 'settings',
	'type'    => 'section',
);

$fields[] = array(
	'id'          => 'enable_nsfw',
	'heading'     => esc_html__( 'Enable NSFW', 'newsy-nsfw' ),
	'description' => esc_html__( 'Enable this option to use NSFW (Not Safe For Work) feature.', 'newsy-nsfw' ),
	'type'        => 'switcher',
	'options'     => array(
		'off' => 'hide',
		'on'  => '',
	),
	'section'     => 'settings',
);
$fields[] = array(
	'id'          => 'nsfw_hide_on_single',
	'heading'     => esc_html__( 'Enable NSFW on Single Post', 'newsy-nsfw' ),
	'description' => esc_html__( 'Enable this option to use NSFW feature in Single Post. ıf disabled only block posts show NSFW box.', 'newsy-nsfw' ),
	'type'        => 'switcher',
	'options'     => array(
		'off' => 'hide',
		'on'  => '',
	),
	'section'     => 'settings',
);
$fields[] = array(
	'id'          => 'enable_nsfw_view_button',
	'heading'     => esc_html__( 'Enable NSFW View Button', 'newsy-nsfw' ),
	'description' => esc_html__( 'Enable this options to show View button when it possible. You can disable this option to use global toggle button only.', 'newsy-nsfw' ),
	'type'        => 'switcher',
	'options'     => array(
		'off' => 'hide',
		'on'  => '',
	),
	'section'     => 'settings',
);
$fields[] = array(
	'id'          => 'enable_nsfw_button',
	'heading'     => esc_html__( 'Enable NSFW Toggle Button', 'newsy-nsfw' ),
	'description' => esc_html__( 'Enable this options to use NSFW toggle button in member dropdown menu.', 'newsy-nsfw' ),
	'type'        => 'switcher',
	'options'     => array(
		'off' => 'hide',
		'on'  => '',
	),
	'section'     => 'settings',
);
$fields[] = array(
	'id'            => 'nsfw_categories',
	'type'          => 'ajax_select',
	'heading'       => esc_html__( 'NSFW Categories', 'newsy-nsfw' ),
	'description'   => esc_html__( 'Select a categories for NSFT posts.', 'newsy-nsfw' ),
	'max_items'     => 10,
	'ajax_callback' => 'Ak\Form\FormCallback::get_categories',
	'section'       => 'settings',
	'return_string' => true,
);


$fields[] = array(
	'heading' => esc_html__( 'Design', 'newsy-nsfw' ),
	'id'      => 'style',
	'type'    => 'section',
);

$fields[] = array(
	'id'      => 'nsfw_icon',
	'type'    => 'icon_select',
	'heading' => esc_html__( 'NSFW Icon', 'newsy-nsfw' ),
	'default' => 'fa-shield',
	'section' => 'style',
);

$fields[] = array(
	'id'      => 'nsfw_icon_size',
	'type'    => 'slider_unit',
	'heading' => esc_html__( 'NSFW Icon Size', 'newsy-nsfw' ),
	'min'     => 1,
	'max'     => 100,
	'step'    => 1,
	'units'   => array(
		'px',
		'em',
		'rem',
	),
	'output'  => array(
		array(
			'type'     => 'css',
			'element'  => '.ak-nsfw .ak-icon',
			'property' => 'font-size',
		),
	),
	'section' => 'style',
);

$fields[] = array(
	'id'      => 'nsfw_icon_color',
	'type'    => 'color',
	'heading' => esc_html__( 'NSFW Icon Color', 'newsy-nsfw' ),
	'section' => 'style',
	'output'  => array(
		array(
			'type'     => 'css',
			'element'  => '.ak-nsfw .ak-icon',
			'property' => 'color',
		),
	),
);
$fields[] = array(
	'id'      => 'nsfw_bg_color',
	'type'    => 'color',
	'heading' => esc_html__( 'NSFW Background Color', 'newsy-nsfw' ),
	'section' => 'style',
	'output'  => array(
		array(
			'type'     => 'css',
			'element'  => '.ak-nsfw',
			'property' => 'background-color',
		),
	),
);
$fields[] = array(
	'id'      => 'nsfw_view_btn_color',
	'type'    => 'color',
	'heading' => esc_html__( 'NSFW View Button Background Color', 'newsy-nsfw' ),
	'section' => 'style',
	'output'  => array(
		array(
			'type'     => 'css',
			'element'  => '.ak-nsfw-view-button, .ak-nsfw-view-button:hover',
			'property' => 'background-color',
		),
	),
);
$fields[] = array(
	'id'      => 'nsfw_view_btn_bg_color',
	'type'    => 'color',
	'heading' => esc_html__( 'NSFW View Button Text Color', 'newsy-nsfw' ),
	'section' => 'style',
	'output'  => array(
		array(
			'type'     => 'css',
			'element'  => '.ak-nsfw-view-button, .ak-nsfw-view-button:hover',
			'property' => 'color',
		),
	),
);
$fields[] = array(
	'id'      => 'nsfw_title_typo',
	'type'    => 'typography',
	'heading' => esc_html__( 'NSFW Title Typography', 'newsy-nsfw' ),
	'section' => 'style',
	'output'  => array(
		array(
			'type'     => 'css',
			'element'  => '.ak-nsfw-title',
			'property' => 'typography',
		),
	),
	'options' => array(
		'align' => false,
	),
);
$fields[] = array(
	'id'      => 'nsfw_desc_typo',
	'type'    => 'typography',
	'heading' => esc_html__( 'NSFW Description Typography', 'newsy-nsfw' ),
	'section' => 'style',
	'output'  => array(
		array(
			'type'     => 'css',
			'element'  => '.ak-nsfw-desc',
			'property' => 'typography',
		),
	),
	'options' => array(
		'align' => false,
	),
);
