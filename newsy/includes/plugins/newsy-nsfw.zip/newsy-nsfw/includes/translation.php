<?php

//NSFW

$fields[] = array(
	'heading' => 'NSFW',
	'id'      => 'nsfw_group_start',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);

$fields[] = array(
	'heading' => 'Not Safe For Work',
	'default' => 'Not Safe For Work',
	'id'      => 'nsfw',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Click to view this post',
	'default' => 'Click to view this post',
	'id'      => 'nsfw_alt',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'View',
	'default' => 'View',
	'id'      => 'nsfw_btn_text',
	'type'    => 'text',
	'section' => 'translation',
);


$fields[] = array(
	'heading'    => 'NSFW',
	'default'    => 'NSFW',
	'input_desc' => 'Used in the member dropdown',
	'id'         => 'nsfw_menu_item',
	'type'       => 'text',
	'section'    => 'translation',
);
