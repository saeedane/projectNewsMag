<?php

/**
 * Reaction Menu Walker
 */
class Newsy_Reaction_Menu_Walker extends Walker_Nav_Menu {

	/**
	 * Start the element output.
	 *
	 * @see Walker_Nav_Menu::start_el()
	 * @see Walker::start_el()
	 *
	 * @param string $output Passed by reference. Used to append additional content.
	 * @param object $item   Menu item data object.
	 * @param int    $depth  Depth of menu item. Used for padding.
	 * @param array  $args   An array of arguments. @see wp_nav_menu()
	 * @param int    $id     Current item ID.
	 */
	public function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {
		// item title as icon
		$item->title = newsy_reaction_get_reaction_icon( get_term( $item->object_id ), array( 'only_icon' => true ) );

		// continue with new args that changed
		$item_output = '';
		parent::start_el( $item_output, $item, $depth, $args, $id );

		$output .= $item_output;

	}
}
