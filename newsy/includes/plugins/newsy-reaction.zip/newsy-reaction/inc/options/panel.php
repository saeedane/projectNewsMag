<?php
$fields[] = array(
	'heading' => __( 'Settings', 'newsy-reaction' ),
	'id'      => 'settings',
	'type'    => 'section',
	'icon'    => 'fa-cog',
);

$fields[] = array(
	'id'               => 'reaction_vote_items',
	'type'             => 'visual_checkbox',
	'heading'          => __( 'Select Reactions', 'newsy-reaction' ),
	'description'      => __( 'You can select specific reaction badges and you can order them. By default all reactions will show up if you don\'t use this option.', 'newsy-reaction' ),
	'options_callback' => array(
		'function' => 'Ak\Form\FormCallback::get_categories',
		'args'     => array(
			array(
				'taxonomy' => 'reaction',
			),
		),
	),
	'input_desc'       => wp_kses(
		sprintf(
			__( '<a href="%s">Click here</a> to add/remove reactions.', 'newsy-reaction' ),
			admin_url( 'edit-tags.php?taxonomy=reaction' )
		), ak_trans_allowed_html()
	),
	'sorter'           => true,
	'section'          => 'settings',
);

$fields[] = array(
	'id'          => 'reaction_threshold',
	'type'        => 'slider',
	'heading'     => __( 'Reaction Badge Threshold', 'newsy-reaction' ),
	'description' => __( 'Assign reaction term to post if reached this threshold.', 'newsy-reaction' ),
	'default'     => '100',
	'min'         => 0,
	'max'         => 9999,
	'section'     => 'settings',
);

$fields[] = array(
	'id'      => 'guest_voting_is_enabled',
	'type'    => 'switcher',
	'heading' => esc_html__( 'Guest voting is enabled?', 'newsy-reaction' ),
	'options' => array(
		'on'  => '',
		'off' => 'off',
	),
	'section' => 'settings',
);

$fields[] = array(
	'id'      => 'reaction_box_style',
	'type'    => 'visual_select',
	'heading' => esc_html__( 'Reaction Box Style?', 'newsy-reaction' ),
	'options' => array(
		'style-1' => __( 'Style 1', 'newsy-reaction' ),
		'style-2' => __( 'Style 2', 'newsy-reaction' ),
	),
	'default' => 'style-1',
	'section' => 'settings',
);
$fields[] = array(
	'id'      => 'reaction_box_color',
	'type'    => 'color',
	'heading' => __( 'Reaction Box Accent Color', 'newsy-reaction' ),
	'section' => 'settings',
	'output'  => array(
		array(
			'type'     => 'css',
			'element'  => array(
				'.br-reaction-style-1 .br-reaction-bar',
				'.br-reaction-style-1.br-reaction-voted .br-reaction-bar',
				'.br-reaction-style-2 .br-reaction:hover .br-reaction-label',
				'.br-reaction-style-2 .br-reaction-voted .br-reaction-label',
				'.br-reaction-style-2 .br-reaction-bar',
				'.br-reaction-style-2.br-reaction-voted .br-reaction-bar',
			),
			'property' => 'background-color',
		),
		array(
			'type'     => 'css',
			'element'  => array(
				'.br-reaction-style-2 .br-reaction-label',
			),
			'property' => 'border-color',
		),
		array(
			'type'     => 'css',
			'element'  => array(
				'.br-reaction-style-2 .br-reaction-label',
			),
			'property' => 'color',
		),
	),
);
