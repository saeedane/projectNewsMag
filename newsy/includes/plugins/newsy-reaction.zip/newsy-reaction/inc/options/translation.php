<?php

/**
 * Block
 */
$fields[] = array(
	'heading' => 'Reaction',
	'id'      => 'reaction_group_start',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);

$fields[] = array(
	'heading' => 'Thanks for your vote!',
	'default' => 'Thanks for your vote!',
	'id'      => 'thanks_for_vote',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'You must login to vote!',
	'default' => 'You must login to vote!',
	'id'      => 'must_login_vote',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Failed to send request!',
	'default' => 'Failed to send request!',
	'id'      => 'failed_for_vote',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'myCred',
	'id'      => 'mycred_group_start',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => 'React to a post',
	'default' => 'React to a post',
	'id'      => 'react_to_post',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Awards for reactions.',
	'default' => 'Awards for reactions.',
	'id'      => 'awards_for_reactions',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Reacted to %post_title% with: %reaction%',
	'default' => 'Reacted to %post_title% with: %reaction%',
	'id'      => 'reaction_hook',
	'type'    => 'text',
	'section' => 'translation',
);
