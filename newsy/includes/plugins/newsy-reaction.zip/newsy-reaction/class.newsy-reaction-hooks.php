<?php
/**
 * @author akbilisim
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Newsy Reaction Hooks
 */
class Newsy_Reaction_Hooks {

	/**
	 * @var Newsy_Reaction_Hooks
	 */
	private static $instance;

	/**
	 * @return Newsy_Reaction_Hooks
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}
		return static::$instance;
	}

	/**
	 * Newsy_Reaction_Hooks constructor.
	 */
	private function __construct() {
		add_action( 'init', array( $this, 'register_taxonomy' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ), 999 );

		add_filter( 'ak-framework/product/pages', array( $this, 'register_product_pages' ), 11 );
		add_filter( 'ak-framework/shortcode', array( $this, 'register_shortcode' ), 11 );
		add_filter( 'ak-framework/menus', array( $this, 'register_menus' ) );
		add_action( 'ak-framework/frontend/ajax', array( $this, 'register_ajax' ) );
		add_filter( 'ak-framework/register/translation', array( $this, 'register_translation_fields' ), 35 );

		add_filter( 'newsy_post_badge_icons', array( $this, 'register_post_badge_icons' ), 13, 4 );

		add_filter( 'manage_edit-reaction_columns', array( $this, 'reaction_columns' ) );
		add_filter( 'manage_reaction_custom_column', array( $this, 'reaction_custom_column' ), 10, 3 );

		add_action( 'mycred_load_hooks', array( $this, 'mycred_load_hook' ), 65 );
		add_filter( 'mycred_setup_hooks', array( $this, 'mycred_register_hook' ), 65 );
		add_filter( 'mycred_all_references', array( $this, 'mycred_register_reference' ), 10, 1 );
	}

	/**
	 * Load plugin assest
	 */
	public function register_assets() {
		wp_enqueue_style( 'newsy-reaction', NEWSY_REACTION_URI . 'css/style.css', array(), NEWSY_REACTION_VERSION );
		wp_style_add_data( 'newsy-reaction', 'rtl', 'replace' );

		wp_enqueue_script( 'newsy-reaction', NEWSY_REACTION_URI . 'js/plugin.js', array( 'jquery' ), NEWSY_REACTION_VERSION, true );
	}

	public function register_taxonomy() {
		$labels = array(
			'name'              => _x( 'Reactions', 'taxonomy general name', 'newsy-reaction' ),
			'singular_name'     => _x( 'Reaction', 'taxonomy singular name', 'newsy-reaction' ),
			'search_items'      => __( 'Search Reactions', 'newsy-reaction' ),
			'all_items'         => __( 'All Reactions', 'newsy-reaction' ),
			'parent_item'       => __( 'Parent Reaction', 'newsy-reaction' ),
			'parent_item_colon' => __( 'Parent Reaction:', 'newsy-reaction' ),
			'edit_item'         => __( 'Edit Reaction', 'newsy-reaction' ),
			'update_item'       => __( 'Update Reaction', 'newsy-reaction' ),
			'add_new_item'      => __( 'Add New Reaction', 'newsy-reaction' ),
			'new_item_name'     => __( 'New Reaction Name', 'newsy-reaction' ),
			'menu_name'         => __( 'Reactions', 'newsy-reaction' ),
			'view_item'         => __( 'View Reaction', 'newsy-reaction' ),
			'not_found'         => __( 'No Reactions Found', 'newsy-reaction' ),
		);

		$args = array(
			'hierarchical'      => false,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'show_in_menu'      => true,
			'show_in_nav_menus' => true,
			'query_var'         => true,
			'orderby'           => 'slug',
			'rewrite'           => array(
				'slug'       => 'reaction',
				'with_front' => false,
			),

		);

		register_taxonomy( Newsy_Reaction::get_instance()->tax_name, array( 'post' ), $args );
	}

	public function register_product_pages( $pages ) {
		$pages['newsy-reaction'] = array(
			'product'    => 'newsy',
			'page_title' => __( 'Reaction Options', 'newsy-reaction' ),
			'capability' => 'manage_options',
			'module'     => 'option-panel',
			'hide_tab'   => true,
			'global_css' => true,
			'position'   => 153,
			'config'     => array(
				'panel_title'   => __( 'Reaction Options', 'newsy-reaction' ),
				'panel_options' => array(
					'file'        => NEWSY_REACTION_PATH . 'inc/options/panel.php',
					'panel_class' => 'ak-panel-menu-top ',
					'option_id'   => Newsy_Reaction::get_instance()->option_id,
				),
			),
		);

		return $pages;
	}

	public function register_shortcode( $shortcode ) {
		$shortcode['newsy_reaction_menu'] = array(
			'style'           => 'ak-block-reaction-menu',
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'name'            => 'Newsy Reaction Menu',
			'desc'            => 'Newsy Reaction Menu desc',
			'class'           => 'Newsy_Reaction_Menu_Shortcode',
			'file'            => NEWSY_REACTION_PATH . 'inc/class.newsy-reaction-menu-shortcode.php',
			'category'        => array( 'Newsy', 'Newsy Widgets' ),
			'icon'            => NEWSY_REACTION_URI . 'images/reaction-menu.png',
		);

		return $shortcode;
	}

	public function register_menus( $menus ) {
		$menus['badge-menu'] = __( 'Badge Navigation', 'newsy-reaction' );

		return $menus;
	}

	public function register_ajax( $action ) {
		if ( 'br_vote_post' === $action ) {
			Newsy_Reaction::get_instance()->ajax_vote();
		}
	}

	public function register_translation_fields( $fields ) {
		$fields['newsy-reaction'] = array(
			'name' => __( 'Newsy Reaction', 'newsy-reaction' ),
			'file' => NEWSY_REACTION_PATH . 'inc/options/translation.php',
		);

		return $fields;
	}

	public function register_post_badge_icons( $output, $post_id, $show_count, $show_both ) {
		if ( $show_both || empty( $output ) ) {
			$output .= Newsy_Reaction::get_instance()->get_most_reactions( $post_id, $show_count );
		}

		return $output;
	}

	public function reaction_columns( $columns ) {
		$columns['term_badge_icon'] = __( 'Icon', 'newsy-reaction' );

		return $columns;
	}

	/**
	 * Display custom columns content
	 *
	 * @param string $content           Column content.
	 * @param string $column_name       Column name.
	 * @param int    $term_id           Term id.
	 *
	 * @return string
	 */
	public function reaction_custom_column( $content, $column_name, $term_id ) {
		if ( 'term_badge_icon' === $column_name ) {
			$content = newsy_reaction_get_reaction_icon( get_term( $term_id ) );
		}

		return $content;
	}

	/**
	 * Add reference
	 *
	 * @param array $references References.
	 * @return array
	 */
	public function mycred_register_reference( $references ) {
		$references['newsy_reaction'] = ak_get_translation( 'React to a post', 'newsy-reaction', 'react_to_post' );
		return $references;
	}

	/**
	 * Register hook
	 *
	 * @param array $installed Installed hooks.
	 * @return array
	 */
	public function mycred_register_hook( $installed ) {
		$installed['newsy_reaction'] = array(
			'title'       => ak_get_translation( 'React to a post', 'newsy-reaction', 'react_to_post' ),
			'description' => ak_get_translation( 'Awards for reactions.', 'newsy-reaction', 'awards_for_reactions' ),
			'callback'    => array( 'Newsy_Reaction_myCRED_Hook' ),
		);

		return $installed;
	}

	/**
	 * Wyr Hook
	 */
	public function mycred_load_hook() {
		require_once NEWSY_REACTION_PATH . 'inc/class.newsy-reaction-mycred-hook.php';
	}
}
