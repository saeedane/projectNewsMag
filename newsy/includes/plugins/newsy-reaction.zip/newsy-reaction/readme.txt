Change Log :

== 1.7.0 ==
- [IMPROVEMENT] Theme compatibility

== 1.6.3 ==
- [NEW] Added frontend translations to theme panel
- [IMPROVEMENT] Theme compatibility
- [FIX] Issue on Guest voting

== 1.5.0 ==
- [IMPROVEMENT] Compatible with Newsy v1.5.0

== 1.0.5 ==
- [IMPROVEMENT] Theme compatibility
- [IMPROVEMENT] RTL version

== 1.0.2 ==
- [IMPROVEMENT] Dark Mode
- [IMPROVEMENT] Panel Options

== 1.0.2 ==
- [FIX] Issue on class names

== 1.0.1 ==
- [FIX] Issue on option panel

== 1.0.0 ==
- First Release
