<?php
namespace Ak\Customizer\Control;

/**
 * Switch control (modified checkbox).
 */
class Switcher extends ControlAbstract {

	/**
	 * The control type.
	 *
	 * @var string
	 */
	public $_type = 'switcher';
}
