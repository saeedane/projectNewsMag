<?php

namespace Ak\Customizer\Control;

/**
 * Create a simple number control.
 */
class IconSelect extends ControlAbstract {
	public $_type = 'icon_select';
}
