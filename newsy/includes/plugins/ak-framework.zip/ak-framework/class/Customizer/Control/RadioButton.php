<?php
namespace Ak\Customizer\Control;

/**
 * Radio Buttonset control (modified radio).
 */
class RadioButton extends ControlAbstract {
	public $_type = 'radio_button';
}
