Change Log :

== 1.7.2 ==
- [FIX] Minor Code & Style issues

== 1.7.1 ==
- [NEW] Newsticker Element
- [IMPROVEMENT] Video Player

== 1.7.0 ==
- [NEW] Slider 4 and Slider 5 Elements
- [IMPROVEMENT] Minor style & code changes

== 1.6.2 ==
- [FIX] Issue on block empty content spacing

== 1.6.1 ==
- [IMPROVEMENT] WordPress 5.9 compatibility

== 1.6.0 ==
- [NEW] Added review stars to module meta

== 1.5.1 ==
- [FIX] Issue on Module 8 without video breaks layout
- [FIX] Issue on Block Tabs sorting on custom order

== 1.5.0 ==
- [IMPROVEMENT] Compatible with Newsy v1.5.0

== 1.0.5 ==
- [IMPROVEMENT] Some minor style changes
- [IMPROVEMENT] Added module preview images to module fields
- [IMPROVEMENT] Added missed translations
- [FIX] Issue on Block tabs

== 1.0.3 ==
- [FIX] Block post count issue

== 1.0.2 ==
- [IMPROVEMENT] Some minor style changes
- [FIX] Issue on WPBakery Page Builder default values

== 1.0.1 ==
- [IMPROVEMENT] Some minor style changes

== 1.0.0 ==
- First Release
