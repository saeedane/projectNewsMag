<?php

if ( ! function_exists( 'newsy_get_post_primary_category' ) ) {
	/**
	 * Returns post main category object.
	 *
	 * @return mixed
	 */
	function newsy_get_post_primary_category( $post_id = null ) {
		if ( empty( $post_id ) ) {
			$post_id = get_the_ID();
		}

		$prim_cat = get_post_meta( $post_id, 'ak_post_primary_category', true );

		if ( 'auto-detect' === $prim_cat ) {
			// Primary category from Yoast SEO plugin
			if ( class_exists( 'WPSEO_Primary_Term' ) ) {
				$prim_cat = get_post_meta( $post_id, '_yoast_wpseo_primary_category', true );

				if ( $prim_cat ) {
					$prim_cat = get_category( $prim_cat );

					if ( ! is_wp_error( $prim_cat ) ) {
						return $prim_cat;
					}
				}
			}
		} elseif ( '' !== $prim_cat ) {
			$prim_cat = get_category( $prim_cat );

			if ( ! is_wp_error( $prim_cat ) ) {
				return $prim_cat;
			}
		}

		return current( get_the_category( $post_id ) ); // fallback -> first category
	}
}

if ( ! function_exists( 'newsy_get_post_categories' ) ) {
	/**
	 * Returns post categories.
	 *
	 * @return array
	 */
	function newsy_get_post_categories( $post_id, $category_limit = 1, $tax = 'category' ) {
		$is_category = 'category' === $tax;
		$cat_array   = array();
		if ( $is_category ) {
			$primary_category     = newsy_get_post_primary_category( $post_id );
			$primary_category_url = get_term_link( $primary_category, $tax );

			if ( ! is_wp_error( $primary_category_url ) ) {
				$cat_array[ $primary_category->name ] = array(
					'term_id'      => $primary_category->term_id,
					'link'         => $primary_category_url,
					'hide_on_post' => ak_get_term_meta( 'hide_badge_on_post', $primary_category->term_id ),
				);
			}
		}

		if ( $category_limit > 1 || empty( $cat_array ) ) {
			$categories = wp_get_post_terms( $post_id, $tax );

			if ( count( $categories ) > 0 ) {
				foreach ( $categories as $i => $category ) {
					if ( $i > $category_limit ) {
						break;
					}
					$category_url = get_term_link( $category, $tax );

					if ( ! is_wp_error( $category_url ) ) {
						$cat_array[ $category->name ] = array(
							'term_id'      => $category->term_id,
							'link'         => $category_url,
							'hide_on_post' => ak_get_term_meta( 'hide_badge_on_post', $category->term_id ),
						);
					}
				}
			}
		}

		return $cat_array;
	}
}

if ( ! function_exists( 'newsy_get_term_badge_icon' ) ) {
	/**
	 * Generate a badge icon from option.
	 *
	 * @param WP_Term $term.
	 * @param array $args.
	 *
	 * @return mixed
	 */
	function newsy_get_term_badge_icon( $term, $args = array() ) {

		$buffy = '';

		if ( ! is_wp_error( $term ) && gettype( $term ) == 'object' ) {
			$term_url        = get_term_link( $term, '' );
			$term_badge_type = get_term_meta( $term->term_id, 'ak_term_badge_type', true );

			if ( empty( $term_badge_type ) ) {
				return '';
			}

			$term_badge_icon = get_term_meta( $term->term_id, 'ak_term_badge_icon', true );
			$term_badge_text = get_term_meta( $term->term_id, 'ak_term_badge_text', true );

			$term_args = array(
				'only_icon'   => false,
				'url'         => $term_url,
				'icon'        => $term_badge_icon,
				'text'        => ! empty( $term_badge_text ) ? $term_badge_text : $term->name,
				'icon_width'  => 50,
				'icon_height' => 50,
			);

			$args = wp_parse_args( $args, $term_args );
			if ( ! $args['only_icon'] ) {
				$buffy .= '<a href="' . esc_url( $args['url'] ) . '" title="' . esc_attr( $args['text'] ) . '">';
			}

			$buffy .= '<span class="ak-badge-icon ak-badge-type-' . esc_attr( $term_badge_type ) . ' term-' . $term->term_id . '">';
			if ( 'text' === $term_badge_type ) {
				$buffy .= '<span class="ak-badge-icon-text">' . esc_html( $args['text'] ) . '</span>';
			} else {
				$buffy .= ak_get_icon( $args['icon'], 'ak-badge-icon-i', $args['text'] );
			}
			$buffy .= '</span>';

			if ( ! $args['only_icon'] ) {
				$buffy .= '</a>';
			}
		}

		return $buffy;
	}
}

if ( ! function_exists( 'newsy_module_edit_post_link' ) ) {
	/**
	 * Returns edit link for post
	 *
	 * @return string
	 */
	function newsy_module_edit_post_link( $post_id ) {
		if ( current_user_can( 'edit_posts' ) && current_user_can( 'edit_post', $post_id ) ) {
			$url = apply_filters( 'newsy_module_edit_btn_link', get_edit_post_link( $post_id ), $post_id );

			return "<a class=\"ak-edit-post-link\" href=\"{$url}\" target=\"_blank\">
                     <i class=\"fa fa-pencil\"></i>
                        <span>" . ak_get_translation( 'Edit', 'newsy-elements', 'edit_post' ) . '</span>
                    </a>';
		}

		return '';
	}
}

if ( ! function_exists( 'newsy_block_no_content' ) ) {
	/**
	 * Returns the no content block.
	 *
	 * @return string
	 */
	function newsy_block_no_content( $content = '' ) {
		if ( '' === $content ) {
			$content = ak_get_translation( 'No Content Available', 'newsy-elements', 'no_content' );
		}

		return '<div class="ak-no-posts">' . $content . '</div>';
	}
}

if ( ! function_exists( 'newsy_block_get_loader' ) ) {
	/**
	 * Returns the content loader.
	 *
	 * @return string
	 */
	function newsy_block_get_loader() {
		$loader_html = '<div class="clearfix ak-loading-wrap"><div class="ak-loading-circle"><div class="ak-loading-circle-inner"></div></div></div>';
		return apply_filters( 'newsy_block_loader_html', $loader_html );
	}
}

if ( ! function_exists( 'newsy_get_author_contact_methods' ) ) {
	/**
	 * Get the author social page providers.
	 *
	 * @return array
	 */
	function newsy_get_author_contact_methods() {
		return array(
			'facebook'       => 'Facebook',
			'twitter'        => 'Twitter',
			'instagram'      => 'Instagram',
			'youtube'        => 'Youtube',
			'vimeo'          => 'Vimeo',
			'pinterest'      => 'Pinterest',
			'reddit'         => 'ReddIt',
			'linkedin'       => 'Linkedin',
			'tumblr'         => 'Tumblr',
			'flickr'         => 'Flickr',
			'telegram'       => 'Telegram',
			'stumbleupon'    => 'StumbleUpon',
			'digg'           => 'Digg',
			'whatsapp'       => 'Whatsapp',
			'foursquare'     => 'Foursquare',
			'yahoo'          => 'Yahoo',
			'steam'          => 'Viber',
			'twitch'         => 'Twitch',
			'lastfm'         => 'Lastfm',
			'soundcloud'     => 'SoundCloud',
			'stack-overflow' => 'Stackoverflow',
			'behance'        => 'Behance',
			'dribbble'       => 'Dribbble',
			'vk'             => 'VK',
			'odnoklassniki'  => 'Odnoklassniki',
			'weibo'          => 'Weibo',
			'github'         => 'Github',
			'wordpress'      => 'Wordpress',
			'rss'            => 'Rss',
		);
	}
}
