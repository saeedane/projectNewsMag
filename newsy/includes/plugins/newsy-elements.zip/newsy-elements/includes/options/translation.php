<?php

/**
 * Block
 */
$fields[] = array(
	'heading' => 'Block',
	'id'      => 'block_group_start',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => 'All',
	'default' => 'All',
	'id'      => 'all',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Edit',
	'default' => 'Edit',
	'id'      => 'edit_post',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'No Content Available',
	'default' => 'No Content Available',
	'id'      => 'no_content',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Read More',
	'default' => 'Read More',
	'id'      => 'read_more',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'More',
	'default' => 'More',
	'id'      => 'pretty_tabs_more',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Latest',
	'default' => 'Latest',
	'id'      => 'latest',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Oldest',
	'default' => 'Oldest',
	'id'      => 'oldest',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Alphabet Asc',
	'default' => 'Alphabet Asc',
	'id'      => 'alphabet_asc',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Alphabet Desc',
	'default' => 'Alphabet Desc',
	'id'      => 'alphabet_desc',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Random',
	'default' => 'Random',
	'id'      => 'random',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Comments',
	'default' => 'Comments',
	'id'      => 'comments',
	'type'    => 'text',
	'section' => 'translation',
);

/**
 * Pagination
 */
$fields[] = array(
	'heading' => 'Pagination',
	'id'      => 'pagination_group_start',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => 'Next',
	'default' => 'Next',
	'id'      => 'pagination_next',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Prev',
	'default' => 'Prev',
	'id'      => 'pagination_prev',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Load More Posts',
	'default' => 'Load More Posts',
	'id'      => 'pagination_more_label',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => '%1$s of %2$s',
	'default' => '%1$s of %2$s',
	'id'      => 'pagination_pages_label',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Loading...',
	'default' => 'Loading...',
	'id'      => 'pagination_loading_label',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'No more posts.',
	'default' => 'No more posts.',
	'id'      => 'pagination_no_more',
	'type'    => 'text',
	'section' => 'translation',
);

/**
 * Newsletter Widgets
 */
$fields[] = array(
	'heading' => 'Newsletter Widget',
	'id'      => 'newsletter_group_start',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => 'Enter your email...',
	'default' => 'Enter your email...',
	'id'      => 'newsletter_email',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Subscribe',
	'default' => 'Subscribe',
	'id'      => 'newsletter_button',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'You can unsubscribe at any time',
	'default' => 'You can unsubscribe at any time',
	'id'      => 'newsletter_unsubcribe',
	'type'    => 'text',
	'section' => 'translation',
);

//Mixed
$fields[] = array(
	'heading' => 'Mixed',
	'id'      => 'mix_group_start',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => 'by %s',
	'default' => 'by %s',
	'id'      => 'by',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => '%s ago',
	'default' => '%s ago',
	'id'      => 'readable_time_ago',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Currently Playing',
	'default' => 'Currently Playing',
	'id'      => 'currently_playing',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Watch',
	'default' => 'Watch',
	'id'      => 'watch',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Follow Us',
	'default' => 'Follow Us',
	'id'      => 'fullow_instagram',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'BREAKING',
	'default' => 'BREAKING',
	'id'      => 'breaking',
	'type'    => 'text',
	'section' => 'translation',
);


