<?php

add_filter( 'ak-framework/shortcode', 'newsy_elements_register_shortcode' );

if ( ! function_exists( 'newsy_elements_register_shortcode' ) ) {
	/**
	 * Register the Newsy Shortcodes to framework.
	 *
	 * @return array
	 */
	function newsy_elements_register_shortcode( $shortcode ) {
		$shortcode['newsy_grid_1']              = array(
			'style'           => 'ak-block-grid ak-block-grid-1 ',
			'top_posts'       => true,
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'name'            => 'Newsy Grid 1',
			'class'           => 'NewsyElements\Shortcode\Grid\Grid_1',
			'category'        => array( 'Newsy', 'Newsy Grids' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/grids/style-1.png',
		);
		$shortcode['newsy_grid_2']              = array(
			'style'           => 'ak-block-grid ak-block-grid-2 ',
			'top_posts'       => true,
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'name'            => 'Newsy Grid 2',
			'class'           => 'NewsyElements\Shortcode\Grid\Grid_2',
			'category'        => array( 'Newsy', 'Newsy Grids' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/grids/style-2.png',
		);
		$shortcode['newsy_grid_3']              = array(
			'style'           => 'ak-block-grid ak-block-grid-3 ',
			'top_posts'       => true,
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'name'            => 'Newsy Grid 3',
			'class'           => 'NewsyElements\Shortcode\Grid\Grid_3',
			'category'        => array( 'Newsy', 'Newsy Grids' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/grids/style-3.png',
		);
		$shortcode['newsy_grid_4']              = array(
			'style'           => 'ak-block-grid ak-block-grid-4 ',
			'top_posts'       => true,
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'name'            => 'Newsy Grid 4',
			'class'           => 'NewsyElements\Shortcode\Grid\Grid_4',
			'category'        => array( 'Newsy', 'Newsy Grids' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/grids/style-4.png',
		);
		$shortcode['newsy_grid_5']              = array(
			'style'           => 'ak-block-grid ak-block-grid-5 ',
			'top_posts'       => true,
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'name'            => 'Newsy Grid 5',
			'class'           => 'NewsyElements\Shortcode\Grid\Grid_5',
			'category'        => array( 'Newsy', 'Newsy Grids' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/grids/style-5.png',
		);
		$shortcode['newsy_grid_6']              = array(
			'style'           => 'ak-block-grid ak-block-grid-6 ',
			'top_posts'       => true,
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'name'            => 'Newsy Grid 6',
			'class'           => 'NewsyElements\Shortcode\Grid\Grid_6',
			'category'        => array( 'Newsy', 'Newsy Grids' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/grids/style-6.png',
		);
		$shortcode['newsy_grid_7']              = array(
			'style'           => 'ak-block-grid ak-block-grid-7 ',
			'top_posts'       => true,
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'name'            => 'Newsy Grid 7',
			'class'           => 'NewsyElements\Shortcode\Grid\Grid_7',
			'category'        => array( 'Newsy', 'Newsy Grids' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/grids/style-7.png',
		);
		$shortcode['newsy_grid_8']              = array(
			'style'           => 'ak-block-grid ak-block-grid-8 ',
			'top_posts'       => true,
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'name'            => 'Newsy Grid 8',
			'class'           => 'NewsyElements\Shortcode\Grid\Grid_8',
			'category'        => array( 'Newsy', 'Newsy Grids' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/grids/style-8.png',
		);
		$shortcode['newsy_grid_9']              = array(
			'style'           => 'ak-block-grid ak-block-grid-9 ',
			'top_posts'       => true,
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'name'            => 'Newsy Grid 9',
			'class'           => 'NewsyElements\Shortcode\Grid\Grid_9',
			'category'        => array( 'Newsy', 'Newsy Grids' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/grids/style-9.png',
		);
		$shortcode['newsy_grid_10']             = array(
			'style'           => 'ak-block-grid ak-block-grid-10 ',
			'top_posts'       => true,
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'name'            => 'Newsy Grid 10',
			'class'           => 'NewsyElements\Shortcode\Grid\Grid_10',
			'category'        => array( 'Newsy', 'Newsy Grids' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/grids/style-10.png',
		);
		$shortcode['newsy_grid_11']             = array(
			'style'           => 'ak-block-grid ak-block-grid-11 ',
			'top_posts'       => true,
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'name'            => 'Newsy Grid 11',
			'class'           => 'NewsyElements\Shortcode\Grid\Grid_11',
			'category'        => array( 'Newsy', 'Newsy Grids' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/grids/style-11.png',
		);
		$shortcode['newsy_grid_12']             = array(
			'style'           => 'ak-block-grid ak-block-grid-12 ',
			'top_posts'       => true,
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'name'            => 'Newsy Grid 12',
			'class'           => 'NewsyElements\Shortcode\Grid\Grid_12',
			'category'        => array( 'Newsy', 'Newsy Grids' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/grids/style-12.png',
		);
		$shortcode['newsy_grid_13']             = array(
			'style'           => 'ak-block-grid ak-block-grid-13 ',
			'top_posts'       => true,
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'name'            => 'Newsy Grid 13',
			'class'           => 'NewsyElements\Shortcode\Grid\Grid_13',
			'category'        => array( 'Newsy', 'Newsy Grids' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/grids/style-13.png',
		);
		$shortcode['newsy_slider_1']            = array(
			'style'           => 'ak-slider-1',
			'top_posts'       => true,
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'name'            => 'Newsy Slider 1',
			'class'           => 'NewsyElements\Shortcode\Slider\Slider_1',
			'category'        => array( 'Newsy', 'Newsy Sliders' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/grids/slider-1.png',
		);
		$shortcode['newsy_slider_2']            = array(
			'style'           => 'ak-block-grid ak-slider-2',
			'top_posts'       => true,
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'name'            => 'Newsy Slider 2',
			'class'           => 'NewsyElements\Shortcode\Slider\Slider_2',
			'category'        => array( 'Newsy', 'Newsy Sliders' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/grids/slider-2.png',
		);
		$shortcode['newsy_slider_3']            = array(
			'style'           => 'ak-block-grid ak-slider-3',
			'top_posts'       => true,
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'name'            => 'Newsy Slider 3',
			'class'           => 'NewsyElements\Shortcode\Slider\Slider_3',
			'category'        => array( 'Newsy', 'Newsy Sliders' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/grids/slider-3.png',
		);
		$shortcode['newsy_slider_4']            = array(
			'style'           => 'ak-block-grid ak-slider-4',
			'top_posts'       => true,
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'name'            => 'Newsy Slider 4',
			'class'           => 'NewsyElements\Shortcode\Slider\Slider_4',
			'category'        => array( 'Newsy', 'Newsy Sliders' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/grids/slider-4.png',
		);
		$shortcode['newsy_slider_5']            = array(
			'style'           => 'ak-block-grid ak-slider-5',
			'top_posts'       => true,
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'name'            => 'Newsy Slider 5',
			'class'           => 'NewsyElements\Shortcode\Slider\Slider_5',
			'category'        => array( 'Newsy', 'Newsy Sliders' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/grids/slider-5.png',
		);
		$shortcode['newsy_list_1']              = array(
			'style'           => 'ak-block-list-1',
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'cat_loop'        => true,
			'name'            => 'Newsy List 1',
			'class'           => 'NewsyElements\Shortcode\Lists\List_1',
			'category'        => array( 'Newsy', 'Newsy Lists' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-1.png',
		);
		$shortcode['newsy_list_1_medium']       = array(
			'style'           => 'ak-block-list-1-medium',
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'cat_loop'        => true,
			'name'            => 'Newsy List 1 Medium',
			'class'           => 'NewsyElements\Shortcode\Lists\List_1_Medium',
			'category'        => array( 'Newsy', 'Newsy Lists' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-1-medium.png',
		);
		$shortcode['newsy_list_1_large']        = array(
			'style'           => 'ak-block-list-1-large',
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'cat_loop'        => true,
			'name'            => 'Newsy List 1 Large',
			'class'           => 'NewsyElements\Shortcode\Lists\List_1_Large',
			'category'        => array( 'Newsy', 'Newsy Lists' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-1-large.png',
		);
		$shortcode['newsy_list_1_small']        = array(
			'style'           => 'ak-block-list-1-small ak-block-column',
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'cat_loop'        => false,
			'name'            => 'Newsy List 1 Small',
			'class'           => 'NewsyElements\Shortcode\Lists\List_1_Small',
			'category'        => array( 'Newsy', 'Newsy Lists' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-1-small.png',
		);
		$shortcode['newsy_list_1_small_square'] = array(
			'style'           => 'ak-block-list-1-small-square ak-block-column',
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'cat_loop'        => false,
			'name'            => 'Newsy List 1 Small Square',
			'class'           => 'NewsyElements\Shortcode\Lists\List_1_Small_Square',
			'category'        => array( 'Newsy', 'Newsy Lists' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-1-small-square.png',
		);
		$shortcode['newsy_list_1_wide']         = array(
			'style'           => 'ak-block-list-1-wide',
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'cat_loop'        => true,
			'name'            => 'Newsy List 1 Wide',
			'class'           => 'NewsyElements\Shortcode\Lists\List_1_Wide',
			'category'        => array( 'Newsy', 'Newsy Lists' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-1-wide.png',
		);
		$shortcode['newsy_list_2']              = array(
			'style'           => 'ak-block-list-2 ak-block-column',
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'cat_loop'        => true,
			'name'            => 'Newsy List 2',
			'class'           => 'NewsyElements\Shortcode\Lists\List_2',
			'category'        => array( 'Newsy', 'Newsy Lists' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-2.png',
		);
		$shortcode['newsy_list_2_wide']         = array(
			'style'           => 'ak-block-list-2-wide ak-block-column',
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'cat_loop'        => true,
			'name'            => 'Newsy List 2 Wide',
			'class'           => 'NewsyElements\Shortcode\Lists\List_2_Wide',
			'category'        => array( 'Newsy', 'Newsy Lists' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-2-wide.png',
		);
		$shortcode['newsy_list_3']              = array(
			'style'           => 'ak-block-list-3 ak-block-column',
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'cat_loop'        => true,
			'name'            => 'Newsy List 3',
			'class'           => 'NewsyElements\Shortcode\Lists\List_3',
			'category'        => array( 'Newsy', 'Newsy Lists' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-3.png',
		);
		$shortcode['newsy_list_4']              = array(
			'style'           => 'ak-block-list-4 ak-block-column',
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'cat_loop'        => true,
			'name'            => 'Newsy List 4',
			'class'           => 'NewsyElements\Shortcode\Lists\List_4',
			'category'        => array( 'Newsy', 'Newsy Lists' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-4.png',
		);
		$shortcode['newsy_list_5']              = array(
			'style'           => 'ak-block-list-5',
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'cat_loop'        => true,
			'name'            => 'Newsy List 5',
			'class'           => 'NewsyElements\Shortcode\Lists\List_5',
			'category'        => array( 'Newsy', 'Newsy Lists' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-5.png',
		);
		$shortcode['newsy_list_6']              = array(
			'style'           => 'ak-block-list-6',
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'cat_loop'        => true,
			'name'            => 'Newsy List 6',
			'class'           => 'NewsyElements\Shortcode\Lists\List_6',
			'category'        => array( 'Newsy', 'Newsy Lists' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-6.png',
		);
		$shortcode['newsy_list_7']              = array(
			'style'           => 'ak-block-list-7',
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'cat_loop'        => true,
			'name'            => 'Newsy List 7',
			'class'           => 'NewsyElements\Shortcode\Lists\List_7',
			'category'        => array( 'Newsy', 'Newsy Lists' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-7.png',
		);
		$shortcode['newsy_list_8']              = array(
			'style'           => 'ak-block-list-8',
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'cat_loop'        => true,
			'name'            => 'Newsy List 8',
			'class'           => 'NewsyElements\Shortcode\Lists\List_8',
			'category'        => array( 'Newsy', 'Newsy Lists' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-8.png',
		);
		$shortcode['newsy_list_9']              = array(
			'style'           => 'ak-block-list-9',
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'cat_loop'        => true,
			'name'            => 'Newsy List 9',
			'class'           => 'NewsyElements\Shortcode\Lists\List_9',
			'category'        => array( 'Newsy', 'Newsy Lists' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-9.png',
		);
		$shortcode['newsy_list_10']             = array(
			'style'           => 'ak-block-list-10 ak-block-column',
			'cat_loop'        => true,
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'name'            => 'Newsy List 10',
			'class'           => 'NewsyElements\Shortcode\Lists\List_10',
			'category'        => array( 'Newsy', 'Newsy Lists' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-10.png',
		);
		$shortcode['newsy_list_11']             = array(
			'style'           => 'ak-block-list-11',
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'cat_loop'        => true,
			'name'            => 'Newsy List Mix 11',
			'class'           => 'NewsyElements\Shortcode\Lists\List_11',
			'category'        => array( 'Newsy', 'Newsy Lists' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-11.png',
		);
		$shortcode['newsy_list_12']             = array(
			'style'           => 'ak-block-list-12',
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'cat_loop'        => true,
			'name'            => 'Newsy List Mix 12',
			'class'           => 'NewsyElements\Shortcode\Lists\List_12',
			'category'        => array( 'Newsy', 'Newsy Lists' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-12.png',
		);
		$shortcode['newsy_list_13']             = array(
			'style'           => 'ak-block-list-13 ak-block-column',
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'cat_loop'        => true,
			'name'            => 'Newsy List Mix 13',
			'class'           => 'NewsyElements\Shortcode\Lists\List_13',
			'category'        => array( 'Newsy', 'Newsy Lists' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-13.png',
		);
		$shortcode['newsy_list_14']             = array(
			'style'           => 'ak-block-list-14',
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'cat_loop'        => true,
			'name'            => 'Newsy List 14',
			'class'           => 'NewsyElements\Shortcode\Lists\List_14',
			'category'        => array( 'Newsy', 'Newsy Lists' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/lists/list-14.png',
		);
		$shortcode['newsy_block_1']             = array(
			'style'           => 'ak-block-1 ak-block-column',
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'name'            => 'Newsy Block 1',
			'class'           => 'NewsyElements\Shortcode\Block\Block_1',
			'category'        => array( 'Newsy', 'Newsy Blocks' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/blocks/block-1.png',
		);
		$shortcode['newsy_block_2']             = array(
			'style'           => 'ak-block-2 ak-block-column',
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'name'            => 'Newsy Block 2',
			'class'           => 'NewsyElements\Shortcode\Block\Block_2',
			'category'        => array( 'Newsy', 'Newsy Blocks' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/blocks/block-2.png',
		);
		$shortcode['newsy_block_3']             = array(
			'style'           => 'ak-block-3  ak-block-column',
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'name'            => 'Newsy Block 3',
			'class'           => 'NewsyElements\Shortcode\Block\Block_3',
			'category'        => array( 'Newsy', 'Newsy Blocks' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/blocks/block-3.png',
		);
		$shortcode['newsy_block_4']             = array(
			'style'           => 'ak-block-4  ak-block-column',
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'name'            => 'Newsy Block 4',
			'class'           => 'NewsyElements\Shortcode\Block\Block_4',
			'category'        => array( 'Newsy', 'Newsy Blocks' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/blocks/block-4.png',
		);
		$shortcode['newsy_block_5']             = array(
			'style'           => 'ak-block-5',
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'name'            => 'Newsy Block 5',
			'class'           => 'NewsyElements\Shortcode\Block\Block_5',
			'category'        => array( 'Newsy', 'Newsy Blocks' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/blocks/block-5.png',
		);
		$shortcode['newsy_block_6']             = array(
			'style'           => 'ak-block-6 ak-block-column',
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'name'            => 'Newsy Block 6',
			'class'           => 'NewsyElements\Shortcode\Block\Block_6',
			'category'        => array( 'Newsy', 'Newsy Blocks' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/blocks/block-6.png',
		);
		$shortcode['newsy_block_7']             = array(
			'style'           => 'ak-block-7',
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'name'            => 'Newsy Block 7',
			'class'           => 'NewsyElements\Shortcode\Block\Block_7',
			'category'        => array( 'Newsy', 'Newsy Blocks' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/blocks/block-7.png',
		);
		$shortcode['newsy_block_8']             = array(
			'style'           => 'ak-block-8',
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'name'            => 'Newsy Block 8',
			'class'           => 'NewsyElements\Shortcode\Block\Block_8',
			'category'        => array( 'Newsy', 'Newsy Blocks' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/blocks/block-8.png',
		);
		$shortcode['newsy_block_9']             = array(
			'style'           => 'ak-block-9',
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'name'            => 'Newsy Block 9',
			'class'           => 'NewsyElements\Shortcode\Block\Block_9',
			'category'        => array( 'Newsy', 'Newsy Blocks' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/blocks/block-9.png',
		);
		$shortcode['newsy_block_10']            = array(
			'style'           => 'ak-block-10',
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'name'            => 'Newsy Block 10',
			'class'           => 'NewsyElements\Shortcode\Block\Block_10',
			'category'        => array( 'Newsy', 'Newsy Blocks' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/blocks/block-10.png',
		);
		$shortcode['newsy_block_11']            = array(
			'style'           => 'ak-block-11',
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'cat_loop'        => false,
			'name'            => 'Newsy Block 11',
			'class'           => 'NewsyElements\Shortcode\Block\Block_11',
			'category'        => array( 'Newsy', 'Newsy Blocks' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/blocks/block-11.png',
		);
		$shortcode['newsy_block_12']            = array(
			'style'           => 'ak-block-12 ak-block-column',
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'cat_loop'        => false,
			'name'            => 'Newsy Block 12',
			'class'           => 'NewsyElements\Shortcode\Block\Block_12',
			'category'        => array( 'Newsy', 'Newsy Blocks' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/blocks/block-12.png',
		);
		$shortcode['newsy_block_13']            = array(
			'style'           => 'ak-block-13 ak-block-column ak-masonry',
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'cat_loop'        => true,
			'name'            => 'Newsy Block 13',
			'class'           => 'NewsyElements\Shortcode\Block\Block_13',
			'category'        => array( 'Newsy', 'Newsy Blocks' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/blocks/block-13.png',
		);
		$shortcode['newsy_block_14']            = array(
			'style'           => 'ak-block-14 ak-block-column ak-masonry',
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'cat_loop'        => true,
			'name'            => 'Newsy Block 14',
			'class'           => 'NewsyElements\Shortcode\Block\Block_14',
			'category'        => array( 'Newsy', 'Newsy Blocks' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/blocks/block-14.png',
		);

		// widgets
		$shortcode['newsy_about_us']           = array(
			'style'           => 'ak-block-about-us',
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'name'            => 'Newsy About Us',
			'class'           => 'NewsyElements\Shortcode\Element\About_Us',
			'category'        => array( 'Newsy', 'Newsy Widgets' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/widgets/about-us.png',
		);
		$shortcode['newsy_author_box']         = array(
			'style'           => 'ak-block-author-box',
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'name'            => 'Newsy Author Box',
			'class'           => 'NewsyElements\Shortcode\Element\Author_Box',
			'category'        => array( 'Newsy', 'Newsy Widgets' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/widgets/author-box.png',
		);
		$shortcode['newsy_facebook_likebox']   = array(
			'style'           => 'ak-block-facvebook-like',
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'name'            => 'Newsy Facebook LikeBox',
			'class'           => 'NewsyElements\Shortcode\Element\Facebook_Likebox',
			'category'        => array( 'Newsy', 'Newsy Widgets' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/widgets/facebook.png',
		);
		$shortcode['newsy_instagram']          = array(
			'style'           => 'ak-block-instagram',
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'name'            => 'Newsy Instagram',
			'class'           => 'NewsyElements\Shortcode\Element\Instagram',
			'category'        => array( 'Newsy', 'Newsy Widgets' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/widgets/instagram.png',
		);
		$shortcode['newsy_mailchimp']          = array(
			'style'           => 'ak-block-mailchimp',
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'name'            => 'Newsy Mailchimp',
			'desc'            => 'Newsy Mailchimp Newsletter',
			'class'           => 'NewsyElements\Shortcode\Element\Mailchimp',
			'category'        => array( 'Newsy', 'Newsy Widgets' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/widgets/mailchimp.png',
		);
		$shortcode['newsy_popular_categories'] = array(
			'style'           => 'ak-block-categories',
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'name'            => 'Newsy Popular Categories',
			'class'           => 'NewsyElements\Shortcode\Element\Popular_Categories',
			'category'        => array( 'Newsy', 'Newsy Widgets' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/widgets/popular-categories.png',
		);
		$shortcode['newsy_video_playlist']     = array(
			'style'           => 'ak-block-video-playlist',
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'name'            => 'Newsy Video Playlist',
			'class'           => 'NewsyElements\Shortcode\Element\Video_Playlist',
			'category'        => array( 'Newsy', 'Newsy Widgets' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/widgets/video-playlist.png',
		);
		$shortcode['newsy_newsticker']         = array(
			'style'           => 'ak-block-newsticker',
			'have_map_for_vc' => true,
			'have_widget'     => false,
			'name'            => 'Newsy Newsticker',
			'class'           => 'NewsyElements\Shortcode\Element\Newsticker',
			'category'        => array( 'Newsy', 'Newsy Widgets' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/widgets/newsticker.png',
		);
		$shortcode['newsy_ad']                 = array(
			'style'           => 'ak-block-ads',
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'name'            => 'Newsy Ads',
			'class'           => 'NewsyElements\Shortcode\Element\Block_Ad',
			'category'        => array( 'Newsy', 'Newsy Widgets' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/widgets/ads.png',
		);
		$shortcode['newsy_block_header']       = array(
			'style'           => 'ak-block-custom-header',
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'name'            => 'Newsy Block Header',
			'class'           => 'NewsyElements\Shortcode\Element\Block_Header',
			'category'        => array( 'Newsy', 'Newsy Widgets' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/widgets/block-header.png',
		);
		$shortcode['newsy_nav_menu']           = array(
			'style'           => 'ak-block-nav-menu',
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'name'            => 'Newsy Navigation Menu',
			'class'           => 'NewsyElements\Shortcode\Element\Nav_Menu',
			'category'        => array( 'Newsy', 'Newsy Widgets' ),
			'icon'            => NEWSY_ELEMENTS_URI . '/assets/images/admin/options/widgets/nav-menu.png',
		);

		return $shortcode;
	}
}

add_action( 'ak-framework/frontend/ajax', 'newsy_elements_register_ajax' );

if ( ! function_exists( 'newsy_elements_register_ajax' ) ) {
	function newsy_elements_register_ajax( $action ) {
		switch ( $action ) {
			case 'ajax_block_pagination':
				NewsyElements\Ajax\BlockAjax::handle();
				break;
		}
	}
}

add_filter( 'ak-framework/register/translation', 'newsy_elements_register_translation_fields', 19 );

if ( ! function_exists( 'newsy_elements_register_translation_fields' ) ) {
	/**
	 * Register the Newsy translations to framework.
	 *
	 * @return array
	 */
	function newsy_elements_register_translation_fields( $fields ) {
		$fields['newsy-elements'] = array(
			'name' => __( 'Newsy Elements', 'newsy-elements' ),
			'file' => NEWSY_ELEMENTS_PATH . 'includes/options/translation.php',
		);

		return $fields;
	}
}
