<?php

namespace NewsyElements;

use NewsyElements\Plugin\VC;
use NewsyElements\Plugin\Elementor;
use NewsyElements\Support\InstagramFeedApi;

/**
 * Newsy Elements Init.
 */
class Init {

	/**
	 * @var Init
	 */
	private static $instance;

	/**
	 * @return Init
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
			static::$instance->init();
		}

		return static::$instance;
	}

	/**
	 * Fire up.
	 */
	private function init() {
		$this->register_textdomain();
		$this->register_includes();
		$this->register_hook();
	}

	/**
	 * Initialize language.
	 */
	public function register_textdomain() {
		load_plugin_textdomain( NEWSY_ELEMENTS, false, NEWSY_ELEMENTS_PATH . 'languages' );
	}

	/**
	 * Initialize setup hook.
	 */
	public function register_includes() {
		require NEWSY_ELEMENTS_PATH . 'includes/config.php';
		require NEWSY_ELEMENTS_PATH . 'includes/content.php';
		require NEWSY_ELEMENTS_PATH . 'includes/filter.php';
	}

	/**
	 * Initialize setup hook.
	 */
	public function register_hook() {
		add_action( 'ak-framework/setup/after', array( $this, 'setup' ) );
	}

	/**
	 * Setup.
	 */
	public function setup() {
		$this->admin();
		$this->hook();
		$this->plugins();
	}

	/**
	 * Initialize admin functionality.
	 */
	public function admin() {
		if ( is_admin() || function_exists( 'vc_is_inline' ) && vc_is_inline() || is_customize_preview() ) {
			require_once NEWSY_ELEMENTS_PATH . 'includes/admin.php';
		}

		InstagramFeedApi::get_instance();
	}

	/**
	 * Initialize hooks.
	 */
	public function hook() {
		// Enqueue assets (css, js)
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ), 99 );
	}

	/**
	 * Initialize plugins.
	 */
	public function plugins() {
		if ( defined( 'WPB_VC_VERSION' ) ) {
			VC::get_instance();
		}

		if ( defined( 'ELEMENTOR_VERSION' ) ) {
			Elementor::get_instance();
		}
	}

	/**
	 * Enqueue css and js files.
	 *
	 * Action Callback: wp_enqueue_scripts
	 */
	public function register_assets() {
		$asset_url = NEWSY_ELEMENTS_URI . '/assets/';

		// styles
		wp_enqueue_style( 'ak-anim' );
		wp_enqueue_style( 'fontawesome' );
		wp_enqueue_style( 'tiny-slider' );
		wp_enqueue_style( 'newsy-elements', $asset_url . 'css/style.css', array(), NEWSY_ELEMENTS_VERSION );
		wp_style_add_data( 'newsy-elements', 'rtl', 'replace' );

		// scripts
		wp_enqueue_script( 'ResizeSensor', $asset_url . 'js/ResizeSensor.js', null, NEWSY_ELEMENTS_VERSION, true );
		wp_enqueue_script( 'mousewheel', $asset_url . 'js/jquery.mousewheel.js', null, NEWSY_ELEMENTS_VERSION, true );
		wp_enqueue_script( 'jscrollpane', $asset_url . 'js/jquery.jscrollpane.js', null, NEWSY_ELEMENTS_VERSION, true );
		wp_enqueue_script( 'bgset', $asset_url . 'js/ls.bgset.js', null, NEWSY_ELEMENTS_VERSION, true );
		wp_enqueue_script( 'lazysizes', $asset_url . 'js/lazysizes.js', null, NEWSY_ELEMENTS_VERSION, true );
		wp_enqueue_script( 'imagesloaded', $asset_url . 'js/imagesloaded.pkgd.min.js', null, NEWSY_ELEMENTS_VERSION, true );
		wp_enqueue_script( 'masonary-layout', $asset_url . 'js/masonry.pkgd.js', null, NEWSY_ELEMENTS_VERSION, true );

		wp_enqueue_script( 'newsy-elements', $asset_url . 'js/plugin.js', array( 'ak-pagination', 'ak-slider' ), NEWSY_ELEMENTS_VERSION, true );
		wp_localize_script( 'newsy-elements', 'newsy_block_loc', $this->localize_script() );
	}

	/**
	 * Callback: delete cache and temp data after theme disabled
	 * action  : switch_theme.
	 */
	public function localize_script() {
		$localize = array(
			'rtl'         => is_rtl() ? 1 : 0,
			'loader_html' => newsy_block_get_loader(),
		);

		return apply_filters( 'newsy_block_loc', $localize );
	}
}
