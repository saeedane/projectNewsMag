<?php

namespace NewsyElements\Shortcode\Element;

use NewsyElements\Shortcode\BlockAbstract;

/**
 * Newsy Block Header Shortcode.
 */
class Block_Header extends BlockAbstract {

	public function __construct( $id, $params ) {
		parent::__construct( $id, $params );

		$this->defaults['title'] = 'Block Name';
	}

	/**
	 * Handle displaying of shortcode.
	 *
	 * @return string
	 */
	public function render_inner() {
		return '';
	}

	/**
	 * Visual Composer Fields Map for Shortcode.
	 */
	public function fields() {
		return array_merge(
			$this->block_header_options(),
			$this->block_design_options()
		);
	}

	public function block_design_item_margin_options() {
		return array();
	}
}
