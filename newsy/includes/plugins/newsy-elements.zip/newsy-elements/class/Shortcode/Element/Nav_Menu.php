<?php

namespace NewsyElements\Shortcode\Element;

use NewsyElements\Shortcode\BlockAbstract;

/**
 * Newsy Nav Menu Shortcode.
 */
class Nav_Menu extends BlockAbstract {


	public function __construct( $id, $params ) {

		$_defaults = array(
			'menu' => 'main-menu',
		);

		$this->defaults = array_merge( $this->defaults, $_defaults );

		parent::__construct( $id, $params );
	}

	/**
	 * Handle displaying of shortcode.
	 *
	 * @return string
	 */
	public function render_inner() {

		return ak_nav_menu(
			array(
				'menu' => $this->atts['menu'],
				'echo' => false,
			)
		);

	}

	/**
	 * Visual Composer Fields Map for Shortcode.
	 */
	public function fields() {
		return array_merge(
			array(
				array(
					'heading' => __( 'Select Menu', 'newsy-elements' ),
					'id'      => 'menu',
					'type'    => 'select',
					'options' => array(
						''                 => __( '-- Default Main Navigation --', 'newsy-elements' ),
						'options_callback' => 'Ak\Form\FormCallback::get_menus',
					),
					'section' => 'Menu',
				),
			),
			$this->block_header_options(),
			$this->block_design_options()
		);
	}

	public function block_design_item_margin_options() {
		return array();
	}
}
