<?php

namespace NewsyElements\Shortcode\Element;

use Ak\Shortcode\ShortcodeAbstract;

/**
 * Newsy Facebook LikeBox Shortcode.
 */
class Facebook_LikeBox extends ShortcodeAbstract {

	/**
	 * Flag used to determine print Facebook SDK in footer.
	 *
	 * @var bool
	 */
	public static $print_footer_sdk = false;

	public function __construct( $id, $params ) {

		$this->defaults = array(
			'title'      => '',
			'page'       => 'http://www.facebook.com/envato',
			'show_faces' => '',
			'show_posts' => '',
			'locate'     => 'en_US',
		);

		parent::__construct( $id, $params );

		add_action( 'wp_footer', array( $this, 'wp_footer' ) );
	}


	/**
	 * Callback: used to print Facebook SDK in footer.
	 *
	 * Action filter: wp_footer
	 */
	public static function wp_footer() {
		// print footer if needed
		if ( ! self::$print_footer_sdk ) {
			return;
		} ?>
		<div id="fb-root"></div>
		<script>
			(function(d, s, id) {
				var js, fjs = d.getElementsByTagName(s)[0];
				if (d.getElementById(id)) return;
				js = d.createElement(s);
				js.id = id;
				js.src = 'https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.11&appId=227007851136416';
				fjs.parentNode.insertBefore(js, fjs);
			}(document, 'script', 'facebook-jssdk'));
		</script>
		<?php
	}

	/**
	 * Handle displaying of shortcode
	 *
	 * @param array  $atts
	 * @param string $content
	 *
	 * @return string
	 */
	public function render( $atts, $content = '' ) {
		self::$print_footer_sdk = true;

		$buffy = '<div class="ak-block ak-block-facebook-likebox clearfix">';

		$show_faces = 'hide' !== $atts['show_faces'] ? 'true' : 'false';
		$show_posts = 'hide' !== $atts['show_posts'] ? 'true' : 'false';

		$buffy .= '<div class="fb-page"
                     data-href="' . esc_attr( $atts['page'] ) . '"
                     data-small-header="false"
                     data-adapt-container-width="true"
                     data-show-facepile="' . $show_faces . '"
                     data-locale="' . esc_attr( $atts['locate'] ) . '"
                     data-show-posts="' . $show_posts . '">
                    <div class="fb-xfbml-parse-ignore">
                    </div>
                </div><!-- .fb-page -->';

		$buffy .= '</div>';

		unset( $atts );

		return $buffy;
	}

	public function fields() {
		return array(
			array(
				'type'        => 'text',
				'admin_label' => false,
				'heading'     => __( 'Title', 'newsy-elements' ),
				'id'          => 'title',
				'section'     => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'type'        => 'text',
				'admin_label' => true,
				'heading'     => __( 'Facebook Page', 'newsy-elements' ),
				'description' => 'ex. http://www.facebook.com/envato',
				'id'          => 'page',
				'section'     => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'heading' => __( 'Show Posts', 'newsy-elements' ),
				'id'      => 'show_posts',
				'type'    => 'switcher',
				'options' => array(
					'off' => 'hide',
					'on'  => '',
				),
				'section' => __( 'Settings', 'newsy-elements' ),
			),
			array(

				'heading' => __( 'Show Faces', 'newsy-elements' ),
				'id'      => 'show_faces',
				'type'    => 'switcher',
				'options' => array(
					'off' => 'hide',
					'on'  => '',
				),
				'section' => __( 'Settings', 'newsy-elements' ),
			),

			array(
				'type'             => 'select',
				'heading'          => __( 'Language', 'newsy-elements' ),
				'id'               => 'locate',
				'options_callback' => 'ak_language_locates',
				'section'          => __( 'Settings', 'newsy-elements' ),
			),
		);
	}
}
