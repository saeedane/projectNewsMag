<?php

namespace NewsyElements\Shortcode\Element;

use NewsyElements\Shortcode\BlockAbstract;

/**
 * Newsy Newsticker.
 */
class Newsticker extends BlockAbstract {
	public function __construct( $id, $params ) {
		parent::__construct( $id, $params );

		$this->defaults['title']                   = ak_get_translation( 'BREAKING', 'newsy-elements', 'breaking' );
		$this->defaults['icon']                    = 'fa-bolt';
		$this->defaults['header_style']            = 'style-8';
		$this->defaults['pagination']              = 'slider';
		$this->defaults['slider_autoplay']         = 'enabled';
		$this->defaults['slider_autoplay_timeout'] = '3000';
		$this->defaults['slider_autoplay_speed']   = '1000';
		$this->defaults['slider_speed']            = '250';
		$this->defaults['slider_count']            = '10';
		$this->defaults['slide_count_desktop']     = '1';
		$this->defaults['slide_count_notebook']    = '1';
		$this->defaults['slide_count_tablet']      = '1';
		$this->defaults['slider_axis']             = 'vertical';
		$this->defaults['slider_nav']              = 'enabled';
		$this->defaults['slider_loop']             = 'enabled';
		$this->defaults['show_no_result']          = false;
	}

	public function prepare_inner_atts() {
		$this->atts['count'] = intval( $this->atts['slider_count'] );
	}

	/**
	 * Display the inner content of block.
	 */
	public function inner( &$atts, $query_posts ) {
		$buffy = '';
		foreach ( $query_posts as $post ) {
			$post_time = sprintf( ak_get_translation( '%s ago', 'newsy-elements', 'readable_time_ago' ), ak_ago_time( get_the_time( 'U', $post ) ) );

			$buffy .= '<div class="ak-newsticker-item">
					<span>
						<a href="' . get_the_permalink( $post ) . '" >' . get_the_title( $post ) . '</a>
					</span>
					<span class="newsticker-date">
						' . $post_time . '
					</span>
				</div>';
		}

		return $buffy;
	}

	public function block_inner_options() {
		return array_merge(
			array(
				array(
					'type'    => 'number',
					'heading' => __( 'Number of slides (Default 3)', 'newsy-elements' ),
					'id'      => 'slider_count',
					'section' => __( 'Slider', 'newsy-elements' ),
				),
				array(
					'id'      => 'slider_speed',
					'type'    => 'number',
					'heading' => __( 'Slider Slide duration (Default 250)', 'newsy-elements' ),
					'section' => __( 'Slider', 'newsy-elements' ),
				),
				array(
					'id'      => 'slider_autoplay',
					'type'    => 'switcher',
					'heading' => __( 'AutoPlay', 'newsy-elements' ),
					'section' => __( 'Slider', 'newsy-elements' ),
					'options' => array(
						'on'  => 'enabled',
						'off' => 'disabled',
					),
				),
				array(
					'id'         => 'slider_autoplay_timeout',
					'type'       => 'number',
					'heading'    => __( 'AutoPlay Speed  (Default 3000)', 'newsy-elements' ),
					'section'    => __( 'Slider', 'newsy-elements' ),
					'dependency' => array(
						'element' => 'slider_autoplay',
						'value'   => array( 'enabled' ),
					),
				),
				array(
					'id'         => 'slider_autoplay_speed',
					'type'       => 'number',
					'heading'    => __( 'AutoPlay Animation Speed  (Default 1000)', 'newsy-elements' ),
					'section'    => __( 'Slider', 'newsy-elements' ),
					'dependency' => array(
						'element' => 'slider_autoplay',
						'value'   => array( 'enabled' ),
					),
				),
				array(
					'id'      => 'slider_nav',
					'type'    => 'switcher',
					'heading' => __( 'Slider Nav', 'newsy-elements' ),
					'section' => __( 'Slider', 'newsy-elements' ),
					'options' => array(
						'on'  => 'enabled',
						'off' => 'disabled',
					),
				),
				array(
					'id'      => 'slider_loop',
					'type'    => 'switcher',
					'heading' => __( 'Loop Items', 'newsy-elements' ),
					'section' => __( 'Slider', 'newsy-elements' ),
					'options' => array(
						'on'  => 'enabled',
						'off' => '',
					),
				),
				array(
					'id'      => 'slider_axis',
					'type'    => 'visual_select',
					'heading' => __( 'Slider Axis', 'newsy-elements' ),
					'section' => __( 'Slider', 'newsy-elements' ),
					'options' => array(
						'vertical'   => __( 'Vertical', 'newsy-elements' ),
						'horizontal' => __( 'Horizontal', 'newsy-elements' ),
					),
				),
			)
		);
	}

	public function block_header_options() {
		return array(
			array(
				'type'        => 'text',
				'admin_label' => true,
				'heading'     => __( 'Block Title', 'newsy-elements' ),
				'id'          => 'title',
				'section'     => __( 'Header', 'newsy-elements' ),
			),
			array(
				'type'        => 'text',
				'admin_label' => false,
				'heading'     => __( 'Block Title Url', 'newsy-elements' ),
				'id'          => 'title_url',
				'section'     => __( 'Header', 'newsy-elements' ),
				'dependency'  => array(
					'element'   => 'title',
					'not_empty' => true,
				),
			),
			array(
				'type'        => 'slider_unit',
				'admin_label' => false,
				'heading'     => __( 'Block Title Font Size', 'newsy-elements' ),
				'id'          => 'title_size',
				'unit'        => 'px',
				'max'         => 100,
				'section'     => __( 'Header', 'newsy-elements' ),
				'dependency'  => array(
					'element'   => 'title',
					'not_empty' => true,
				),
			),
			array(
				'type'        => 'slider_unit',
				'admin_label' => false,
				'heading'     => __( 'Block Title Line Height', 'newsy-elements' ),
				'id'          => 'title_line_height',
				'unit'        => 'px',
				'max'         => 100,
				'section'     => __( 'Header', 'newsy-elements' ),
				'dependency'  => array(
					'element'   => 'title',
					'not_empty' => true,
				),
			),
			array(
				'type'        => 'icon_select',
				'heading'     => __( 'Block Icon (Optional)', 'newsy-elements' ),
				'id'          => 'icon',
				'admin_label' => false,
				'description' => __( 'Select custom icon for listing.', 'newsy-elements' ),
				'section'     => __( 'Header', 'newsy-elements' ),
			),
			array(
				'type'    => 'color',
				'heading' => __( 'Header Title Background Color', 'newsy-elements' ),
				'id'      => 'header_title_bg_color',
				'section' => __( 'Header', 'newsy-elements' ),
			),
			array(
				'type'    => 'color',
				'heading' => __( 'Header Title Color', 'newsy-elements' ),
				'id'      => 'header_title_color',
				'section' => __( 'Header', 'newsy-elements' ),
			),
			array(
				'type'       => 'color',
				'heading'    => __( 'Header Icon Color', 'newsy-elements' ),
				'id'         => 'header_icon_color',
				'section'    => __( 'Header', 'newsy-elements' ),
				'dependency' => array(
					'element'   => 'icon',
					'not_empty' => true,
				),
			),
			array(
				'type'        => 'color',
				'heading'     => __( 'Block Accent Color', 'newsy-elements' ),
				'description' => __( 'Block Elements Color', 'newsy-elements' ),
				'id'          => 'block_accent_color',
				'section'     => __( 'Header', 'newsy-elements' ),
			),
		);
	}

	public function block_pagination_options() {
		return array();
	}

	public function block_tab_options() {
		return array();
	}

	public function block_post_number_options() {
		return array();
	}

	public function block_design_options_numeric_content() {
		return array();
	}

	public function block_design_item_margin_options() {
		return array();
	}
}
