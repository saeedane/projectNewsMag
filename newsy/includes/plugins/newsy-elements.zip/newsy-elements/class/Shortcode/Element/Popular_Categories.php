<?php

namespace NewsyElements\Shortcode\Element;

use NewsyElements\Shortcode\BlockAbstract;

/**
 * Newsy Popular Categories Shortcode.
 */
class Popular_Categories extends BlockAbstract {

	public function __construct( $id, $params ) {

		$_defaults = array(
			'show-post-count' => '',
			'show-empty'      => '',
			'count'           => 10,
			'order_by'        => 'count',
			'order'           => 'DESC',
			'include'         => '',
			'exclude'         => '',
		);

		$this->defaults = array_merge( $this->defaults, $_defaults );

		parent::__construct( $id, $params );
	}

	public function render_inner() {
		$show_counts = 'hide' != $this->atts['show-post-count'];
		$hide_empty  = 'no' === $this->atts['show-empty'];

		$column_classes = '';
		if ( ! empty( $this->atts['block_width'] ) && 1 < $this->atts['block_width'] ) {
			$column_classes .= esc_attr( ' columns-' . $this->atts['block_width'] );
		}

		$args = array(
			'orderby'    => $this->atts['order_by'],
			'show_count' => $show_counts,
			'hide_empty' => $hide_empty,
			'order'      => $this->atts['order'],
			'number'     => $this->atts['count'],
		);

		if ( ! empty( $this->atts['exclude'] ) ) {
			if ( is_array( $this->atts['exclude'] ) ) {
				$this->atts['exclude'][] = 1;
				$args['exclude']         = implode( ',', $this->atts['exclude'] ); // Exclude uncategorized
			} else {
				$args['exclude'] = rtrim( '1,' . $this->atts['exclude'], ',' ); // Exclude uncategorized
			}
		} else {
			$args['exclude'] = 1; // Exclude uncategorized
		}

		$categories = get_categories( $args );
		$buffy      = '';

		if ( ! empty( $categories ) ) {
			$buffy .= '<ul class="popular-cats-list ' . $column_classes . '">';
			foreach ( $categories as $term ) {
				$buffy .= '<li class="popular-cat-item term-' . esc_attr( $term->term_id ) . '">';
				$buffy .= '<a class="link" href="' . esc_url( get_category_link( $term->term_id ) ) . '">';
				$buffy .= $term->name;
				if ( $show_counts ) {
					$buffy .= '<span class="term-count">' . $term->count . '</span>';
				}
				$buffy .= '</a>';
				$buffy .= '</li>';
			}
			$buffy .= '</ul>';
		}

		unset( $categories );

		return $buffy;
	}

	/**
	 * Visual Composer Fields Map for Shortcode.
	 */
	public function fields() {
		return array_merge(
			$this->block_inner_options(),
			$this->block_header_options(),
			$this->block_design_options()
		);
	}

	/**
	 * Registers Visual Composer Add-on.
	 */
	public function block_inner_options() {
		return array(
			array(
				'type'        => 'number',
				'admin_label' => false,
				'heading'     => __( 'Count', 'newsy-elements' ),
				'id'          => 'count',
				'section'     => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'type'        => 'select',
				'heading'     => __( 'Order By', 'newsy-elements' ),
				'id'          => 'order_by',
				'admin_label' => false,
				'options'     => array(
					'count' => __( 'Total Posts Count', 'newsy-elements' ),
					'name'  => __( 'Name', 'newsy-elements' ),
					'rand'  => __( 'Random', 'newsy-elements' ),
				),
				'section'     => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'type'        => 'select',
				'heading'     => __( 'Order', 'newsy-elements' ),
				'id'          => 'order',
				'admin_label' => false,
				'options'     => array(
					'DESC' => __( 'Latest First (DESC)', 'newsy-elements' ),
					'ASC'  => __( 'Oldest First (ASC)', 'newsy-elements' ),
				),
				'section'     => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'type'        => 'select',
				'heading'     => __( 'Columns', 'newsy-elements' ),
				'id'          => 'block_width',
				'admin_label' => true,
				'options'     => array(
					''  => __( 'No Column', 'newsy-elements' ),
					'2' => __( '2 Columns', 'newsy-elements' ),
					'3' => __( '3 Columns', 'newsy-elements' ),
				),
				'section'     => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'type'        => 'switcher',
				'heading'     => __( 'Show Category Post Count', 'newsy-elements' ),
				'id'          => 'show-post-count',
				'admin_label' => false,
				'options'     => array(
					'on'  => '',
					'off' => 'hide',
				),
				'section'     => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'type'        => 'switcher',
				'heading'     => __( 'Show Empty Categories', 'newsy-elements' ),
				'id'          => 'show-empty',
				'admin_label' => false,
				'options'     => array(
					'on'  => '',
					'off' => 'hide',
				),
				'section'     => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'type'             => 'select',
				'admin_label'      => false,
				'heading'          => __( 'Include Categories', 'newsy-elements' ),
				'input_desc'       => __( 'Hold Command in Mac or CTRL in Windows to select multiple categories.', 'newsy-elements' ),
				'id'               => 'include',
				'multiple'         => 500,
				'options_callback' => 'Ak\Form\FormCallback::get_categories',
				'section'          => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'type'             => 'select',
				'admin_label'      => false,
				'heading'          => __( 'Excluded Categories', 'newsy-elements' ),
				'input_desc'       => __( 'Hold Command in Mac or CTRL in Windows to select multiple categories.', 'newsy-elements' ),
				'id'               => 'exclude',
				'multiple'         => 500,
				'options_callback' => 'Ak\Form\FormCallback::get_categories',
				'section'          => __( 'Settings', 'newsy-elements' ),
			),
		);
	}

	public function block_design_item_margin_options() {
		return array();
	}
}
