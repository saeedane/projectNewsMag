<?php

namespace NewsyElements\Shortcode\Element;

use Ak\Shortcode\ShortcodeAbstract;

/**
 * Newsy Ad Shortcode.
 */
class Block_Ad extends ShortcodeAbstract {

	public function __construct( $id, $params ) {

		$this->defaults = array(
			'type'             => '',
			'image'            => '',
			'image_alt'        => '',
			'image_link'       => '#',
			'image_new_tab'    => '',
			'google_client_id' => '',
			'google_slot_id'   => '',
			'google_desktop'   => '',
			'google_tab'       => '',
			'google_phone'     => '',
			'content'          => '',
			'css'              => '',
			'classes'          => '',
			'block_width'      => '',
		);

		parent::__construct( $id, $params );
	}

	/**
	 * Handle displaying of shortcode
	 *
	 * @param array  $atts
	 * @param string $content
	 *
	 * @return string
	 */
	public function render( $atts, $content = '' ) {
		$type = &$this->atts['type'];

		if ( empty( $type ) ) {
			return '';
		}

		if ( '' === $this->atts['block_width'] ) {
			$this->atts['block_width'] = apply_filters( 'newsy_block_width', 1 );
		}

		$classes = '';
		if ( isset( $this->params['style'] ) ) {
			$classes .= esc_attr( $this->params['style'] );
		}

		if ( isset( $atts['classes'] ) ) {
			$classes .= ' ' . esc_attr( $atts['classes'] );
		}

		// generate block unique id
		$html = '';
		// generate block unique id
		$block_id = 'block_' . ak_generate_uniqid();

		if ( 'image' === $type ) {
			$tab        = ( 'no' === $this->atts['image_new_tab'] ) ? '_self' : '_blank';
			$link       = $this->atts['image_link'];
			$text       = $this->atts['image_alt'];
			$image      = $this->atts['image'];
			$image_size = '';

			if ( is_int( (int) $image ) ) {
				$image_attacment = wp_get_attachment_image_src( (int) $image, 'full' );
				if ( $image_attacment ) {
					if ( isset( $image_attacment[2] ) ) {
						$image      = $image_attacment[0];
						$image_size = "width='{$image_attacment[1]}' height='{$image_attacment[2]}'";
					}
				}
			}

			if ( ! empty( $image ) ) {
				$html .= "<a href='{$link}' target='{$tab}' class='adlink' rel='nofollow noopener'><img class='lazyload' src='data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==' data-src='{$image}' alt='{$text}' {$image_size}></a>";
			}
		}

		if ( 'code' === $type ) {
			$html = is_null( $this->content ) ? $this->atts['content'] : $this->content;
		}

		if ( 'google' === $type ) {
			$client_id = $this->atts['google_client_id'];
			$slot_id   = $this->atts['google_slot_id'];

			if ( ! empty( $client_id ) && ! empty( $slot_id ) ) {
				$block_width = $this->atts['block_width'];
				if ( $block_width >= 2 ) {
					$desktopsize_ad = 3 === $block_width ? array( '970', '250' ) : array( '728', '90' );
					$tabsize_ad     = array( '468', '60' );
					$phonesize_ad   = array( '320', '50' );
				} else {
					$desktopsize_ad = array( '300', '250' );
					$tabsize_ad     = array( '300', '250' );
					$phonesize_ad   = array( '300', '250' );
				}

				$ad_style = '';

				$desktopsize = $this->atts['google_desktop'];
				$tabsize     = $this->atts['google_tab'];
				$phonesize   = $this->atts['google_phone'];

				if ( '' !== $desktopsize ) {
					$desktopsize_ad = explode( 'x', $desktopsize );
				}
				if ( '' !== $tabsize ) {
					$tabsize_ad = explode( 'x', $tabsize );
				}
				if ( '' !== $phonesize ) {
					$phonesize_ad = explode( 'x', $phonesize );
				}

				if ( 'hide' !== $desktopsize && is_array( $desktopsize_ad ) && isset( $desktopsize_ad['0'] ) && isset( $desktopsize_ad['1'] ) ) {
					$ad_style .= ".adsslot_{$block_id}{ width:{$desktopsize_ad[0]}px !important; height:{$desktopsize_ad[1]}px !important; }\n";
				}

				if ( 'hide' !== $tabsize && is_array( $tabsize_ad ) && isset( $tabsize_ad['0'] ) && isset( $tabsize_ad['1'] ) ) {
					$ad_style .= "@media (max-width:1199px) { .adsslot_{$block_id}{ width:{$tabsize_ad[0]}px !important; height:{$tabsize_ad[1]}px !important; } }\n";
				}

				if ( 'hide' !== $phonesize && is_array( $phonesize_ad ) && isset( $phonesize_ad['0'] ) && isset( $phonesize_ad['1'] ) ) {
					$ad_style .= "@media (max-width:767px) { .adsslot_{$block_id}{ width:{$phonesize_ad[0]}px !important; height:{$phonesize_ad[1]}px !important; } }\n";
				}

				$html .= "<div id=\"{$block_id}\" class=\"newsy_ad\">
                            <style type='text/css' scoped>{$ad_style}</style>
                            <ins class=\"adsbygoogle adsslot_{$block_id}\" style=\"display:inline-block;\" data-ad-client=\"{$client_id}\" data-ad-slot=\"{$slot_id}\"></ins>
                            <script async src='//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js'></script>
                            <script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
                        </div>";

			}
		}

		if ( empty( $html ) ) {
			return '';
		}

		$css = $this->render_block_css( $block_id );

		return "<div class='ak-ad {$classes} clearfix' id='{$block_id}'>" . $css . $html . '</div>';
	}

	public function fields() {
		return array_merge(
			newsy_get_block_ad_fields(),
			array(
				array(
					'id'      => 'css',
					'type'    => 'css_editor',
					'heading' => __( 'CSS box', 'newsy-elements' ),
					'section' => __( 'Design', 'newsy-elements' ),
				),
			)
		);
	}

	protected function render_block_css( $block_id ) {
		$out = '';

		//vc css options
		if ( ! empty( $this->atts['css'] ) && ! is_array( $this->atts['css'] ) ) {
			preg_match( '/{(.*?)}/s', $this->atts['css'], $match );
			if ( isset( $match[1] ) ) {
				$out .= "#{$block_id} { " . $match[1] . ' }';
			}
		}

		return "<style scoped>{$out}</style>";
	}
}
