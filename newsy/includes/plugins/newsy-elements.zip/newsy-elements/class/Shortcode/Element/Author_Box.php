<?php

namespace NewsyElements\Shortcode\Element;

use Ak\Shortcode\ShortcodeAbstract;

/**
 * Newsy Author Box Shortcode.
 */
class Author_Box extends ShortcodeAbstract {
	public function __construct( $id, $params ) {

		$this->defaults = array(
			'author'              => '',
			'show_cover'          => '',
			'show_desc'           => '',
			'desc_length'         => 255,
			'show_socials'        => '',
			'show_extras'         => '',
			'block_extra_classes' => '',
			'block_width'         => 1,
			'css'                 => '',
		);

		parent::__construct( $id, $params );
	}

	/**
	 * Handle displaying of shortcode
	 *
	 * @param array  $atts
	 * @param string $content
	 *
	 * @return string
	 */
	public function render( $atts, $content = '' ) {
		if ( '' === $atts['block_width'] ) {
			$atts['block_width'] = apply_filters( 'newsy_block_width', 1 );
		}

		$author_id  = $atts['author'];
		$author_url = esc_url( get_author_posts_url( $author_id ) );

		if ( empty( $author_id ) || ! $author_url ) {
			return '';
		}
		$post_author_url  = get_author_posts_url( $author_id );
		$post_author_name = get_the_author_meta( 'display_name', $author_id );
		$author_cover_url = '';

		if ( 'hide' !== $atts['show_cover'] && function_exists( 'bp_attachments_get_attachment' ) ) {
			// Get the Cover Image
			$author_cover_url = bp_attachments_get_attachment(
				'url', array(
					'object_dir' => 'members',
					'type'       => 'cover-image',
					'item_id'    => $author_id,
				)
			);
		}

		$classes  = ! empty( $author_cover_url ) ? 'author-has-cover' : '';
		$classes .= $atts['block_width'] > 1 ? ' center-items' : '';

		ob_start();  ?>

		<div class="ak-author-box <?php echo esc_attr( $classes ); ?> clearfix">
			<?php
			if ( ! empty( $author_cover_url ) ) {
				printf(
					'<a class="ak-author-cover lazyload" href="%s" title="%s" %s></a>',
					esc_url( $post_author_url ),
					esc_attr( $post_author_name ),
					empty( $author_cover_url ) ? '' : 'data-bgset="' . esc_url( $author_cover_url ) . ' 800w"'
				);
			}
			?>
			<div class="ak-author-image">
				<a href="<?php echo esc_url( $post_author_url ); ?>">
					<?php echo get_avatar( $author_id, 90, null, $post_author_name ); ?>
					<?php do_action( 'newsy_author_box_avatar_after', $author_id ); ?>
				</a>
			</div>

			<div class="ak-author-info">
				<div class="ak-author-bax-name">
					<h3 class="ak-author-name fn">
						<a href="<?php echo esc_url( $post_author_url ); ?>">
							<?php echo esc_html( $post_author_name ); ?>
						</a>
					</h3>
					<div class="ak-author-actions">
					<?php do_action( 'newsy_author_box_actions', $author_id ); ?>
					</div>
				</div>
				<?php
				if ( 'hide' !== $atts['show_desc'] ) {
					$this->get_author_desc( $author_id );
				}
				if ( 'hide' !== $atts['show_socials'] ) {
					$this->get_social_links( $author_id );
				}
				if ( 'hide' !== $atts['show_extras'] ) {
					do_action( 'newsy_author_box_extras', $author_id );
				}
				?>
			</div>
		</div>
		<?php

		return ob_get_clean();
	}


	/**
	 * Visual Composer Fields Map for Shortcode.
	 */
	public function get_author_desc( $author_id ) {
		$buffy  = '<div class="ak-author-description">';
		$buffy .= ak_html_limit_words( esc_html( get_the_author_meta( 'description', $author_id ) ), $this->atts['desc_length'], '&hellip;' );
		$buffy .= '</div>';

		ak_sanitize_echo( $buffy );
	}

	/**
	 * Visual Composer Fields Map for Shortcode.
	 */
	public function get_social_links( $author_id ) {
		$buffy = '<div class="ak-author-social">';

		foreach ( newsy_get_author_contact_methods() as $social_id => $social_name ) {
			$author_meta = get_the_author_meta( $social_id, $author_id );
			if ( ! empty( $author_meta ) ) {
				//the theme can use the twitter id instead of the full url. This avoids problems with yoast plugin
				if ( 'twitter' === $social_id ) {
					if ( ! filter_var( $author_meta, FILTER_VALIDATE_URL ) ) {
						$author_meta = str_replace( '@', '', $author_meta );
						$author_meta = 'http://twitter.com/' . $author_meta;
					}
				}

				$buffy .= '<a href="' . esc_url( $author_meta ) . '" rel="nofollow" class="' . $social_id . '" title="' . $social_name . '"><i class="fa fa-' . $social_id . '"></i> </a>';
			}
		}
		$buffy .= '</div>';

		ak_sanitize_echo( $buffy );
	}
	/**
	 * Visual Composer Fields Map for Shortcode.
	 */
	public function fields() {
		return array_merge(
			$this->block_inner_options(),
			$this->block_design_options()
		);
	}

	public function block_inner_options() {
			return array(
				array(
					'id'            => 'author',
					'type'          => 'ajax_select',
					'heading'       => __( 'Select Author to display', 'newsy-elements' ),
					'max_items'     => 1,
					'return_string' => true,
					'ajax_callback' => 'Ak\Form\FormCallback::get_users',
					'section'       => __( 'General', 'newsy-elements' ),
				),
				array(
					'id'          => 'show_cover',
					'type'        => 'switcher',
					'heading'     => __( 'Show Cover', 'newsy-elements' ),
					'description' => __( 'Reqiures BuddyPress plugin.', 'newsy-elements' ),
					'options'     => array(
						'on'  => '',
						'off' => 'hide',
					),
					'section'     => __( 'General', 'newsy-elements' ),
				),
				array(
					'id'      => 'show_desc',
					'type'    => 'switcher',
					'heading' => __( 'Show Description', 'newsy-elements' ),
					'options' => array(
						'on'  => '',
						'off' => 'hide',
					),
					'section' => __( 'General', 'newsy-elements' ),
				),
				array(
					'id'      => 'show_socials',
					'type'    => 'switcher',
					'heading' => __( 'Show Social Links', 'newsy-elements' ),
					'options' => array(
						'on'  => '',
						'off' => 'hide',
					),
					'section' => __( 'General', 'newsy-elements' ),
				),
				array(
					'id'      => 'show_extras',
					'type'    => 'switcher',
					'heading' => __( 'Show Extra Elements', 'newsy-elements' ),
					'options' => array(
						'on'  => '',
						'off' => 'hide',
					),
					'section' => __( 'General', 'newsy-elements' ),
				),
				array(
					'id'      => 'desc_length',
					'type'    => 'number',
					'heading' => __( 'Description Length', 'newsy-elements' ),
					'section' => __( 'General', 'newsy-elements' ),
				),
			);
	}

	/**
	 *  Handy function used to add pagination fields array to VC_Map.
	 *
	 * @return array
	 */
	public function block_design_options() {
		return array(
			array(
				'type'    => 'text',
				'heading' => __( 'Block Extra Class', 'newsy-elements' ),
				'id'      => 'block_extra_classes',
				'section' => __( 'Design', 'newsy-elements' ),
			),
			array(
				'type'    => 'css_editor',
				'heading' => __( 'CSS box', 'newsy-elements' ),
				'id'      => 'css',
				'section' => __( 'Design', 'newsy-elements' ),
			),
		);
	}
}
