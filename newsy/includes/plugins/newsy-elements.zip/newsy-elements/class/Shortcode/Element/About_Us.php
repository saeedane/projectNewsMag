<?php

namespace NewsyElements\Shortcode\Element;

use NewsyElements\Shortcode\BlockAbstract;

/**
 * Newsy About Shortcode.
 */
class About_Us extends BlockAbstract {

	public function __construct( $id, $params ) {

		$_defaults = array(
			'layout_align'       => '',
			'image_rounded'      => '',
			'image'              => '',
			'logo_text'          => '',
			'about_title'        => '',
			'description'        => '',
			'social_sites'       => '',
			'social_sites_color' => 'colored',
			'about_link_url'     => '',
			'about_link_text'    => ak_get_translation( 'Read More', 'newsy-elements', 'read_more' ),
		);

		$this->defaults = array_merge( $this->defaults, $_defaults );

		parent::__construct( $id, $params );
	}

	/**
	 * Handle displaying of shortcode.
	 *
	 * @param array  $this->atts
	 * @param string $content
	 *
	 * @return string
	 */
	public function inner_classes( $classes ) {

		if ( '' != $this->atts['layout_align'] ) {
			$classes[] = ' text-align-center';
		}

		if ( '' != $this->atts['image_rounded'] ) {
			$classes[] = ' image-align-rounded';
		}

		return $classes;
	}

	/**
	 * Handle displaying of shortcode.
	 *
	 * @return string
	 */
	public function render_inner() {

		$buffy = '';

		if ( '' !== $this->atts['image'] ) {
			$buffy .= '<div class="ak-about-image">';
			$buffy .= '<img src="' . esc_url( $this->atts['image'] ) . '" alt="' . esc_attr( $this->atts['logo_text'] ) . '">';
			$buffy .= '</div>';
		}

		if ( '' !== $this->atts['about_title'] ) {
			$buffy .= '<h4 class="ak-about-name">';
			$buffy .= esc_html( $this->atts['about_title'] );
			$buffy .= '</h4>';
		}

		if ( '' !== $this->atts['description'] ) {
			$buffy .= '<p class="ak-about-description">';
			$buffy .= esc_html( $this->atts['description'] );

			if ( '' !== $this->atts['about_link_url'] ) {
				$buffy .= '<a href="' . esc_url( $this->atts['about_link_url'] ) . '" class="ak-about-link">' . esc_html( $this->atts['about_link_text'] ) . '</a>';
			}
			$buffy .= '</p>';
		}

		if ( '' !== $this->atts['social_sites'] && function_exists( 'newsy_social_counter_render' ) ) {
			$buffy .= '<div class="ak-about-social-items">';
			$buffy .= newsy_social_counter_render( $this->atts['social_sites'], 'style-4', $this->atts['social_sites_color'] );
			$buffy .= '</div>';
		}

		return $buffy;
	}

	/**
	 * Visual Composer Fields Map for Shortcode.
	 */
	public function fields() {
		return array_merge(
			$this->block_inner_options(),
			$this->block_header_options(),
			$this->block_design_options()
		);
	}

	/**
	 * Registers Visual Composer Add-on.
	 */
	public function block_inner_options() {
		return array(
			array(
				'type'         => 'media_image',
				'admin_label'  => false,
				'heading'      => __( 'Image', 'newsy-elements' ),
				'id'           => 'image',
				'upload_label' => __( 'Upload Image', 'newsy-elements' ),
				'remove_label' => __( 'Remove', 'newsy-elements' ),
				'media_title'  => __( 'Remove', 'newsy-elements' ),
				'media_button' => __( 'Select as Image', 'newsy-elements' ),
				'section'      => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'type'        => 'text',
				'admin_label' => false,
				'heading'     => __( 'Image Text (alt)', 'newsy-elements' ),
				'id'          => 'logo_text',
				'section'     => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'type'        => 'text',
				'admin_label' => false,
				'heading'     => __( 'About Title', 'newsy-elements' ),
				'id'          => 'about_title',
				'section'     => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'type'        => 'textarea',
				'admin_label' => false,
				'heading'     => __( 'Description', 'newsy-elements' ),
				'id'          => 'description',
				'section'     => __( 'Settings', 'newsy-elements' ),
			),

			array(
				'type'        => 'text',
				'admin_label' => false,
				'heading'     => __( 'Read more text', 'newsy-elements' ),
				'id'          => 'about_link_text',
				'section'     => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'type'        => 'text',
				'admin_label' => true,
				'heading'     => __( 'Read more link', 'newsy-elements' ),
				'id'          => 'about_link_url',
				'section'     => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'heading'          => __( 'Social Sites', 'newsy-elements' ),
				'description'      => __( 'Select active social share links and sort them.', 'newsy-elements' ),
				'type'             => 'visual_checkbox',
				'id'               => 'social_sites',
				'admin_label'      => true,
				'options_callback' => 'newsy_get_social_site_options',
				'sorter'           => true,
				'social_fields'    => true,
				'section'          => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'heading'  => __( 'Social Icons Color style?', 'newsy-elements' ),
				'type'     => 'select',
				'id'       => 'social_sites_color',
				'vertical' => true,
				'options'  => array(
					'colored'      => __( 'Colored', 'newsy-elements' ),
					'dark'         => __( 'Dark', 'newsy-elements' ),
					'light'        => __( 'Light', 'newsy-elements' ),
					'light-box'    => __( 'Light Box', 'newsy-elements' ),
					'light-square' => __( 'Light Square', 'newsy-elements' ),
					'light-circle' => __( 'Light Circle', 'newsy-elements' ),
				),
				'section'  => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'type'     => 'visual_select',
				'heading'  => __( 'Layout Align', 'newsy-elements' ),
				'id'       => 'layout_align',
				'vertical' => true,
				'options'  => array(
					''       => __( 'Left', 'newsy-elements' ),
					'center' => __( 'Center', 'newsy-elements' ),
				),
				'section'  => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'type'    => 'switcher',
				'heading' => __( 'Image Round?', 'newsy-elements' ),
				'id'      => 'image_rounded',
				'options' => array(
					'on'  => 'yes',
					'off' => '',
				),
				'section' => __( 'Settings', 'newsy-elements' ),
			),
		);
	}

	public function block_design_item_margin_options() {
		return array();
	}
}
