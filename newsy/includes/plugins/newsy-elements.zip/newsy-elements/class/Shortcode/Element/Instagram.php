<?php

namespace NewsyElements\Shortcode\Element;

use Ak\Shortcode\ShortcodeAbstract;
use NewsyElements\Support\InstagramFeedApi;

/**
 * Newsy Instagram Shortcode.
 */
class Instagram extends ShortcodeAbstract {

	private $count;
	private $username;
	private $newtab;

	public function __construct( $id, $params ) {
		$_defaults = array(
			'follow_button' => ak_get_translation( 'Follow Us', 'newsy-elements', 'fullow_instagram' ),
			'column'        => 3,
			'row'           => 3,
			'item_margin'   => 5,
			'newtab'        => '',
			'css'           => '',
		);

		$this->defaults = $_defaults;

		parent::__construct( $id, $params );
	}

	/**
	 * Handle displaying of shortcode
	 *
	 * @param array  $atts
	 * @param string $content
	 *
	 * @return string
	 */
	public function render( $atts, $content = '' ) {
		$this->count  = $this->atts['row'] * $this->atts['column'];
		$this->newtab = empty( $this->atts['newtab'] ) ? 'target=\'_blank\'' : '';

		// generate block unique id
		$block_id = 'block_' . ak_generate_uniqid();

		$this->atts['block_id'] = $block_id;

		$content        = '';
		$api            = InstagramFeedApi::get_instance();
		$data           = $api->get_data();
		$this->username = $api->get( 'username' );

		if ( $api->is_expired() ) {
			$content = $api->get_error( 'expired' );
		} elseif ( ! $api->is_active() ) {
			$content = $api->get_error( 'inactive' );
		} else {
			$content = $this->render_items( $data );
		}

		$css = $this->render_block_css();

		$follow_button = $this->get_follow_button();

		return "<div class=\"ak-block ak-block-instagram clearfix\" id=\"{$block_id}\">
                    {$css}
                    {$follow_button}
                    <ul class=\"instagram-pics col{$this->atts['column']} normal\">
                        {$content}
                    </ul>
                </div>";
	}


	public function render_block_css() {
		$out         = '';
		$block_id    = &$this->atts['block_id'];
		$item_margin = &$this->atts['item_margin'];

		if ( '' !== $item_margin ) {
			$out .= "#{$block_id} ul {  margin-right:  -" . $item_margin . 'px; }';
			$out .= "#{$block_id} li { padding-right: {$item_margin}px; margin-bottom: {$item_margin}px; }";
		}

		if ( '' !== $this->atts['css'] ) {
			preg_match( '/{(.*?)}/s', $this->atts['css'], $match );
			if ( isset( $match[1] ) ) {
				$out .= "#{$block_id} { " . $match[1] . ' }';
			}
		}

		return "<style scoped>{$out}</style>";
	}


	protected function render_items( $data ) {
		if ( empty( $data ) || ! is_array( $data ) ) {
			return;
		}

		$content = '';
		$like    = '';
		$comment = '';
		$i       = 1;
		foreach ( $data as $image ) {
			$image_caption = isset( $image['caption'] ) ? $image['caption'] : '';
			$content      .=
				"<li>
                    <a href='{$image['permalink'] }' {$this->newtab}>
                        <div class='item-meta'>{$like}{$comment}</div>
                        <div class='ak-featured-thumb size-1000'><img src='{$image['media_url']}' alt='{$image_caption}' title='{$image_caption}'></div>
                    </a>
                </li>";

			if ( $i >= $this->count ) {
				break;
			}

			$i++;
		}

		return $content;
	}

	/**
	 * Follow button
	 *
	 * @param $follow_button_option
	 *
	 * @return string
	 */
	public function get_follow_button() {
		$follow_button = '';
		if ( ! empty( $this->atts['follow_button'] ) ) {
			$follow_button =
				"<h3 class='ak-block-instagram-heading'>
                    <a href='//www.instagram.com/{$this->username}/' {$this->newtab}>
                        <i class='fa fa-instagram'></i>
                        " . esc_html( $this->atts['follow_button'] ) . '
                    </a>
                </h3>';
		}

		return $follow_button;
	}


	/**
	 * Registers Visual Composer Add-on.
	 */
	public function fields() {
		$api      = InstagramFeedApi::get_instance();
		$username = $api->get( 'username' );

		if ( ! empty( $username ) ) {
			$info_label       = sprintf( __( 'Connected as %s', 'newsy-elements' ), $username );
			$info_description = sprintf( __( 'This token is valid until %1$s. <a class="%2$s" href="%3$s" target="_blank">Click here</a> to connect another account.', 'newsy-elements' ), date( 'F d, Y H:i:s', (int) $api->get( 'expires_on' ) ), 'newsy_access_token instagram', $api->get_api_url() );
		} else {
			$info_label       = esc_html__( 'Connect Instagram Account', 'newsy-elements' );
			$info_description = sprintf( __( 'Connect your Instagram account by clicking this <a class="%1$s" href="%2$s" target="_blank">link</a> and refer to next page URL.', 'newsy-elements' ), 'newsy_access_token instagram', $api->get_api_url() );
		}

		return array(
			array(
				'id'          => 'redirect_info',
				'type'        => 'info',
				'heading'     => $info_label,
				'description' => $info_description,
				'section'     => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'id'          => 'column',
				'heading'     => __( 'Set Column', 'newsy-elements' ),
				'description' => __( 'Choose number of column widget.', 'newsy-elements' ),
				'type'        => 'select',
				'options'     => array(
					2 => __( '2 Columnss', 'newsy-elements' ),
					3 => __( '3 Columnss', 'newsy-elements' ),
					4 => __( '4 Columnss', 'newsy-elements' ),
					5 => __( '5 Columnss', 'newsy-elements' ),
					6 => __( '6 Columns', 'newsy-elements' ),
					7 => __( '7 Columns', 'newsy-elements' ),
					8 => __( '8 Columns', 'newsy-elements' ),
				),
				'section'     => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'id'          => 'row',
				'heading'     => __( 'Set Row', 'newsy-elements' ),
				'description' => __( 'Choose number of row widget.', 'newsy-elements' ),
				'type'        => 'slider',
				'min'         => 1,
				'max'         => 10,
				'section'     => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'id'          => 'item_margin',
				'heading'     => __( 'Items Margin', 'newsy-elements' ),
				'description' => __( 'Choose gap between items.', 'newsy-elements' ),
				'type'        => 'slider',
				'min'         => 1,
				'max'         => 50,
				'section'     => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'id'      => 'follow_button',
				'heading' => __( 'Follow Button Text', 'newsy-elements' ),
				'type'    => 'text',
				'section' => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'id'          => 'newtab',
				'heading'     => __( 'Open New Tab', 'newsy-elements' ),
				'description' => __( 'Open Instagram profile page on new tab.', 'newsy-elements' ),
				'type'        => 'switcher',
				'options'     => array(
					'off' => 'no',
					'on'  => '',
				),
				'section'     => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'type'    => 'css_editor',
				'heading' => __( 'CSS box', 'newsy-elements' ),
				'id'      => 'css',
				'section' => __( 'Design', 'newsy-elements' ),
			),
		);
	}

}
