<?php

namespace NewsyElements\Shortcode\Element;

use NewsyElements\Shortcode\BlockAbstract;

/**
 * Newsy Category Menu Shortcode.
 */
class CategoryMenu extends BlockAbstract {

	public function inner_defaults( &$_defaults ) {
		$_defaults['order_by']        = '';
		$_defaults['order']           = '';
		$_defaults['show_categories'] = '';
		$_defaults['count']           = 10;
	}

	public function render_inner() {
		$column_classes = '';

		$args = array(
			'orderby' => $this->atts['order_by'],
			'include' => implode( ',', $this->atts['show_categories'] ),
			'order'   => $this->atts['order'],
			'number'  => $this->atts['count'],
		);

		$categories = get_categories( $args );
		$buffy      = '';

		if ( ! empty( $categories ) ) {
			$buffy .= '<ul class="ak-category-menu">';
			foreach ( $categories as $term ) {
				$buffy .= '<li class="popular-cat-item ' . $column_classes . ' term-item-' . esc_attr( $term->term_id ) . '">';
				$buffy .= '<a class="link" href="' . esc_url( get_category_link( $term->term_id ) ) . '">';

				if ( 'show' != $this->atts['show-cat-icon'] ) {
					$show_bg_image = ak_get_term_meta( 'term_header_custom_logo', $term->term_id );

					if ( ! empty( $show_bg_image ) ) {
						$buffy .= '<img width="24" height="24" class="cat_icon" src="' . $show_bg_image . '" alt="' . $term->name . '" \>';
					}
				}

				$buffy .= $term->name;
				$buffy .= '</a>';
				$buffy .= '</li>';
			}
			$buffy .= '</ul>';
		}

		unset( $categories );

		return $buffy;
	}

	/**
	 * Visual Composer Fields Map for Shortcode.
	 */
	public function fields() {
		return array_merge(
			$this->block_inner_options(),
			$this->block_header_options(),
			$this->block_design_options()
		);
	}

	/**
	 * Registers Visual Composer Add-on.
	 */
	public function block_inner_options() {
		return array(
			array(
				'type'        => 'number',
				'admin_label' => false,
				'heading'     => __( 'Count', 'newsy-elements' ),
				'id'          => 'count',
				'default'     => '6',
				'value'       => '6',
				'section'     => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'type'        => 'select',
				'heading'     => __( 'Order By', 'newsy-elements' ),
				'id'          => 'order_by',
				'admin_label' => false,
				'default'     => 'count',
				'options'     => array(
					'count' => __( 'Total Posts Count', 'newsy-elements' ),
					'name'  => __( 'Name', 'newsy-elements' ),
					'rand'  => __( 'Random', 'newsy-elements' ),
				),
				'section'     => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'type'        => 'select',
				'heading'     => __( 'Order', 'newsy-elements' ),
				'id'          => 'order',
				'admin_label' => false,
				'default'     => 'DESC',
				'options'     => array(
					'DESC' => __( 'Latest First (DESC)', 'newsy-elements' ),
					'ASC'  => __( 'Oldest First (ASC)', 'newsy-elements' ),
				),
				'section'     => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'type'        => 'select',
				'heading'     => __( 'Columns', 'newsy-elements' ),
				'id'          => 'block_width',
				'admin_label' => true,
				'value'       => '',
				'options'     => array(
					''  => __( 'No Column', 'newsy-elements' ),
					'2' => __( '2 Columns', 'newsy-elements' ),
					'3' => __( '3 Columns', 'newsy-elements' ),
					'4' => __( '4 Columns', 'newsy-elements' ),
				),
				'section'     => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'type'        => 'switcher',
				'heading'     => __( 'Show Category Post Count', 'newsy-elements' ),
				'id'          => 'show-post-count',
				'admin_label' => false,
				'options'     => array(
					'on'  => '',
					'off' => 'hide',
				),
				'section'     => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'type'        => 'switcher',
				'heading'     => __( 'Show Category Icon', 'newsy-elements' ),
				'id'          => 'show-cat-icon',
				'admin_label' => false,
				'options'     => array(
					'on'  => '',
					'off' => 'hide',
				),
				'section'     => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'type'        => 'switcher',
				'heading'     => __( 'Show Empty Categories', 'newsy-elements' ),
				'id'          => 'show-empty',
				'admin_label' => false,
				'options'     => array(
					'on'  => '',
					'off' => 'hide',
				),
				'section'     => __( 'Settings', 'newsy-elements' ),
			),
			array(
				'type'             => 'select',
				'admin_label'      => false,
				'heading'          => __( 'Excluded Categories', 'newsy-elements' ),
				'input_desc'       => __( 'Hold Command in Mac or CTRL in Windows to select multiple categories.', 'newsy-elements' ),
				'id'               => 'exclude',
				'multiple'         => true,
				'drop_down_select' => true,
				'options'          => array(
					''                => __( '-- No Exclude --', 'newsy-elements' ),
					'category_walker' => 'category_walker',
				),
				'section'          => __( 'Settings', 'newsy-elements' ),
			),
		);
	}

	public function block_design_item_margin_options() {
		return array();
	}
}
