<?php

namespace NewsyElements\Shortcode\Element;

use Ak\Shortcode\ShortcodeAbstract;

/**
 * Newsy Mailchimp Shortcode.
 */
class Mailchimp extends ShortcodeAbstract {
	public function __construct( $id, $params ) {

		$_defaults = array(
			'style'               => 'style-1',
			'icon'                => '',
			'color'               => '',
			'text_align'          => '',
			'form_layout'         => '',
			'image'               => '',
			'title'               => '',
			'msg'                 => '',
			'mailchimp_url'       => '#',
			'input_alt'           => ak_get_translation( 'You can unsubscribe at any time', 'newsy-elements', 'newsletter_unsubcribe' ),
			'layout_align'        => '',
			'block_extra_classes' => '',
			'block_width'         => '',
			'css'                 => '',
		);

		$this->defaults = array_merge( $this->defaults, $_defaults );

		parent::__construct( $id, $params );
	}

	/**
	 * Handle displaying of shortcode
	 *
	 * @param array  $atts
	 * @param string $content
	 *
	 * @return string
	 */
	public function render( $atts, $content = '' ) {

		$classes = array();

		if ( '' !== $this->atts['style'] ) {
			$classes[] = esc_attr( $this->atts['style'] );
		}

		if ( '' !== $this->atts['icon'] ) {
			$classes[] = 'has-icon';
		}

		if ( '' !== $this->atts['text_align'] ) {
			$classes[] = 'text-align-center';
		}

		if ( '' !== $this->atts['form_layout'] ) {
			$classes[] = 'form-horizontal';
		}
		$block_width = apply_filters( 'newsy_block_width', $this->atts['block_width'] );
		$classes[]   = 'ak-block-width-' . $block_width;

		if ( ! empty( $this->atts['block_extra_classes'] ) ) {
			$classes[] = esc_attr( $this->atts['block_extra_classes'] );
		}

		// generate block unique id
		$block_id = 'block_' . ak_generate_uniqid();

		$this->atts['block_id'] = $block_id;

		$buffy = '<div class="ak-block ak-block-newsletter ' . implode( ' ', $classes ) . ' clearfix"  id="' . $block_id . '">';

		$buffy .= $this->render_block_css();

		$buffy .= '<div class="ak-block-inner">';

		$buffy .= $this->render_inner();

		$buffy .= '</div>';

		$buffy .= '</div>';

		unset( $this->atts );

		return $buffy;
	}

	public function render_inner() {

		$buffy = '';

		$buffy .= '<div class="ak-newsletter-head clearfix">';
		if ( '' !== $this->atts['icon'] ) {
			$buffy .= '<div class="ak-newsletter-icon">';
			$buffy .= ak_get_icon( $this->atts['icon'] );
			$buffy .= '</div>';
		}

		if ( '' !== $this->atts['image'] ) {
			$buffy .= '<div class="ak-newsletter-image">';
			$buffy .= '<img src="' . $this->atts['image'] . '" alt="' . esc_attr( $this->atts['title'] ) . '">';
			$buffy .= '</div>';
		}
		$buffy .= '<div class="ak-newsletter-text">';
		if ( '' !== $this->atts['title'] ) {
			$buffy .= '<h4 class="ak-newsletter-title">';
			$buffy .= esc_attr( $this->atts['title'] );
			$buffy .= '</h4>';
		}

		if ( '' !== $this->atts['msg'] ) {
			$buffy .= '<div class="ak-newsletter-message">';
			$buffy .= wpautop( $this->atts['msg'] );
			$buffy .= '</div>';
		}
		$buffy .= '</div>';
		$buffy .= '</div>';

		if ( '' !== $this->atts['mailchimp_url'] ) {
			$newsletter_email = ak_get_translation( 'Enter your email...', 'newsy-elements', 'newsletter_email' );
			$input_text       = esc_html( $this->atts['input_alt'] );

			$buffy .= '<div class="ak-newsletter-form">';
			$buffy .= '<form action="' . esc_url( $this->atts['mailchimp_url'] ) . '" method="post" name="mc-embedded-subscribe-form" class="validate" target="_blank">';
			$buffy .= '<input name="EMAIL" type="email" placeholder="' . esc_attr( $newsletter_email ) . '" class="newsletter-email">';
			$buffy .= '<button class="btn newsletter-subscribe" name="subscribe" type="submit">';
			$buffy .= ak_get_translation( 'Subscribe', 'newsy-elements', 'newsletter_button' );
			$buffy .= '</button>';
			$buffy .= '</form>';
			if ( ! empty( $input_text ) ) {
				$buffy .= '<span class="unsubscribe-info">' . $input_text . '</span>';
			}
			$buffy .= '</div>';
		}

		return $buffy;
	}


	public function render_block_css() {
		if ( '' === $this->atts['color'] && '' === $this->atts['css'] ) {
			return;
		}
		$block_id = &$this->atts['block_id'];
		$color    = &$this->atts['color'];

		$out  = '#' . esc_attr( $block_id ) . ' .ak-newsletter-icon{  background-color:' . $color . '; }';
		$out .= '#' . esc_attr( $block_id ) . ':before{ background-color:' . $color . '; }';
		$out .= '#' . esc_attr( $block_id ) . ' .newsletter-email:focus{ border-color:' . $color . '; }';
		$out .= '#' . esc_attr( $block_id ) . ' .ak-newsletter{ background-color:' . $color . '; }';
		$out .= '#' . esc_attr( $block_id ) . ' .newsletter-subscribe{ background-color:' . $color . '; }';

		//vc css options
		if ( '' !== $this->atts['css'] ) {
			preg_match( '/{(.*?)}/s', $this->atts['css'], $match );
			if ( isset( $match[1] ) ) {
				$out .= "#{$block_id} { " . $match[1] . ' }';
			}
		}

		unset( $color );

		return "<style scoped>{$out}</style>";
	}

	/**
	 * Visual Composer Fields Map for Shortcode.
	 */
	public function fields() {
		return array_merge(
			self::block_newsletter_options(),
			$this->block_design_options()
		);
	}

	public static function block_newsletter_options() {
			return array(
				array(
					'type'        => 'info',
					'heading'     => __( 'Instructions', 'newsy-elements' ),
					'info_type'   => 'tip',
					'id'          => 'help',
					'description' => wp_kses(
						sprintf(
							'<p>To integrate MailChimp with your site, you will need MailChimp signup form code that you can find it with following steps:</p>
							<ol>
								<li><a href="%s" target="_blank">Log in</a> to your MailChimp account.</li>
								<li>From your account Dashboard, click <strong>Lists</strong> in the navigation menu.</li>
								<li>Find the list you want to connect to your site, click on it.</li>
								<li>Find the "<strong>Sign up forms</strong>" from the list navigation, click on it.</li>
								<li>Click "<strong>Select</strong>" on the "<strong>Embedded</strong>" forms option.</li>
								<li>Find the "<strong>Copy/paste onto your site</strong>" section.</li>
								<li>Click anywhere in the box to select the code.</li>
								<li>Press "<strong>ctrl + C</strong>" on a PC or "<strong>command + C</strong>" on a Mac to copy the code.</li>
								<li>Paste it in following "<strong>MailChimp Form Code</strong>" field.</li>
							</ol>',
							'https://goo.gl/MU6UWn'
						),
						ak_trans_allowed_html()
					),
					'section'     => __( 'Settings', 'newsy-elements' ),
				),
				array(
					'type'        => 'text',
					'admin_label' => false,
					'heading'     => __( 'Title', 'newsy-elements' ),
					'id'          => 'title',
					'section'     => __( 'Settings', 'newsy-elements' ),
				),
				array(
					'type'        => 'icon_select',
					'admin_label' => false,
					'heading'     => __( 'Title Icon', 'newsy-elements' ),
					'id'          => 'icon',
					'section'     => __( 'Settings', 'newsy-elements' ),
				),
				array(
					'type'        => 'textarea',
					'admin_label' => false,
					'heading'     => __( 'Message', 'newsy-elements' ),
					'id'          => 'msg',
					'section'     => __( 'Settings', 'newsy-elements' ),
				),
				array(
					'type'         => 'media_image',
					'admin_label'  => false,
					'heading'      => __( 'Image', 'newsy-elements' ),
					'id'           => 'image',
					'upload_label' => __( 'Upload Image', 'newsy-elements' ),
					'remove_label' => __( 'Remove', 'newsy-elements' ),
					'media_title'  => __( 'Remove', 'newsy-elements' ),
					'media_button' => __( 'Select as Image', 'newsy-elements' ),
					'section'      => __( 'Settings', 'newsy-elements' ),
				),
				array(
					'type'        => 'text',
					'admin_label' => false,
					'heading'     => __( 'MailChimp List URL', 'newsy-elements' ),
					'id'          => 'mailchimp_url',
					'section'     => __( 'Settings', 'newsy-elements' ),
				),
				array(
					'type'        => 'text',
					'admin_label' => false,
					'heading'     => __( 'Input Below Text', 'newsy-elements' ),
					'id'          => 'input_alt',
					'section'     => __( 'Settings', 'newsy-elements' ),
				),
				array(
					'type'    => 'visual_select',
					'heading' => __( 'Style', 'newsy-elements' ),
					'id'      => 'style',
					'options' => array(
						'style-1' => sprintf( __( 'Style %s', 'newsy-elements' ), '1' ),
						'style-2' => sprintf( __( 'Style %s', 'newsy-elements' ), '2' ),
						'style-3' => sprintf( __( 'Style %s', 'newsy-elements' ), '3' ),
						'style-4' => sprintf( __( 'Style %s', 'newsy-elements' ), '4' ),
						'style-5' => sprintf( __( 'Style %s', 'newsy-elements' ), '5' ),
						'style-6' => sprintf( __( 'Style %s', 'newsy-elements' ), '6' ),
						'style-7' => sprintf( __( 'Style %s', 'newsy-elements' ), '7' ),
					),
					'section' => __( 'Settings', 'newsy-elements' ),
				),
				array(
					'type'     => 'visual_select',
					'heading'  => __( 'Text Align', 'newsy-elements' ),
					'id'       => 'text_align',
					'vertical' => true,
					'options'  => array(
						''       => __( 'Left', 'newsy-elements' ),
						'center' => __( 'Center', 'newsy-elements' ),
					),
					'section'  => __( 'Settings', 'newsy-elements' ),
				),
				array(
					'type'     => 'visual_select',
					'heading'  => __( 'Form Layout', 'newsy-elements' ),
					'id'       => 'form_layout',
					'vertical' => true,
					'options'  => array(
						''           => __( 'Vertical', 'newsy-elements' ),
						'Horizontal' => __( 'Horizontal', 'newsy-elements' ),
					),
					'section'  => __( 'Settings', 'newsy-elements' ),
				),
				array(
					'type'        => 'color',
					'admin_label' => false,
					'heading'     => __( 'Block Color', 'newsy-elements' ),
					'id'          => 'color',
					'section'     => __( 'Settings', 'newsy-elements' ),
				),
			);
	}

	/**
	 *  Handy function used to add pagination fields array to VC_Map.
	 *
	 * @return array
	 */
	public function block_design_options() {
		return array(
			array(
				'type'    => 'text',
				'heading' => __( 'Block Extra Class', 'newsy-elements' ),
				'id'      => 'block_extra_classes',
				'section' => __( 'Design', 'newsy-elements' ),
			),
			array(
				'type'    => 'css_editor',
				'heading' => __( 'CSS box', 'newsy-elements' ),
				'id'      => 'css',
				'section' => __( 'Design', 'newsy-elements' ),
			),
		);
	}
}
