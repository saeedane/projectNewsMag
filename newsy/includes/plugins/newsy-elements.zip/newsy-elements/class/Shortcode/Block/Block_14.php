<?php

namespace NewsyElements\Shortcode\Block;

use NewsyElements\Shortcode\BlockAbstract;
use NewsyElements\Module\Module_2_Tall;
use NewsyElements\Module\Module_3;

/**
 * Newsy Block 14.
 */
class Block_14 extends BlockAbstract {


	public function __construct( $id, $params ) {
		parent::__construct( $id, $params );

		$this->defaults['module_2_tall_custom_enabled'] = '';
		$this->defaults['module_2_tall_custom_parts']   = '';
		$this->defaults['module_3_custom_enabled']      = '';
		$this->defaults['module_3_custom_parts']        = '';
	}

	/**
	 * Display the inner content of block.
	 *
	 * @param array $atts Attribute of shortcode or ajax action
	 * @param array $query_posts Wp posts
	 *
	 * @return string
	 */
	public function inner( &$atts, $query_posts ) {
		$post_count     = 0;
		$buffy          = '';
		$module_3_atts  = $this->get_module_atts( $atts, 'module_3_' );
		$module_2t_atts = $this->get_module_atts( $atts, 'module_2_tall_' );

		foreach ( $query_posts as $post ) {
			$post_count++;

			if ( 1 === $post_count ) {
				$the_post = new Module_3( $post, $module_3_atts );
				$buffy   .= $the_post->display();
			} else {
				$the_post   = new Module_2_Tall( $post, $module_2t_atts );
				$buffy     .= $the_post->display();
				$post_count = 0;
			}
		}

		unset( $query_posts );

		return $buffy;
	}


	public function block_design_inner_options() {
		return array(
			array(
				'type'        => 'select',
				'heading'     => __( 'Columns', 'newsy-elements' ),
				'id'          => 'block_width',
				'admin_label' => true,
				'options'     => array(
					''  => __( 'Auto Column', 'newsy-elements' ),
					'2' => __( '2 Columns', 'newsy-elements' ),
					'3' => __( '3 Columns', 'newsy-elements' ),
					'4' => __( '4 Columns', 'newsy-elements' ),
					'5' => __( '5 Columns', 'newsy-elements' ),
				),
				'section'     => __( 'Design', 'newsy-elements' ),
			),
		);
	}

	public function block_module_show_parts() {
		return array_merge(
			newsy_get_module_vc_fields( 'module_2_tall', true ),
			newsy_get_module_vc_fields( 'module_3', true )
		);
	}
}
