<?php

namespace NewsyElements\Shortcode\Block;

use NewsyElements\Module\Module_2;
use NewsyElements\Module\Module_6;
use NewsyElements\Shortcode\BlockAbstract;

/**
 * Newsy Block 7.
 */
class Block_7 extends BlockAbstract {

	public function __construct( $id, $params ) {
		parent::__construct( $id, $params );

		$this->defaults['module_2_custom_enabled'] = '';
		$this->defaults['module_2_custom_parts']   = '';
		$this->defaults['module_6_custom_enabled'] = '';
		$this->defaults['module_6_custom_parts']   = '';

		$this->fixed_count = true;
	}

	/**
	 * Display the inner content of block.
	 *
	 * @param array $atts Attribute of shortcode or ajax action
	 * @param array $query_posts Wp posts
	 *
	 * @return string
	 */
	public function inner( &$atts, $query_posts ) {
		$total_count   = count( $query_posts );
		$block_width   = $atts['block_width'];
		$post_count    = 0;
		$module_6_atts = $this->get_module_atts( $atts, 'module_6_' );
		$module_2_atts = $this->get_module_atts( $atts, 'module_2_' );

		$buffy = '';
		switch ( $block_width ) {
			case '1':
				foreach ( $query_posts as $post ) {
					$post_count++;

					if ( 1 === $post_count ) {
						$the_post = new Module_6( $post, $module_6_atts );
						$buffy   .= $the_post->display();
					} else {
						if ( 2 === $post_count ) {
							$buffy .= '<div class="row">';
						}
						$buffy   .= '<div class="col-sm-6">';
						$the_post = new Module_2( $post, $module_2_atts );
						$buffy   .= $the_post->display();
						$buffy   .= '</div>';

						if ( 3 === $post_count || $total_count === $post_count ) {
							$buffy     .= '</div>';
							$post_count = 0;
						}
					}
				}
				break;

			case '2':
			case '3':
				foreach ( $query_posts as $post ) {
					$post_count++;

					if ( 1 === $post_count ) {
						$buffy   .= '<div class="row">';
						$buffy   .= '<div class="col-sm-8">';
						$the_post = new Module_6( $post, $module_6_atts );
						$buffy   .= $the_post->display();
						$buffy   .= '</div>';
					} else {
						if ( 2 === $post_count ) {
							$buffy .= '<div class="col-sm-4">';
						}
						$the_post = new Module_2( $post, $module_2_atts );
						$buffy   .= $the_post->display();

						if ( 3 === $post_count || $total_count === $post_count ) {
							$buffy     .= '</div>';
							$buffy     .= '</div>';
							$post_count = 0;
						}
					}
				}
				break;
		}

		unset( $query_posts );

		return $buffy;
	}


	public function block_module_show_parts() {
		return array_merge(
			newsy_get_module_vc_fields( 'module_6', true ),
			newsy_get_module_vc_fields( 'module_2', true )
		);
	}
}
