<?php

namespace NewsyElements\Shortcode\Block;

use NewsyElements\Module\Module_2;
use NewsyElements\Module\Module_6;
use NewsyElements\Shortcode\BlockAbstract;

/**
 * Newsy Block 10.
 */
class Block_10 extends BlockAbstract {

	public function __construct( $id, $params ) {
		parent::__construct( $id, $params );

		$this->defaults['module_2_custom_enabled'] = '';
		$this->defaults['module_2_custom_parts']   = '';
		$this->defaults['module_6_custom_enabled'] = '';
		$this->defaults['module_6_custom_parts']   = '';
	}

	/**
	 * Display the inner content of block.
	 *
	 * @param array $atts Attribute of shortcode or ajax action
	 * @param array $query_posts Wp posts
	 *
	 * @return string
	 */
	public function inner( &$atts, $query_posts ) {
		$total_count   = count( $query_posts );
		$column_number = $atts['block_width'];
		$count         = $atts['count'];
		$post_count    = 0;
		$module_6_atts = $this->get_module_atts( $atts, 'module_6_' );
		$module_2_atts = $this->get_module_atts( $atts, 'module_2_' );

		$buffy = '';

		switch ( $column_number ) {
			case '1':
				foreach ( $query_posts as $post ) {
					$post_count++;

					if ( 1 === $post_count ) {
						$the_post = new Module_6( $post, $module_6_atts );
						$buffy   .= $the_post->display();
					} else {

						$the_post = new Module_2( $post, $module_2_atts );
						$buffy   .= $the_post->display();
					}
				}

				break;

			case '2':
			case '3':
				$buffy .= '<div class="row">';
				foreach ( $query_posts as $post ) {
					$post_count++;

					if ( '5' === $count ) {
						if ( 1 === $post_count || 4 === $post_count ) {
							$buffy .= '<div class="col-sm-3">';
						}
						if ( 3 === $post_count ) {
							$buffy .= '<div class="col-sm-6">';
						}

						if ( 3 === $post_count ) {
							$the_post = new Module_6( $post, $module_6_atts );
							$buffy   .= $the_post->display();
						} else {
							$the_post = new Module_2( $post, $module_2_atts );
							$buffy   .= $the_post->display();
						}

						if ( 2 === $post_count || 3 === $post_count || $total_count === $post_count ) {
							$buffy .= '</div>';
						}
					} else {
						if ( 1 === $post_count ) {
							$buffy   .= '<div class="col-sm-3">';
							$the_post = new Module_2( $post, $module_2_atts );
							$buffy   .= $the_post->display();
							$buffy   .= '</div>';
						} elseif ( 2 === $post_count ) {
							$buffy   .= '<div class="col-sm-6">';
							$the_post = new Module_6( $post, $module_6_atts );
							$buffy   .= $the_post->display();
							$buffy   .= '</div>';
						} elseif ( 3 === $post_count ) {
							$buffy     .= '<div class="col-sm-3">';
							$the_post   = new Module_2( $post, $module_2_atts );
							$buffy     .= $the_post->display();
							$buffy     .= '</div>';
							$post_count = 0;
						}
					}
				}
				$buffy .= '</div>';

				break;

		}

		unset( $query_posts );

		return $buffy;
	}

	public function block_post_number_options() {
		//no post number for grid posts
		return array(
			'type'    => 'select',
			'id'      => 'count',
			'options' => array(
				'3' => '3',
				'5' => '5',
			),
			'heading' => __( 'Fixed count', 'newsy-elements' ),
			'section' => __( 'Filters', 'newsy-elements' ),
		);
	}

	public function block_module_show_parts() {
		return array_merge(
			newsy_get_module_vc_fields( 'module_2', true ),
			newsy_get_module_vc_fields( 'module_6', true )
		);
	}
}
