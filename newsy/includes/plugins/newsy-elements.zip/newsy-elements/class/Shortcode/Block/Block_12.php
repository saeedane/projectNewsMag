<?php

namespace NewsyElements\Shortcode\Block;

use NewsyElements\Module\Module_1_Large;
use NewsyElements\Module\Module_1_Small;
use NewsyElements\Shortcode\BlockAbstract;

/**
 * Newsy Block 12.
 */
class Block_12 extends BlockAbstract {

	public function __construct( $id, $params ) {
		parent::__construct( $id, $params );

		$this->defaults['module_1_large_custom_enabled'] = '';
		$this->defaults['module_1_large_custom_parts']   = '';
		$this->defaults['module_1_small_custom_enabled'] = '';
		$this->defaults['module_1_small_custom_parts']   = '';

		$this->fixed_count = true;
	}


	public function prepare_inner_atts() {
		$count_number = 3;

		$column_number = $this->atts['block_width'];

		if ( 3 === $column_number ) {
			$count_number = 7;
		} elseif ( 2 === $column_number ) {
			$count_number = 5;
		}

		$this->atts['count'] = $count_number;
	}

	/**
	 * Display the inner content of block.
	 *
	 * @param array $atts Attribute of shortcode or ajax action
	 * @param array $query_posts Wp posts
	 *
	 * @return string
	 */
	public function inner( &$atts, $query_posts ) {
		$total_count    = count( $query_posts );
		$post_count     = 0;
		$module_1l_atts = $this->get_module_atts( $atts, 'module_1_large_' );
		$module_1s_atts = $this->get_module_atts( $atts, 'module_1_small_' );

		$buffy = '';
		foreach ( $query_posts as $post ) {
			$post_count++;

			if ( 1 === $post_count ) {
				$the_post = new Module_1_Large( $post, $module_1l_atts );
				$buffy   .= $the_post->display();
			} else {
				if ( 2 === $post_count ) {
					$buffy .= '<div class="ak-block-bottom-posts">';
				}

				$the_post = new Module_1_Small( $post, $module_1s_atts );
				$buffy   .= $the_post->display();

				if ( $total_count === $post_count ) {
					$buffy .= '</div>';
				}
			}
		}

		unset( $query_posts );

		return $buffy;
	}

	public function block_module_show_parts() {
		return array_merge(
			newsy_get_module_vc_fields( 'module_1_large', true ),
			newsy_get_module_vc_fields( 'module_1_small', true )
		);
	}
}
