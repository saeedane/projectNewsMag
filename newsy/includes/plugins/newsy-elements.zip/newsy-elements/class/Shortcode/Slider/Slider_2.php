<?php
namespace NewsyElements\Shortcode\Slider;

use NewsyElements\Module\Module_Grid_Wide;

/**
 * Newsy Slider 2.
 */
class Slider_2 extends SliderAbstract {

	public function __construct( $id, $params ) {
		parent::__construct( $id, $params );

		$this->defaults['gradient']            = 'tg-focus tg-center';
		$this->defaults['grid_height']         = '300';
		$this->defaults['slider_scroll_items'] = '3';
		$this->defaults['slider_nav']          = 'style-3';

		$this->fixed_count = true;
	}

	/**
	 * Display the inner content of block.
	 */
	public function inner( &$atts, $query_posts ) {
		$post_count           = 0;
		$buffy                = '';
		$module_atts          = $this->get_module_atts( $atts );
		$module_atts['class'] = 'ak-slider-item';
		foreach ( $query_posts as $post ) {
			$post_count++;

			$the_post = new Module_Grid_Wide( $post, $module_atts );
			$buffy   .= $the_post->display( $post_count );
		}

		unset( $module_atts, $atts );

		return $buffy;
	}

	public function block_inner_options() {
		return array_merge(
			$this->block_slide_style_options(),
			$this->block_slide_count_options(),
			$this->block_grid_height_options(),
			$this->block_slider_options()
		);
	}

	public function block_module_show_parts() {
		return newsy_get_module_vc_fields( 'module_grid_wide' );
	}

	public function block_design_item_margin_options() {
		return array();
	}
}
