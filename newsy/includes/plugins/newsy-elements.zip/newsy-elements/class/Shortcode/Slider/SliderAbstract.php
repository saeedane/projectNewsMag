<?php

namespace NewsyElements\Shortcode\Slider;

use NewsyElements\Shortcode\BlockAbstract;

/**
 * Newsy Slider Abstract class.
 */
class SliderAbstract extends BlockAbstract {
	public $defaults = array(
		'gradient'                => 'tg-gradient',
		'pagination'              => 'slider',
		'grid_height'             => '',
		'slide_count_desktop'     => '3',
		'slide_count_notebook'    => '3',
		'slide_count_tablet'      => '2',
		'slide_count_mobile'      => '1',
		'slider_count'            => '3',
		'slider_speed'            => '250',
		'slider_autoplay'         => '',
		'slider_autoplay_timeout' => '3000',
		'slider_autoplay_speed'   => '1000',
		'slider_dots'             => '',
		'slider_nav'              => '',
		'slider_item_margin'      => '15',
		'slider_stage_padding'    => '',
		'slider_scroll_items'     => '1',
		'slider_center'           => '',
		'slider_loop'             => '',
	);

	/**
	 * Display the inner content of block.
	 */
	public function render_block_css() {
		$block_id           = $this->atts['block_id'];
		$grid_height        = $this->atts['grid_height'];
		$block_accent_color = $this->atts['block_accent_color'];

		$out = '';

		if ( $this->defaults['grid_height'] !== $grid_height ) {
			$out .= "@media (min-width: 991px) {#{$block_id} .ak-block-posts { height: {$grid_height}px; } }";
		}

		if ( '' !== $block_accent_color ) {
			$out .= "#{$block_id} {--ak-block-accent-color:{$block_accent_color};}";
			$out .= "#{$block_id}.ak-slider-nav-style-1 .tns-controls button { background-color: {$block_accent_color}; }";
			$out .= "#{$block_id}.ak-slider-nav-style-3 .tns-controls button:hover { background-color: {$block_accent_color}; }";
			$out .= "#{$block_id} .tns-nav button.tns-nav-active { background-color: {$block_accent_color}; }";
			$out .= "#{$block_id} .tns-nav button:hover { background-color: {$block_accent_color}; }";
			$out .= "#{$block_id} .ak-slider-nav .tns-nav-active .ak-slider-nav-thumb::after { background-color: {$block_accent_color}; opacity: 0.3; }";
		}

		$out .= $this->inner_css();

			// vc css options
		if ( ! empty( $this->atts['css'] ) && ! is_array( $this->atts['css'] ) ) {
			preg_match( '/{(.*?)}/s', $this->atts['css'], $match );
			if ( isset( $match[1] ) ) {
				$out .= "#{$block_id} { " . $match[1] . ' }';
			}
		}

		if ( empty( $out ) ) {
			return '';
		}

		return "<style scoped>{$out}</style>";
	}

	/**
	 * Handle displaying of shortcode.
	 *
	 * @param array  $this->atts
	 * @param string $content
	 *
	 * @return string
	 */
	public function inner_classes( $classes ) {
		if ( '' !== $this->atts['gradient'] ) {
			$classes[] = esc_attr( $this->atts['gradient'] );
		} else {
			$classes[] = esc_attr( $this->defaults['gradient'] );
		}

		return $classes;
	}

	public function prepare_inner_atts() {
		$this->atts['count'] = ( intval( $this->atts['slide_count_desktop'] ) * intval( $this->atts['slider_count'] ) );

		if ( '15' === $this->atts['slider_item_margin'] && '30' !== $this->atts['item_margin'] ) {
			$this->atts['slider_item_margin'] = $this->atts['item_margin'];
		}
	}

	/**
	 *  Handy function used to add pagination fields array to VC_Map.
	 *
	 * @return array
	 */
	public function block_slide_style_options() {
		return array(
			array(
				'type'             => 'select',
				'heading'          => __( 'Overlay Gradient', 'newsy-elements' ),
				'description'      => __( 'Select slider items overlay style.', 'newsy-elements' ),
				'id'               => 'gradient',
				'admin_label'      => true,
				'options_callback' => 'newsy_get_grid_overlay_styles',
				'section'          => __( 'General', 'newsy-elements' ),
			),
			array(
				'type'        => 'color',
				'heading'     => __( 'Block Color', 'newsy-elements' ),
				'description' => __( 'Block Elements Color', 'newsy-elements' ),
				'id'          => 'block_accent_color',
				'section'     => __( 'General', 'newsy-elements' ),
			),
		);
	}

	/**
	 *  Handy function used to add pagination fields array to VC_Map.
	 *
	 * @return array
	 */
	public function block_slide_count_options() {
		return array(
			array(
				'type'         => 'number',
				'heading'      => __( 'Number of slide (Desktop >1400px)', 'newsy-elements' ),
				'id'           => 'slide_count_desktop',
				'section'      => __( 'Slider', 'newsy-elements' ),
				'block_column' => 2,
			),
			array(
				'type'         => 'number',
				'heading'      => __( 'Number of slide (Notebook >1024px)', 'newsy-elements' ),
				'id'           => 'slide_count_notebook',
				'section'      => __( 'Slider', 'newsy-elements' ),
				'block_column' => 2,
			),
			array(
				'type'         => 'number',
				'heading'      => __( 'Number of slide (Tablet >768px)', 'newsy-elements' ),
				'id'           => 'slide_count_tablet',
				'section'      => __( 'Slider', 'newsy-elements' ),
				'block_column' => 2,
			),
			array(
				'type'         => 'number',
				'heading'      => __( 'Number of slide (Mobile >380px)', 'newsy-elements' ),
				'id'           => 'slide_count_mobile',
				'section'      => __( 'Slider', 'newsy-elements' ),
				'block_column' => 2,
			),
		);
	}

	/**
	 *  Handy function used to add pagination fields array to VC_Map.
	 *
	 * @return array
	 */
	public function block_slider_options() {
		return array(
			array(
				'type'    => 'number',
				'heading' => __( 'Number of slides (Default 3)', 'newsy-elements' ),
				'id'      => 'slider_count',
				'section' => __( 'Slider', 'newsy-elements' ),
			),
			array(
				'id'      => 'slider_speed',
				'type'    => 'number',
				'heading' => __( 'Slider Slide duration (Default 250)', 'newsy-elements' ),
				'section' => __( 'Slider', 'newsy-elements' ),
			),
			array(
				'id'      => 'slider_scroll_items',
				'type'    => 'slider',
				'heading' => __( 'Slider Scroll Items', 'newsy-elements' ),
				'max'     => 250,
				'min'     => 1,
				'section' => __( 'Slider', 'newsy-elements' ),
			),
			array(
				'id'      => 'slider_item_margin',
				'type'    => 'slider',
				'heading' => __( 'Slider Item Margin (Default 15)', 'newsy-elements' ),
				'max'     => 100,
				'section' => __( 'Slider', 'newsy-elements' ),
			),
			array(
				'id'      => 'slider_stage_padding',
				'type'    => 'slider',
				'heading' => __( 'Slider Stage Padding', 'newsy-elements' ),
				'max'     => 500,
				'step'    => 5,
				'section' => __( 'Slider', 'newsy-elements' ),
			),
			array(
				'id'      => 'slider_nav',
				'type'    => 'select',
				'heading' => __( 'Slider Nav', 'newsy-elements' ),
				'section' => __( 'Slider', 'newsy-elements' ),
				'options' => array(
					''        => __( 'Disabled', 'newsy-elements' ),
					'style-1' => sprintf( __( 'Style %s', 'newsy-elements' ), '1' ),
					'style-2' => sprintf( __( 'Style %s', 'newsy-elements' ), '2' ),
					'style-3' => sprintf( __( 'Style %s', 'newsy-elements' ), '3' ),
					'style-4' => sprintf( __( 'Style %s', 'newsy-elements' ), '4' ),
					'style-5' => sprintf( __( 'Style %s', 'newsy-elements' ), '5' ),
				),
			),
			array(
				'id'      => 'slider_dots',
				'type'    => 'select',
				'heading' => __( 'Slider Controls', 'newsy-elements' ),
				'section' => __( 'Slider', 'newsy-elements' ),
				'options' => array(
					''        => __( 'Disabled', 'newsy-elements' ),
					'enabled' => sprintf( __( 'Style %s', 'newsy-elements' ), '1' ), // backward comp
					'style-2' => sprintf( __( 'Style %s', 'newsy-elements' ), '2' ),
					'style-3' => sprintf( __( 'Style %s', 'newsy-elements' ), '3' ),
					'style-4' => sprintf( __( 'Style %s', 'newsy-elements' ), '4' ),
					'style-5' => sprintf( __( 'Style %s', 'newsy-elements' ), '5' ),
				),
			),
			array(
				'id'      => 'slider_autoplay',
				'type'    => 'switcher',
				'heading' => __( 'AutoPlay', 'newsy-elements' ),
				'section' => __( 'Slider', 'newsy-elements' ),
				'options' => array(
					'on'  => 'enabled',
					'off' => 'disabled',
				),
			),
			array(
				'id'         => 'slider_autoplay_timeout',
				'type'       => 'number',
				'heading'    => __( 'AutoPlay Speed  (Default 3000)', 'newsy-elements' ),
				'section'    => __( 'Slider', 'newsy-elements' ),
				'dependency' => array(
					'element' => 'slider_autoplay',
					'value'   => array( 'enabled' ),
				),
			),
			array(
				'id'         => 'slider_autoplay_speed',
				'type'       => 'number',
				'heading'    => __( 'AutoPlay Animation Speed  (Default 1000)', 'newsy-elements' ),
				'section'    => __( 'Slider', 'newsy-elements' ),
				'dependency' => array(
					'element' => 'slider_autoplay',
					'value'   => array( 'enabled' ),
				),
			),
			array(
				'id'      => 'slider_center',
				'type'    => 'switcher',
				'heading' => __( 'Slider Center Mode', 'newsy-elements' ),
				'section' => __( 'Slider', 'newsy-elements' ),
				'options' => array(
					'on'  => 'enabled',
					'off' => '',
				),
			),
			array(
				'id'      => 'slider_loop',
				'type'    => 'switcher',
				'heading' => __( 'Loop Items', 'newsy-elements' ),
				'section' => __( 'Slider', 'newsy-elements' ),
				'options' => array(
					'on'  => 'enabled',
					'off' => '',
				),
			),
		);
	}


	public function block_grid_height_options() {
		return array(
			array(
				'type'        => 'number',
				'heading'     => __( 'Grid Height', 'newsy-elements' ),
				'id'          => 'grid_height',
				'admin_label' => true,
				'section'     => __( 'General', 'newsy-elements' ),
			),
		);
	}

	public function block_pagination_options() {
		//no inner option
		return array();
	}

	public function block_tab_options() {
		//no tabs for grid posts
		return array();
	}
}
