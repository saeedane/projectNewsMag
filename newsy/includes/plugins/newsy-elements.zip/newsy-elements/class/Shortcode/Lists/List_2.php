<?php

namespace NewsyElements\Shortcode\Lists;

use NewsyElements\Shortcode\BlockAbstract;
use NewsyElements\Module\Module_2;

/**
 * Newsy List 2.
 */
class List_2 extends BlockAbstract {

	public function prepare_inner_atts() {
		/*
		if ( $this->defaults['count'] == $this->atts['count'] ) {
			$block_width = intval( $this->atts['block_width'] );

			if ( 2 == $block_width ) {
				$this->atts['count'] = 4;
			} elseif ( 3 == $block_width ) {
				$this->atts['count'] = 6;
			}
		}*/
	}

	/**
	 * Display the inner content of block.
	 *
	 * @param array $atts Attribute of shortcode or ajax action
	 * @param array $query_posts Wp posts
	 *
	 * @return string
	 */
	public function inner( &$atts, $query_posts ) {
		$module_atts = $this->get_module_atts( $atts );

		$buffy      = '';
		$post_count = 0;

		foreach ( $query_posts as $post ) {
			$post_count++;

			$the_post = new Module_2( $post, $module_atts );
			$buffy   .= $the_post->display();
		}

		unset( $module_atts, $query_posts );

		return $buffy;
	}

	public function block_design_inner_options() {
		return array(
			array(
				'type'        => 'select',
				'heading'     => __( 'Columns', 'newsy-elements' ),
				'id'          => 'block_width',
				'admin_label' => true,
				'options'     => array(
					''  => __( 'Auto Column', 'newsy-elements' ),
					'2' => __( '2 Columns', 'newsy-elements' ),
					'3' => __( '3 Columns', 'newsy-elements' ),
					'4' => __( '4 Columns', 'newsy-elements' ),
					'5' => __( '5 Columns', 'newsy-elements' ),
				),
				'section'     => __( 'Design', 'newsy-elements' ),
			),
		);
	}

	public function block_module_show_parts() {
		return newsy_get_module_vc_fields( 'module_2' );
	}
}
