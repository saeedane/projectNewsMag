<?php

namespace NewsyElements\Shortcode\Lists;

use NewsyElements\Shortcode\BlockAbstract;
use NewsyElements\Module\Module_2;
use NewsyElements\Module\Module_5;

/**
 * Newsy List 13.
 */
class List_13 extends BlockAbstract {

	public function __construct( $id, $params ) {
		parent::__construct( $id, $params );
		$this->defaults['count']                   = '5';
		$this->defaults['module_2_custom_enabled'] = '';
		$this->defaults['module_2_custom_parts']   = '';
		$this->defaults['module_5_custom_enabled'] = '';
		$this->defaults['module_5_custom_parts']   = '';
	}

	/**
	 * Display the inner content of block.
	 *
	 * @param array $atts Attribute of shortcode or ajax action
	 * @param array $query_posts Wp posts
	 *
	 * @return string
	 */
	public function inner( &$atts, $query_posts ) {
		$total_count = count( $query_posts );
		$post_count  = 0;
		$buffy       = '';

		foreach ( $query_posts as $post ) {
			$post_count++;

			if ( 1 == $post_count ) {
				$the_post = new Module_5( $post, $this->get_module_atts( $atts, 'module_5_' ) );
				$buffy   .= $the_post->display();
			} else {
				$the_post = new Module_2( $post, $this->get_module_atts( $atts, 'module_2_' ) );
				$buffy   .= $the_post->display();
			}
		}

		unset( $query_posts );

		return $buffy;
	}

	public function block_module_show_parts() {
		return array_merge(
			newsy_get_module_vc_fields( 'module_5', true ),
			newsy_get_module_vc_fields( 'module_2', true )
		);
	}
}
