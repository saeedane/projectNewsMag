<?php
namespace NewsyElements\Shortcode\Lists;

use NewsyElements\Shortcode\BlockAbstract;
use NewsyElements\Module\Module_1_Small_Square;

/**
 * Newsy List 1 Small Square.
 */
class List_1_Small_Square extends BlockAbstract {

	/**
	 * Display the inner content of block.
	 *
	 * @param array $atts Attribute of shortcode or ajax action
	 * @param array $query_posts Wp posts
	 *
	 * @return string
	 */
	public function inner( &$atts, $query_posts ) {
		$module_atts = $this->get_module_atts( $atts );

		$buffy      = '';
		$post_count = 0;

		foreach ( $query_posts as $post ) {
			$post_count++;

			$the_post = new Module_1_Small_Square( $post, $module_atts );
			$buffy   .= $the_post->display();
		}

		unset( $module_atts, $query_posts );

		return $buffy;
	}

	public function block_module_show_parts() {
		return newsy_get_module_vc_fields( 'module_1_small_square' );
	}
}
