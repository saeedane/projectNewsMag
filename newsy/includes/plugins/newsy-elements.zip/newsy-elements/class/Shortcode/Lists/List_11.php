<?php

namespace NewsyElements\Shortcode\Lists;

use NewsyElements\Shortcode\BlockAbstract;
use NewsyElements\Module\Module_1_Medium;
use NewsyElements\Module\Module_5;

/**
 * Newsy List 11.
 */
class List_11 extends BlockAbstract {

	public function __construct( $id, $params ) {
		parent::__construct( $id, $params );

		$this->defaults['count']                          = '10';
		$this->defaults['module_5_custom_enabled']        = '';
		$this->defaults['module_5_custom_parts']          = '';
		$this->defaults['module_1_medium_custom_enabled'] = '';
		$this->defaults['module_1_medium_custom_parts']   = '';
	}

		/**
	 * Display the inner content of block.
	 *
	 * @param array $atts Attribute of shortcode or ajax action
	 * @param array $query_posts Wp posts
	 *
	 * @return string
	 */
	public function inner( &$atts, $query_posts ) {
		$module_atts = $this->get_module_atts( $atts );

		$buffy         = '';
		$post_count    = 0;
		$column_number = 5;

		foreach ( $query_posts as $post ) {
			$post_count++;

			switch ( $post_count ) {
				case '1':
					$the_post = new Module_5( $post, $this->get_module_atts( $atts, 'module_5_' ) );
					$buffy   .= $the_post->display();
					break;

				default: //second column
					$the_post = new Module_1_Medium( $post, $this->get_module_atts( $atts, 'module_1_medium_' ) );
					$buffy   .= $the_post->display();
					break;
			}

			//reset post count if post reach max post number for column
			if ( $post_count == $column_number ) {
				$post_count = 0;
			}
		}
		unset( $module_atts, $query_posts );

		return $buffy;
	}

	public function block_module_show_parts() {
		return array_merge(
			newsy_get_module_vc_fields( 'module_5', true ),
			newsy_get_module_vc_fields( 'module_1_medium', true )
		);
	}
}
