<?php

namespace NewsyElements\Shortcode\Grid;

use NewsyElements\Shortcode\BlockAbstract;

/**
 * Newsy Grid Abstract class.
 */
class GridAbstract extends BlockAbstract {

	public function __construct( $id, $params ) {
		parent::__construct( $id, $params );

		$this->defaults['gradient']    = 'tg-gradient tg-focus';
		$this->defaults['item_margin'] = '5';

		$this->fixed_count = true;
	}

	/**
	 * Display the inner content of block.
	 */
	public function inner_css() {
		$block_id    = $this->atts['block_id'];
		$grid_height = $this->atts['grid_height'];

		$out = '';

		if ( $this->defaults['grid_height'] !== $grid_height ) {
			$out .= "@media (min-width: 992px) {#{$block_id} .ak-block-posts { height: {$grid_height}px; } }";
		}

		return $out;
	}

	/**
	 * Handle displaying of shortcode.
	 *
	 * @param array  $this->atts
	 * @param string $content
	 *
	 * @return string
	 */
	public function inner_classes( $classes ) {
		if ( '' !== $this->atts['gradient'] ) {
			$classes[] = esc_attr( $this->atts['gradient'] );
		} else {
			$classes[] = esc_attr( $this->defaults['gradient'] );
		}

		return $classes;
	}

	public function block_inner_options() {
		//no inner option for grid posts
		return array(
			array(
				'type'             => 'select',
				'heading'          => __( 'Overlay Gradient', 'newsy-elements' ),
				'description'      => __( 'Select slider items overlay style.', 'newsy-elements' ),
				'id'               => 'gradient',
				'admin_label'      => true,
				'options_callback' => 'newsy_get_grid_overlay_styles',
				'section'          => __( 'General', 'newsy-elements' ),
			),
			array(
				'type'        => 'number',
				'heading'     => __( 'Grid Height', 'newsy-elements' ),
				'id'          => 'grid_height',
				'admin_label' => true,
				'section'     => __( 'General', 'newsy-elements' ),
			),
		);
	}


	public function block_pagination_options() {
		//no inner option
		return array();
	}

	public function block_tab_options() {
		//no tabs for grid posts
		return array();
	}
}
