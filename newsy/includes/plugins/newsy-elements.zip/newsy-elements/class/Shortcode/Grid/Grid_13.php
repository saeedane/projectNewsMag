<?php

namespace NewsyElements\Shortcode\Grid;

use NewsyElements\Module\Module_Grid_Big;
use NewsyElements\Module\Module_Grid_Small;

/**
 * Newsy Grid 13.
 */
class Grid_13 extends GridAbstract {

	public function __construct( $id, $params ) {
		parent::__construct( $id, $params );

		$this->defaults['count']       = '5';
		$this->defaults['grid_height'] = '600';
	}

	/**
	 * Display the inner content of block.
	 *
	 * @param array $atts Attribute of shortcode or ajax action
	 * @param array $query_posts Wp posts
	 *
	 * @return string
	 */
	public function inner( &$atts, $query_posts ) {
		$post_count = 0;
		$post_total = count( $query_posts );
		$buffy      = '';

		foreach ( $query_posts as $post ) {
			$post_count++;

			switch ( $post_count ) {
				case '1':
				case '2':
					$the_post = new Module_Grid_Big( $post );
					$buffy   .= $the_post->display( $post_count );
					break;

				case '3':
				case '4':
				case '5':
					$the_post = new Module_Grid_Small( $post );
					$buffy   .= $the_post->display( $post_count );
					break;
			}

			if ( 7 == $post_count || $post_count == $post_total ) {
				$post_count = 0;
			}
		}
		unset( $query_posts );

		return $buffy;
	}
}
