<?php

namespace NewsyElements\Shortcode\Grid;

use NewsyElements\Module\Module_Grid_Small;

/**
 * Newsy Grid 7.
 */
class Grid_7 extends GridAbstract {

	public function __construct( $id, $params ) {
		parent::__construct( $id, $params );

		$this->defaults['count']       = '4';
		$this->defaults['grid_height'] = '300';
	}

	/**
	 * Display the inner content of block.
	 *
	 * @param array $atts Attribute of shortcode or ajax action
	 * @param array $query_posts Wp posts
	 *
	 * @return string
	 */
	public function inner( &$atts, $query_posts ) {
		$post_count  = 0;
		$module_atts = $this->get_module_atts( $atts );
		$buffy       = '';

		foreach ( $query_posts as $post ) {
			$post_count++;

			$the_post = new Module_Grid_Small( $post, $module_atts );
			$buffy   .= $the_post->display( $post_count );
		}

		unset( $query_posts );

		return $buffy;
	}


	public function block_module_show_parts() {
		return newsy_get_module_vc_fields( 'module_grid_small' );
	}
}
