<?php
namespace NewsyElements\Module;

/**
 * Class Module_1_Medium.
 */
class Module_1_Medium extends ModuleAbstract {

	public $module_id = 'module_1_medium';

	public $module_class = 'ak-module-1-medium';

	public $module_image = 'newsy_350x250';

	public $show_video_duration = true;


	public function display() {
		ob_start(); ?>
		<article class="<?php echo esc_attr( $this->get_module_classes() ); ?>">
			<div class="ak-module-inner clearfix">
				<div class="ak-module-featured">
					<?php
					$this->get_badge_icon();
					$this->get_featured_image();
					$this->get_category();
					?>
				</div>
				<div class="ak-module-details">
					<?php
					$this->get_category( 'inline' );
					$this->get_title( 55 );
					$this->get_excerpt( 100 );
					$this->get_meta();
					?>
				</div>
			</div>
		</article>
		<?php
		return ob_get_clean();
	}
}
