<?php
namespace NewsyElements\Module;

/**
 * Class Module_1_Small.
 */
class Module_1_Small extends ModuleAbstract {

	public $module_id = 'module_1_small';

	public $module_class = 'ak-module-1-small ak-column-module';

	public $module_image = 'newsy_120x86';

	public function display() {
		ob_start(); ?>
		<article class="<?php echo esc_attr( $this->get_module_classes() ); ?>">
			<div class="ak-module-inner clearfix">
				<div class="ak-module-featured">
					<?php $this->get_featured_image(); ?>
				</div>
				<div class="ak-module-details">
					<?php
					$this->get_title( 55, 'h3' );
					$this->get_meta();
					?>
				</div>
			</div>
		</article>
		<?php
		return ob_get_clean();
	}
}
