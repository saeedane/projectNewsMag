<?php
namespace NewsyElements\Module;

/**
 * Class Module_11.
 */
class Module_11 extends ModuleAbstract {

	public $module_id = 'module_11';

	public $module_class = 'ak-module-11';

	public $module_image = 'newsy_750x0';

	public $show_thumb_placeholder = false;

	public function display() {
		ob_start(); ?>
		<article class="<?php echo esc_attr( $this->get_module_classes() ); ?>">
			<div class="ak-module-inner clearfix">
				<div class="ak-module-left ">
					<?php echo $this->get_voting(); ?>
				</div>
				<div class="ak-module-top">
					<?php $this->get_category( 'inline' ); ?>

					<?php $this->get_badge_icon(); ?>
				</div>
				<?php $this->get_title(); ?>
				<div class="ak-module-featured clearfix">
				<?php $this->get_featured_image( '', false, true, true, true ); ?>
				</div>
				<div class="ak-module-details">
					<?php $this->get_meta(); ?>

					<div class="ak-module-bottom clearfix">
						<?php echo $this->get_meta_bottom(); ?>
					</div>
				</div>
			</div>
		</article>
		<?php
		return ob_get_clean();
	}

	public function get_voting() {
		if ( ! class_exists( '\Newsy_Voting' ) ) {
			return '';
		}
		$instance   = \Newsy_Voting::get_instance();
		$instance_h = \Newsy_Voting_Hooks::get_instance();
		$status     = $instance->get_status( $this->post->ID );

		$is_voted = '';
		if ( '1' === $status ) {
			$is_voted = 'post-voted up-voted';
		} elseif ( '-1' === $status ) {
			$is_voted = 'post-voted down-voted';
		}

		$up_btn   = $instance_h->get_up_btn( $this->post->ID, false );
		$down_btn = '';
		if ( 'yes' !== newsy_get_option( 'post_voting_single' ) ) {
			$down_btn = $instance_h->get_down_btn( $this->post->ID, false );
		}

		$vote_count = $instance->get_average_count( $this->post->ID );

		$avg_count = sprintf( '<span class="ak-voting-count"><span class="counts">%s</span></span>', $vote_count );

		$output =
			"<div class='ak-post-voting {$is_voted} clearfix'>
				{$up_btn}
				{$avg_count}
                {$down_btn}
            </div>";

		return $output;
	}

	public function get_meta_bottom() {
		if ( ! class_exists( '\Newsy_Social_Share' ) || ! function_exists( 'newsy_get_option' ) ) {
			return '';
		}

		$sites            = newsy_get_option( 'module_social_share_sites', 'facebook,twitter,pinterest' );
		$share_style      = newsy_get_option( 'module_social_share_style', 'style-2' );
		$share_count_type = newsy_get_option( 'module_social_share_count', 'each' );
		$share_show_count = newsy_get_option( 'module_social_share_show_count', 2 );

		return \Newsy_Social_Share::get_instance()->get_share_buttons( $sites, $this->post->ID, $share_style, $share_count_type, $share_show_count );
	}
}
