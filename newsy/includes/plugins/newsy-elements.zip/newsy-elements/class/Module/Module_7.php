<?php
namespace NewsyElements\Module;

/**
 * Class Module_7.
 */
class Module_7 extends ModuleAbstract {

	public $module_id = 'module_7';

	public $module_class = 'ak-module-7';

	public $module_image = 'newsy_750x375';

	public function display() {
		ob_start(); ?>
		<article class="<?php echo esc_attr( $this->get_module_classes() ); ?>">
			<div class="ak-module-inner clearfix">
				<div class="ak-module-featured clearfix">
					<?php $this->get_badge_icon(); ?>
					<?php $this->get_featured_image(); ?>
				</div>
				<div class="ak-module-details">
					<?php $this->get_category( 'inline' ); ?>

					<?php $this->get_title(); ?>

					<?php $this->get_meta(); ?>

					<?php $this->get_excerpt( 180 ); ?>

					<div class="ak-module-bottom clearfix">
						<?php $this->get_meta_bottom(); ?>
					</div>
				</div>
			</div>
		</article>
		<?php
		return ob_get_clean();
	}
}
