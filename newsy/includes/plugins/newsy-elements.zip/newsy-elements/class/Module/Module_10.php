<?php
namespace NewsyElements\Module;

/**
 * Class Module_10.
 */
class Module_10 extends ModuleAbstract {

	public $module_id = 'module_10';

	public $module_class = 'ak-module-10 ak-column-module';

	public function display() {
		ob_start(); ?>
		<article class="<?php echo esc_attr( $this->get_module_classes() ); ?>">
			<div class="ak-module-inner clearfix">
				<div class="ak-module-details">
					<?php $this->get_category( 'inline' ); ?>

					<?php $this->get_title( '', 'h3' ); ?>

					<?php $this->get_excerpt( 180 ); ?>

					<?php $this->get_meta(); ?>
				</div>
			</div>
		</article>
		<?php
		return ob_get_clean();
	}
}
