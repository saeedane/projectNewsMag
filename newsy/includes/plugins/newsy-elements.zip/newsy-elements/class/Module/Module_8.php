<?php
namespace NewsyElements\Module;

/**
 * Class Module_8.
 */
class Module_8 extends ModuleAbstract {

	public $module_id = 'module_8';

	public $module_class = 'ak-module-8';

	public $module_image = 'newsy_750x375';

	public $show_thumb_placeholder = false;

	public function display() {
		ob_start(); ?>
		<article class="<?php echo esc_attr( $this->get_module_classes() ); ?>">
			<div class="ak-module-inner clearfix">
				<?php $this->get_badge_icon(); ?>
				<?php $this->get_category( 'inline' ); ?>

				<?php $this->get_title(); ?>

				<?php $this->get_meta(); ?>

				<div class="ak-module-featured clearfix">
					<?php $this->get_featured_image( '', false, true, true, true ); ?>
				</div>
				<div class="ak-module-details clearfix">
					<?php $this->get_excerpt( 280 ); ?>
				</div>

				<div class="ak-module-bottom clearfix">
					<?php $this->get_meta_bottom(); ?>
				</div>
			</div>
		</article>
		<?php
		return ob_get_clean();
	}
}
