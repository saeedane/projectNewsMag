<?php
namespace NewsyElements\Module;

/**
 * Class Module_4.
 */
class Module_4 extends ModuleAbstract {

	public $module_id = 'module_4';

	public $module_class = 'ak-module-4 ak-column-module';

	public $module_image        = 'newsy_350x250';
	public $show_video_duration = true;

	public function display() {
		ob_start(); ?>
		<article class="<?php echo esc_attr( $this->get_module_classes() ); ?>">
			<div class="ak-module-inner clearfix">
				<div class="ak-module-featured">
					<?php $this->get_badge_icon(); ?>

					<?php $this->get_featured_image(); ?>

					<?php $this->get_category(); ?>
				</div>
				<div class="ak-module-details">
					<?php $this->get_category( 'inline' ); ?>

					<?php $this->get_title( '', 'h3' ); ?>

					<?php $this->get_meta(); ?>

					<?php $this->get_excerpt( 95 ); ?>
				</div>
			</div>
		</article>
		<?php
		return ob_get_clean();
	}
}
