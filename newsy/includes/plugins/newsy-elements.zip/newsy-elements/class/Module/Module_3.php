<?php

namespace NewsyElements\Module;

/**
 * Class Module_3.
 */
class Module_3 extends ModuleAbstract {

	public $module_id = 'module_3';

	public $module_class = 'ak-module-3 ak-column-module';

	public $module_image = 'newsy_350x250';

	public $show_video_duration = true;

	public function display( $image_size = '' ) {
		ob_start(); ?>
		<article class="<?php echo esc_attr( $this->get_module_classes() ); ?>">
			<div class="ak-module-inner clearfix">
				<div class="ak-module-grid-wrap">
					<div class="ak-module-featured">
						<?php
						$this->get_badge_icon();
						$this->get_featured_image( $image_size );
						$this->get_category();
						?>
					</div>
					<div class="ak-module-details">
						<?php
						$this->get_category( 'inline' );
						$this->get_title();
						$this->get_meta();
						?>
					</div>
				</div>
			</div>
		</article>
		<?php
		return ob_get_clean();
	}
}
