<?php
namespace NewsyElements\Module;

/**
 * Class Module_Grid_Big.
 */
class Module_Grid_Big extends ModuleAbstract {

	public $module_id = 'module_grid_big';

	public $module_class = 'ak-module-grid ak-module-grid-big';

	public $module_image = 'newsy_750x536';

	public function display( $order_no ) {
		ob_start(); ?>
		<article class="<?php echo esc_attr( $this->get_module_classes( array( 'ak-block-item-' . $order_no ) ) ); ?>">
			<div class="ak-module-inner clearfix">
				<div class="ak-module-grid-wrap">
					<div class="ak-module-featured">
					<?php $this->get_badge_icon( true ); ?>
					<?php $this->get_category(); ?>
					<?php $this->get_featured_image( '', true ); ?>
					</div>
					<div class="ak-module-details">
						<?php $this->get_category( 'inline' ); ?>
						<?php $this->get_title(); ?>
						<?php $this->get_meta(); ?>
					</div>
				</div>
			</div>
		</article>
		<?php
		return ob_get_clean();
	}
}
