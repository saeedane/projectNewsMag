Change Log :

== 1.0.2 ==
- [NEW] Plugin translation

== 1.0.1 ==
- [FIX] Issue on video player

== 1.0.0 ==
- First Release
