<?php

$fields[] = array(
	'heading' => esc_html__( 'Newsy Theme Options', 'newsy' ),
	'id'      => NEWSY_THEME_OPTIONS,
	'type'    => 'panel',
	'icon'    => 'fa-globe',
	'file'    => NEWSY_THEME_PATH . 'includes/options/theme-panel/theme-options.php',
);
