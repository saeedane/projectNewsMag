<?php
/*
Plugin Name:    BuzzEditor Post Importer
Plugin URI:     http://themeforest.net/user/akbilisim
Description:    BuzzEditor Post Importer is a plugin that allows you to import trivia quizzes, personality quizzes, checklist quizzes, and polls from BuzzFeed.
Author:         akbilisim
Version:        2.0.0
Author URI:     http://akbilisim.com
Text Domain:    buzzeditor-post-importer
*/

define( 'BUZZEDITOR_POST_IMPORTER_PATH', plugin_dir_path( __FILE__ ) );
define( 'BUZZEDITOR_POST_IMPORTER_URI', plugin_dir_url( __FILE__ ) );
define( 'BUZZEDITOR_POST_IMPORTER_VERSION', '2.0.0' );

require_once 'class.buzzeditor-post-importer-hooks.php';

BuzzEditor_Post_Importer_Hooks::get_instance();

