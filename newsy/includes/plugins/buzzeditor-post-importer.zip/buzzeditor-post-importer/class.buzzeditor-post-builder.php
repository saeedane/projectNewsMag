<?php
/**
 * Used for retrieving social data from social sites and caching them
 */
class BuzzEditor_Post_Builder {

	/**
	 * Contain live instance object class
	 *
	 * @var BuzzEditor_Post_Builder
	 */
	private static $instance;

	/**
	 * Cached value for counts
	 *
	 * @var array
	 */
	private $templates = array();

	/**
	 * @return BuzzEditor_Post_Builder
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
			static::$instance->set_templates();
		}
		return static::$instance;
	}

	private function set_templates() {
		if ( empty( $this->templates ) ) {
			$this->templates = array(
				'cover'          => ak_get_local_file_content( BUZZEDITOR_POST_IMPORTER_PATH . 'template/_cover.txt' ),
				'cover_no_title' => ak_get_local_file_content( BUZZEDITOR_POST_IMPORTER_PATH . 'template/_cover_no_title.txt' ),
				'cover_no_image' => ak_get_local_file_content( BUZZEDITOR_POST_IMPORTER_PATH . 'template/_cover_no_image.txt' ),
				'cover_empty'    => ak_get_local_file_content( BUZZEDITOR_POST_IMPORTER_PATH . 'template/_cover_empty.txt' ),
				'personality'    => array(
					'p'   => ak_get_local_file_content( BUZZEDITOR_POST_IMPORTER_PATH . 'template/personality.txt' ),
					'pqs' => ak_get_local_file_content( BUZZEDITOR_POST_IMPORTER_PATH . 'template/personality-questions.txt' ),
					'pq'  => ak_get_local_file_content( BUZZEDITOR_POST_IMPORTER_PATH . 'template/personality-question.txt' ),
					'pas' => ak_get_local_file_content( BUZZEDITOR_POST_IMPORTER_PATH . 'template/personality-answers.txt' ),
					'pa'  => ak_get_local_file_content( BUZZEDITOR_POST_IMPORTER_PATH . 'template/personality-answer.txt' ),
					'prs' => ak_get_local_file_content( BUZZEDITOR_POST_IMPORTER_PATH . 'template/personality-results.txt' ),
					'pr'  => ak_get_local_file_content( BUZZEDITOR_POST_IMPORTER_PATH . 'template/personality-result.txt' ),
				),
				'trivia'         => array(
					'p'   => ak_get_local_file_content( BUZZEDITOR_POST_IMPORTER_PATH . 'template/trivia.txt' ),
					'pqs' => ak_get_local_file_content( BUZZEDITOR_POST_IMPORTER_PATH . 'template/trivia-questions.txt' ),
					'pq'  => ak_get_local_file_content( BUZZEDITOR_POST_IMPORTER_PATH . 'template/trivia-question.txt' ),
					'pas' => ak_get_local_file_content( BUZZEDITOR_POST_IMPORTER_PATH . 'template/trivia-answers.txt' ),
					'pa'  => ak_get_local_file_content( BUZZEDITOR_POST_IMPORTER_PATH . 'template/trivia-answer.txt' ),
					'prs' => ak_get_local_file_content( BUZZEDITOR_POST_IMPORTER_PATH . 'template/trivia-results.txt' ),
					'pr'  => ak_get_local_file_content( BUZZEDITOR_POST_IMPORTER_PATH . 'template/trivia-result.txt' ),
				),
				'checklist'      => array(
					'p'   => ak_get_local_file_content( BUZZEDITOR_POST_IMPORTER_PATH . 'template/checklist.txt' ),
					'pqs' => ak_get_local_file_content( BUZZEDITOR_POST_IMPORTER_PATH . 'template/checklist-questions.txt' ),
					'pq'  => ak_get_local_file_content( BUZZEDITOR_POST_IMPORTER_PATH . 'template/checklist-question.txt' ),
					'pas' => ak_get_local_file_content( BUZZEDITOR_POST_IMPORTER_PATH . 'template/checklist-answers.txt' ),
					'pa'  => ak_get_local_file_content( BUZZEDITOR_POST_IMPORTER_PATH . 'template/checklist-answer.txt' ),
					'prs' => ak_get_local_file_content( BUZZEDITOR_POST_IMPORTER_PATH . 'template/checklist-results.txt' ),
					'pr'  => ak_get_local_file_content( BUZZEDITOR_POST_IMPORTER_PATH . 'template/checklist-result.txt' ),
				),
				'poll'           => array(
					'p'   => ak_get_local_file_content( BUZZEDITOR_POST_IMPORTER_PATH . 'template/poll.txt' ),
					'pqs' => ak_get_local_file_content( BUZZEDITOR_POST_IMPORTER_PATH . 'template/poll-questions.txt' ),
					'pq'  => ak_get_local_file_content( BUZZEDITOR_POST_IMPORTER_PATH . 'template/poll-question.txt' ),
					'pas' => ak_get_local_file_content( BUZZEDITOR_POST_IMPORTER_PATH . 'template/poll-answers.txt' ),
					'pa'  => ak_get_local_file_content( BUZZEDITOR_POST_IMPORTER_PATH . 'template/poll-answer.txt' ),
				),
			);
		}
	}

	public function run( $data ) {
		$template = '';

		foreach ( $data as $_data ) {
			$template .= $this->init_data( $_data );
		}

		return $template;
	}

	public function init_data( $data ) {
		$id        = $data['id'];
		$type      = $data['type'];
		$questions = $data['questions'];
		$results   = $data['results'];

		if ( empty( $id ) || empty( $type ) || empty( $questions ) ) {
			return '';
		}

		$template  = '';
		$templates = $this->templates[ $type ];

		if ( $questions ) {
			$pq_template = '';
			foreach ( $questions as $question ) {

				$pas_template = '';
				if ( $question['answers'] ) {
					foreach ( $question['answers'] as $answer ) {
						$qaid = 'ak-quiz-post-' . $id . '-q' . $question['id'] . '-a' . $answer['id'];

						$pas_template .= str_replace(
							array(
								'<%=id%>',
								'<%=cover%>',
								'<%=title%>',
								'<%=mediaCredit%>',
							), array(
								$qaid,
								$this->get_cover( $qaid, $answer, $question['answers_col'] ),
								$answer['title'],
								$answer['image_credit'],
							), $templates['pa']
						);

						if ( 'personality' === $type ) {
							$pas_template = str_replace(
								array(
									'<%=result%>',
								), array(
									'ak-quiz-post-' . $id . '-r' . $answer['result'],
								), $pas_template
							);
						} elseif ( 'trivia' === $type ) {
							$pas_template = str_replace(
								array(
									'<%=result%>',
								), array(
									$answer['result'],
								), $pas_template
							);
						}
					}

					$pas_template = str_replace(
						array(
							'<%=id%>',
							'<%=col%>',
							'<%=answers%>',
						),
						array(
							'ak-quiz-post-' . $id . '-q' . $question['id'] . '-a',
							$question['answers_col'],
							$pas_template,
						),
						$templates['pas']
					);
				}

				$qid = 'ak-quiz-post-' . $id . '-q' . $question['id'];

				$pq_template .= str_replace(
					array(
						'<%=id%>',
						'<%=heading%>',
						'<%=cover%>',
						'<%=answers%>',
						'<%=reveal_head%>',
						'<%=reveal_desc%>',
					), array(
						$qid,
						$question['heading'],
						$this->get_cover( $qid, $question ),
						$pas_template,
						$question['reveal_head'],
						$question['reveal_desc'],
					), $templates['pq']
				);
			}

			$template .= str_replace( '<%=questions%>', $pq_template, $templates['pqs'] );
		}

		if ( $results ) {
			$pr_template = '';
			foreach ( $results as $result ) {
				$prid = 'ak-quiz-post-' . $id . '-r' . $result['id'];

				$pr_template .= str_replace(
					array(
						'<%=id%>',
						'<%=heading%>',
						'<%=cover%>',
						'<%=description%>',
					), array(
						$prid,
						$result['heading'],
						$this->get_cover( $prid, $result ),
						$result['description'],
					), $templates['pr']
				);

				if ( 'trivia' === $type || 'checklist' === $type ) {
					$pr_template = str_replace(
						array(
							'<%=rangeMin%>',
							'<%=rangeMax%>',
						), array(
							$result['rangeMin'],
							$result['rangeMax'],
						), $pr_template
					);
				}
			}

			$template .= str_replace( '<%=results%>', $pr_template, $templates['prs'] );

			if ( 'checklist' === $type ) {
				$template = str_replace(
					array(
						'<%=result_verb%>',
						'<%=result_subject%>',
						'<%=result_title_text%>',
						'<%=result_share_text%>',
					), array(
						$data['metadata']['result_verb'],
						$data['metadata']['result_subject'],
						sprintf(
							__( 'You %1$s <b>#</b> out of <span>#</span> %2$s', 'buzzeditor' ),
							$data['metadata']['result_verb'],
							$data['metadata']['result_subject']
						),
						sprintf(
							__( 'I %1$s <b>#</b> out of <span>#</span> %2$s', 'buzzeditor' ),
							$data['metadata']['result_verb'],
							$data['metadata']['result_subject']
						),
					), $template
				);
			}
		}

		return str_replace( array( '<%=id%>', '<%=slot%>' ), array( 'ak-quiz-post-' . $id, $template ), $templates['p'] );
	}

	/**
	 * get cover parse
	 *
	 * @param [type] $id
	 * @param [type] $item
	 * @return string
	 */
	public function get_cover( $id, $item, $answers_col = 'col-3' ) {

		if ( ! empty( $item['image'] ) && ! empty( $item['cover_overlay'] ) && $item['cover_overlay'] ) {
			$template = $this->templates['cover'];
		} elseif ( ! empty( $item['cover_overlay'] ) && $item['cover_overlay'] ) {
			$template = $this->templates['cover_no_image'];
		} elseif ( ! empty( $item['image'] ) ) {
			$template = $this->templates['cover_no_title'];
		} else {
			$template = $this->templates['cover_empty'];
		}

		$image_height  = ! empty( $item['image_height'] ) ? $item['image_height'] : '400';
		$overlay_color = ! empty( $item['cover_overlay_color'] ) ? ',"customOverlayColor":"' . $item['cover_overlay_color'] . '"' : ',"gradient":"vivid-cyan-blue-to-vivid-purple"';
		$overlay_class = ! empty( $item['cover_overlay_color'] ) ? ' has-background-dim' : ' has-background-dim has-background-gradient has-vivid-cyan-blue-to-vivid-purple-gradient-background';

		if ( 'answer' === $image_height ) {
			$image_height   = ! empty( $answers_col ) && 'col-3' === $answers_col ? '190' : '245';
			$overlay_color .= ',"className":"be-answer-image"';
			$overlay_class .= ' be-answer-image';
		}

		return str_replace(
			array(
				'<%=coverText%>',
				'<%=mediaID%>',
				'<%=mediaURL%>',
				'<%=minHeight%>',
				'<%=overlayColor%>',
				'<%=overlayStyle%>',
				'<%=overlayClass%>',
				'<%=textColor%>',
				'<%=textStyle%>',
				'<%=textClass%>',
				'<%=textSize%>',
			), array(
				$item['cover_text'],
				! empty( $item['image'] ) ? "%%{$id}%%" : '',
				! empty( $item['image'] ) ? "%attachment_url%{$id}%attachment_url%" : '',
				$image_height,
				$overlay_color,
				! empty( $item['cover_overlay_color'] ) ? 'background-color:' . $item['cover_overlay_color'] . ';' : '',
				$overlay_class,
				! empty( $item['cover_text_color'] ) ? ',"color":{"text":"' . $item['cover_text_color'] . '"}' : '',
				! empty( $item['cover_text_color'] ) ? 'color:' . $item['cover_text_color'] . ';' : '',
				! empty( $item['cover_text_color'] ) ? ' has-text-color' : '',
				! empty( $item['cover_text_size'] ) ? $item['cover_text_size'] : '40',
			), $template
		);
	}
}
