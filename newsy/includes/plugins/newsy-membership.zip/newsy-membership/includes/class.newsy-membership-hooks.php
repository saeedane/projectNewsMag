<?php

/**
 * @author akbilisim
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Newsy_Membership_Hooks {
	/**
	 * @var Newsy_Membership_Hooks
	 */
	private static $instance;

	/**
	 * @return Newsy_Membership_Hooks
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}

		return static::$instance;
	}

	public function __construct() {
		add_filter( 'swpm_not_logged_in_post_msg', array( $this, 'restrict_box' ) );
		add_filter( 'swpm_not_logged_in_more_tag_msg', array( $this, 'restrict_box' ) );
		add_filter( 'swpm_restricted_post_msg', array( $this, 'restrict_level_box' ) );
		add_filter( 'swpm_restricted_more_tag_msg', array( $this, 'restrict_level_box' ) );
		add_filter( 'swpm_account_expired_msg', array( $this, 'restrict_renewal_box' ) );
		add_filter( 'swpm_account_expired_more_tag_msg', array( $this, 'restrict_renewal_box' ) );
		if ( class_exists( 'SwpmSettings' ) ) {
			add_filter( 'newsy_module_classes', array( $this, 'add_module_classes' ), 10, 3 );
			add_filter( 'post_class', array( $this, 'add_classes' ), 10, 3 );
		}
	}

	/**
	 * @param $error_msg
	 *
	 * @return string
	 */
	public function restrict_box( $error_msg ) {
		$login_url  = \SwpmSettings::get_instance()->get_value( 'login-page-url' );
		$joinus_url = \SwpmSettings::get_instance()->get_value( 'join-us-page-url' );

		if ( empty( $login_url ) || empty( $joinus_url ) ) {
			return '<p class="error">The login page or the join us page URL is missing in the settings configuration.</p>';
		}

		$restrict_title = ak_get_translation( 'Get <span>unlimited</span> access to all our premium contents', 'newsy-membership', 'restrict_title', false );
		$restrict_desc  = ak_get_translation( 'Plans starting at less than $9/month. <strong>Cancel anytime.</strong>', 'newsy-membership', 'restrict_desc', false );
		$join_us_label  = ak_get_translation( 'Get Digital All Access', 'newsy-membership', 'join_us_label' );
		$login_label    = ak_get_translation( 'Sign In', 'newsy-membership', 'login_label' );
		$login_desc     = ak_get_translation( 'Already a subscriber?', 'newsy-membership', 'login_desc' );

		$output  = '';
		$output .= '<div class="ak-restrict-box"><div class="ak-restrict-box-inner">';
		$output .= '<div class="restrict-icon"><i class="ak-icon fa fa-lock"></i></div>';
		$output .= '<h2 class="restrict-title">' . wp_kses( $restrict_title, ak_trans_allowed_html() ) . '</h2>';
		$output .= '<p class="restrict-desc">' . wp_kses( $restrict_desc, ak_trans_allowed_html() ) . '</p>';
		$output .= '<div class="restrict-button-wrap"><a href="' . $joinus_url . '" class="btn btn-lg btn-accent restrict-button is-btn">' . $join_us_label . '</a></div>';
		if ( ! is_user_logged_in() ) {
			$output .= '<div class="restrict-login">';
			$output .= '<span class="restrict-login-description">' . wp_kses( $login_desc, ak_trans_allowed_html() ) . '</span>';
			$output .= '<a class="restrict-login-link ak_require_login_button" href="' . esc_url( $login_url ) . '">' . $login_label . '</a>';
			$output .= '</div>';
		}

		$output .= '</div></div>';

		return $output;
	}

	/**
	 * @param $error_msg
	 *
	 * @return string
	 */
	public function restrict_level_box( $error_msg ) {
		$joinus_url = \SwpmSettings::get_instance()->get_value( 'join-us-page-url' );

		if ( empty( $joinus_url ) ) {
			return '<p class="error">The login page or the join us page URL is missing in the settings configuration.</p>';
		}

		$restrict_title = newsy_get_translation( '<strong>Upgrade Your Plan</strong> for even <span>Greater</span> benefits.', 'newsy-membership', 'restrict_level_title' );
		$restrict_desc  = newsy_get_translation( 'This content is not permitted for your membership level.', 'newsy-membership', 'restrict_level_desc' );
		$join_us_label  = newsy_get_translation( 'Upgrade Now', 'newsy-membership', 'restrict_level_join_label' );

		$output  = '';
		$output .= '<div class="ak-restrict-box"><div class="ak-restrict-box-inner">';

		$output .= '<h2 class="restrict-title">' . wp_kses( $restrict_title, ak_trans_allowed_html() ) . '</h2>';
		$output .= '<p class="restrict-desc">' . wp_kses( $restrict_desc, ak_trans_allowed_html() ) . '</p>';
		$output .= '<div class="restrict-button-wrap"><a href="' . esc_url( $joinus_url ) . '" class="btn btn-lg btn-accent restrict-button is-btn">' . $join_us_label . '</a></div>';

		$output .= '</div></div>';

		return $output;
	}

	/**
	 * @param $error_msg
	 *
	 * @return string
	 */
	public function restrict_renewal_box( $error_msg ) {
		$renewal = \SwpmSettings::get_instance()->get_value( 'renewal-page-url' );

		if ( empty( $renewal ) ) {
			$renewal = \SwpmSettings::get_instance()->get_value( 'join-us-page-url' );
		}
		if ( empty( $renewal ) ) {
			return '<p class="error">The renewal page or the URL is missing in the settings configuration.</p>';
		}

		$restrict_title = newsy_get_translation( '<strong>Renew account</strong> to access <span>Premium</span> contents', 'newsy-membership', 'restrict_renewal_title', false );
		$restrict_desc  = newsy_get_translation( 'Your membership plan has expired.', 'newsy-membership', 'restrict_renewal_desc' );
		$renewal_label  = newsy_get_translation( 'Renewal Your MemberShip', 'newsy-membership', 'renewal_label' );

		$output  = '';
		$output .= '<div class="ak-restrict-box"><div class="ak-restrict-box-inner">';

		$output .= '<h2 class="restrict-title">' . wp_kses( $restrict_title, ak_trans_allowed_html() ) . '</h2>';
		$output .= '<p class="restrict-desc">' . wp_kses( $restrict_desc, ak_trans_allowed_html() ) . '</p>';
		$output .= '<div class="restrict-button-wrap"><a href="' . esc_url( $renewal ) . '" class="btn btn-lg btn-accent restrict-button is-btn">' . $renewal_label . '</a></div>';

		$output .= '</div></div>';

		return $output;
	}

	/**
	 * @param $classes
	 * @param $post_id
	 *
	 * @return string
	 */
	public function add_module_classes( $classes, $post_id ) {
		$protected = SwpmProtection::get_instance();
		if ( ! $protected->is_protected( $post_id ) ) {
			return $classes;
		}
		$classes[] = 'ak-exclusive-post';

		return $classes;
	}

	/**
	 * @param $classes
	 * @param $post_id
	 *
	 * @return string
	 */
	public function add_classes( $classes, $class, $post_id ) {
		$protected = SwpmProtection::get_instance();
		if ( ! $protected->is_protected( $post_id ) ) {
			return $classes;
		}
		$classes[] = 'ak-exclusive-article';

		return $classes;
	}
}
