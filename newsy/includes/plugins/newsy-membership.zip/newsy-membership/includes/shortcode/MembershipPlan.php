<?php

use Ak\Shortcode\ShortcodeAbstract;

class MembershipPlan extends ShortcodeAbstract {
	public function __construct( $id, $params ) {
		$_defaults = array(
			'icon'         => '',
			'title'        => 'Monthly Plan',
			'desc'         => '',
			'style'        => '',
			'price'        => '9',
			'price_unit'   => '$',
			'price_tenure' => '/month',
			'features'     => '',
			'btn_code'     => '',
		);

		$this->defaults = array_merge( $this->defaults, $_defaults );

		parent::__construct( $id, $params );
	}

	/**
	 * Handle displaying of shortcode.
	 *
	 * @param array  $atts
	 * @param string $content
	 *
	 * @return string
	 */
	public function render( $atts, $content = '' ) {
		$output  = '';
		$output .= '<div class="ak-plan-item ' . esc_attr( $atts['style'] ) . '">';
		$output .= '<div class="ak-plan-item-inner">';
		$output .= '<div class="ak-plan-item-header">';
		if ( ! empty( $atts['icon'] ) ) {
			$output .= '<div class="ak-plan-item-icon">' . ak_get_icon( $atts['icon'] ) . '</div>';
		}
		if ( ! empty( $atts['title'] ) ) {
			$output .= '<h4 class="ak-plan-item-name">' . esc_html( $atts['title'] ) . '</h4>';
		}
		if ( ! empty( $atts['desc'] ) ) {
			$output .= '<p class="ak-plan-item-desc">' . esc_html( $atts['desc'] ) . '</p>';
		}
			$output .= '</div>';

		if ( ! empty( $atts['title'] ) ) {
			$output .= sprintf(
				'<div class="ak-plan-price-wrap h6"><span class="ak-plan-price-unit">%s</span><span class="ak-plan-price">%s</span><span class="ak-plan-tenure">%s</span></div>',
				! empty( $atts['price_unit'] ) ? esc_html( $atts['price_unit'] ) : '$',
				$atts['price'],
				! empty( $atts['price_tenure'] ) ? esc_html( $atts['price_tenure'] ) : ''
			);
		}

		$features = ! empty( $atts['features'] ) ? explode( ',', $atts['features'] ) : array();

		if ( ! empty( $features ) ) {
			$output .= '<div class="ak-plan-features">';
			foreach ( $features as $feature ) {
				$output .= '<span class="ak-plan-feature">' . esc_html( $feature ) . '</span>';
			}
			$output .= '</div>';
		}

		if ( ! empty( $atts['btn_code'] ) ) {
			$output .= '<div class="ak-plan-button-wrap">';
			$output .= do_shortcode( "[swpm_payment_button id={$atts['btn_code']}]" );
			$output .= '</div>';
		}

		$output .= '</div>';
		$output .= '</div>';

		return $output;
	}


	/**
	 * Visual Composer Fields Map for Shortcode.
	 */
	public function fields() {
		$options = array(
			'' => '',
		);

		if ( class_exists( 'SwpmMembershipLevelUtils' ) ) {
			$items = get_posts(
				array(
					'post_type'      => 'swpm_payment_button',
					'post_status'    => 'publish',
					'posts_per_page' => 99999,
				)
			);

			foreach ( $items as $item ) {
				$membership_level     = get_post_meta( $item->ID, 'membership_level_id', true );
				$button_type          = get_post_meta( $item->ID, 'button_type', true );
				$level_name           = \SwpmMembershipLevelUtils::get_membership_level_name_by_level_id( $membership_level );
				$options[ $item->ID ] = get_the_title( $item->ID ) . ' (' . $level_name . ') - ' . $button_type;
			}
		}

		return array(
			array(
				'id'          => 'title',
				'type'        => 'text',
				'heading'     => esc_html__( 'Title', 'newsy-membership' ),
				'placeholder' => esc_html__( 'Monthly Plan', 'newsy-membership' ),
				'section'     => 'Plan',
			),
			array(
				'id'      => 'desc',
				'type'    => 'text',
				'heading' => esc_html__( 'Description', 'newsy-membership' ),
				'section' => 'Plan',
			),
			array(
				'id'      => 'icon',
				'type'    => 'icon_select',
				'heading' => esc_html__( 'Icon', 'newsy-membership' ),
				'section' => 'Plan',
			),
			array(
				'id'      => 'style',
				'type'    => 'visual_select',
				'heading' => esc_html__( 'Style', 'newsy-membership' ),
				'section' => 'Plan',
				'options' => array(
					''         => 'Normal',
					'featured' => esc_html__( 'Featured', 'newsy-membership' ),
					'dark'     => esc_html__( 'Dark', 'newsy-membership' ),
				),
			),
			array(
				'id'      => 'price',
				'type'    => 'number',
				'heading' => esc_html__( 'Price', 'newsy-membership' ),
				'section' => 'Plan',
			),
			array(
				'id'      => 'price_unit',
				'type'    => 'text',
				'heading' => esc_html__( 'Price Unit', 'newsy-membership' ),
				'section' => 'Plan',
			),
			array(
				'id'          => 'price_tenure',
				'type'        => 'text',
				'heading'     => esc_html__( 'Price Tenure', 'newsy-membership' ),
				'placeholder' => esc_html__( '/month', 'newsy-membership' ),
				'section'     => 'Plan',
			),
			array(
				'id'        => 'features',
				'type'      => 'text',
				'selectize' => true,
				'multiple'  => true,
				'heading'   => esc_html__( 'Features', 'newsy-membership' ),
				'section'   => 'Plan',
			),
			array(
				'id'         => 'btn_code',
				'type'       => 'select',
				'heading'    => esc_html__( 'Membership Payment Button', 'newsy-membership' ),
				'input_desc' => esc_html__( 'Select a payment button. You can create and get your button code on WP Membership > Payments > Manage Payment Buttons', 'newsy-membership' ),
				'section'    => 'Plan',
				'options'    => $options,
			),
		);
	}
}
