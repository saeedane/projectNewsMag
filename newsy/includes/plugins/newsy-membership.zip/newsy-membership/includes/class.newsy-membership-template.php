<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Newsy Membership Template
 */
class Newsy_Membership_Template {

	/**
	 * @var Newsy_Membership_Template
	 */
	private static $instance;

	/**
	 * @return Newsy_Membership_Template
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}
		return static::$instance;
	}

	private function __construct() {
		$this->setup_hook();
	}

	protected function setup_hook() {
		add_action( 'init', array( $this, 'add_rewrite_rule' ) );
		add_action( 'template_include', array( $this, 'add_page_template' ) );
	}

	public function get_endpoint() {
		return trim( Newsy_Membership::get_instance()->get_option( 'endpoint', 'subscription' ), '/' );
	}

	public function add_rewrite_rule() {
		$endpoint = $this->get_endpoint();
		add_rewrite_endpoint( $endpoint, EP_ROOT | EP_PAGES );
		add_rewrite_rule( '^' . $endpoint . '/?([0-9]{1,})/?$', 'index.php?&page=$matches[1]&' . $endpoint, 'top' );
	}

	public function flush_rewrite_rules() {
		global $wp_rewrite;
		$wp_rewrite->flush_rules();
	}

	public function reset_rewrite_rules() {
		$this->add_rewrite_rule();
		$this->flush_rewrite_rules();
	}

	public function add_page_template( $template ) {
		if ( ! $this->endpoint_check() ) {
			return $template;
		}

		$file = NEWSY_MEMBERSHIP_PATH . 'includes/template/page-membership.php';

		if ( ! empty( $file ) && file_exists( $file ) ) {
			$template = $file;
		}

		return $template;
	}

	public function endpoint_check() {
		global $wp;
		$endpoint = $this->get_endpoint();

		if ( isset( $wp->query_vars[ $endpoint ] ) ) {
			return true;
		}

		return false;
	}
}
