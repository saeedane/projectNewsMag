<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

get_header();

$plans          = Newsy_Membership::get_instance()->get_plans();
$show_footer    = Newsy_Membership::get_instance()->get_option( 'show_footer' );
$contact_us_url = Newsy_Membership::get_instance()->get_option( 'contact_us_url', '#' );
?>
<div class="ak-content-wrap ak-join-us-wrap">
	<div class="ak-container">
		<div class="ak-content">
			<div class="ak-membership-wrapper">
				<div class="ak-membership-header">
					<div class="container">
						<h2 class="ak-membership-header-title"><?php ak_echo_translation( 'Choose Your Plan', 'newsy-membership', 'subcription_heading' ); ?></h2>
						<p class="ak-membership-header-desc"><?php ak_echo_translation( 'Get unlimited access to everything', 'newsy-membership', 'subcription_desc' ); ?></p>
					</div>
				</div>
				<div class="ak-membership-plan-wrap">
					<div class="container">
						<div class="ak-membership-plan-list">
							<?php
							foreach ( $plans as $plan ) {
								ak_do_shortcode( 'newsy_membership_plan', $plan );
							}
							?>
						</div>
					</div>
				</div>
				<?php if ( 'no' !== $show_footer ) : ?>
				<div class="ak-membership-footer">
					<div class="container">
						<div class="ak-membership-footer-header">
							<h3><?php ak_echo_translation( 'Do you have questions?', 'newsy-membership', 'subcription_help_title' ); ?></h3>
							<p><?php ak_echo_translation( 'We have a dedicated team of experts to help you with your membership needs.', 'newsy-membership', 'subcription_help_desc' ); ?></p>
							<a href="<?php echo esc_url( $contact_us_url ); ?>" class="btn btn-box rounded"><?php ak_echo_translation( 'Contact us', 'newsy-membership', 'subcription_help_label' ); ?></a>
						</div>
					</div>
				</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>
<?php get_footer(); ?>
