<?php
$fields[] = array(
	'heading' => esc_html__( 'Settings', 'newsy-membership' ),
	'id'      => 'settings',
	'type'    => 'section',
);


if ( ! class_exists( 'SimpleWpMembership' ) ) {
	$fields[] = array(
		'id'          => 'simple_membership_warning',
		'type'        => 'info',
		'info_type'   => 'warning',
		'heading'     => esc_html__( 'Simple WordPress Membership Plugin is missing!', 'newsy-membership' ),
		'description' => wp_kses( __( 'Please install <a href=\'https://wordpress.org/plugins/simple-membership/\'>Simple WordPress Membership</a> plugin to enable the theme features.', 'newsy-membership' ), ak_trans_allowed_html() ),
		'section'     => 'settings',
	);
}


$fields[] = array(
	'id'          => 'endpoint',
	'type'        => 'text',
	'heading'     => esc_html__( 'Membership Endpoint', 'newsy-membership' ),
	'description' => esc_html__( 'Choose Frontend editor access endpoint. You may want to change url for editor page with this option. Default is "editor"', 'newsy-membership' ),
	'default'     => 'subscription',
	'section'     => 'settings',
);

$fields[] = array(
	'id'                 => 'plans',
	'type'               => 'repeater',
	'heading'            => esc_html__( 'Membership Plans', 'newsy-membership' ),
	'repeat_heading'     => esc_html__( 'Panel', 'newsy-membership' ),
	'repeat_title_field' => 'title',
	'description'        => esc_html__( 'Here you can choose classic frontend editor post formats. Each type has starter blocks and accepted blocks and you can enable for editor, start page and dropdown.', 'newsy-membership' ),
	'fields'             => ak_get_shortcode( 'newsy_membership_plan' )->get_fields(),
	'default'            => Newsy_Membership::get_instance()->get_default_plans(),
	'filter_default'     => false,
	'defaults_on_empty'  => true,
	'section'            => 'settings',
);

$fields[] = array(
	'id'      => 'show_footer',
	'type'    => 'switcher',
	'heading' => esc_html__( 'Show Help Section on Membership Plans page?', 'newsy-membership' ),
	'options' => array(
		'on'  => '',
		'off' => 'no',
	),
	'section' => 'settings',
);

$fields[] = array(
	'id'         => 'contact_us_url',
	'type'       => 'text',
	'heading'    => esc_html__( 'Contact us URL?', 'newsy-membership' ),
	'section'    => 'settings',
	'dependency' => array(
		'element' => 'show_footer',
		'value'   => array( '' ),
	),
);


$fields[] = array(
	'heading' => esc_html__( 'Others', 'newsy-membership' ),
	'id'      => 'other',
	'type'    => 'section',
);

$fields[] = array(
	'heading' => esc_html__( 'Exclusive badge', 'newsy-membership' ),
	'id'      => 'exclusive_badge_group_start',
	'type'    => 'group_start',
	'section' => 'other',
	'state'   => 'open',
);

$fields[] = array(
	'id'      => 'exclusive_badge_text',
	'type'    => 'text',
	'heading' => esc_html__( 'Exclusive post badge text', 'newsy-membership' ),
	'default' => 'EXCLUSIVE',
	'section' => 'other',
	'output'  => array(
		array(
			'type'     => 'css',
			'element'  => array(
				'.ak-exclusive-post .ak-module-title a:before',
			),
			'property' => 'custom',
			'css'      => array(
				'content' => '"%%value%%"',
			),
		),
	),
);
$fields[] = array(
	'id'      => 'exclusive_badge_style',
	'type'    => 'css_editor',
	'heading' => esc_html__( 'Exclusive post badge style', 'newsy-membership' ),
	'section' => 'other',
	'output'  => array(
		array(
			'type'     => 'css',
			'element'  => array(
				'.ak-exclusive-post .ak-module-title a:before',
			),
			'property' => 'css-editor',
		),
	),
);
$fields[] = array(
	'id'      => 'exclusive_badge_typo',
	'type'    => 'typography',
	'heading' => esc_html__( 'Exclusive post badge typography', 'newsy' ),
	'section' => 'other',
	'output'  => array(
		array(
			'type'     => 'css',
			'element'  => '.ak-exclusive-post .ak-module-title a:before',
			'property' => 'typography',
		),
	),
);
