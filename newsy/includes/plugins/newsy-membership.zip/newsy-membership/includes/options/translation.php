<?php

//Membership

$fields[] = array(
	'heading' => 'Restrict Box',
	'id'      => 'restrict_group_start',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => 'Restrict',
	'id'      => 'restrict_heading',
	'type'    => 'heading',
	'section' => 'translation',
);
$fields[] = array(
	'heading'           => 'Get <span>unlimited</span> access to all our premium contents',
	'default'           => 'Get <span>unlimited</span> access to all our premium contents',
	'id'                => 'restrict_title',
	'type'              => 'text',
	'section'           => 'translation',
	'sanitize_callback' => false,
);

$fields[] = array(
	'heading'           => 'Plans starting at less than $9/month. <strong>Cancel anytime.</strong>',
	'default'           => 'Plans starting at less than $9/month. <strong>Cancel anytime.</strong>',
	'id'                => 'restrict_desc',
	'type'              => 'text',
	'section'           => 'translation',
	'sanitize_callback' => false,
);

$fields[] = array(
	'heading' => 'Get Digital All Access',
	'default' => 'Get Digital All Access',
	'id'      => 'join_us_label',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Sign In',
	'default' => 'Sign In',
	'id'      => 'login_label',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Already a subscriber',
	'default' => 'Already a subscriber',
	'id'      => 'login_desc',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Upgrade',
	'id'      => 'restrict_level_heading',
	'type'    => 'heading',
	'section' => 'translation',
);

$fields[] = array(
	'heading'           => '<strong>Upgrade Your Plan</strong> for even <span>Greater</span> benefits.',
	'default'           => '<strong>Upgrade Your Plan</strong> for even <span>Greater</span> benefits.',
	'id'                => 'restrict_level_title',
	'type'              => 'text',
	'section'           => 'translation',
	'sanitize_callback' => false,
);
$fields[] = array(
	'heading'           => 'This content is not permitted for your membership level.',
	'default'           => 'This content is not permitted for your membership level.',
	'id'                => 'restrict_level_desc',
	'type'              => 'text',
	'section'           => 'translation',
	'sanitize_callback' => false,
);
$fields[] = array(
	'heading' => 'Upgrade Now',
	'default' => 'Upgrade Now',
	'id'      => 'restrict_level_join_label',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Renewal',
	'id'      => 'restrict_renewal_heading',
	'type'    => 'heading',
	'section' => 'translation',
);
$fields[] = array(
	'heading'           => '<strong>Renew account</strong> to access <span>Premium</span> contents.',
	'default'           => '<strong>Renew account</strong> to access <span>Premium</span> contents.',
	'id'                => 'restrict_renewal_title',
	'type'              => 'text',
	'section'           => 'translation',
	'sanitize_callback' => false,
);
$fields[] = array(
	'heading' => 'Your membership plan has expired..',
	'default' => 'Your membership plan has expired.',
	'id'      => 'restrict_renewal_title',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Renewal Your MemberShip',
	'default' => 'Renewal Your MemberShip',
	'id'      => 'renewal_label',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Subcription Page',
	'id'      => 'subcription_group_start',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);

$fields[] = array(
	'heading' => 'Choose Your Plan',
	'default' => 'Choose Your Plan',
	'id'      => 'subcription_heading',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Get unlimited access to everything',
	'default' => 'Get unlimited access to everything',
	'id'      => 'subcription_desc',
	'type'    => 'text',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Subcription Help',
	'id'      => 'subcription_help_heading',
	'type'    => 'heading',
	'section' => 'translation',
);

$fields[] = array(
	'heading' => 'Do you have questions?',
	'default' => 'Do you have questions?',
	'id'      => 'subcription_help_title',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'We have a dedicated team of experts to help you with your membership needs.',
	'default' => 'We have a dedicated team of experts to help you with your membership needs.',
	'id'      => 'subcription_help_desc',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Contact us',
	'default' => 'Contact us',
	'id'      => 'subcription_help_label',
	'type'    => 'text',
	'section' => 'translation',
);
