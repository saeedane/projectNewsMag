<?php
/**
 * @author akbilisim
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Newsy_Membership {

	/**
	 * @var Newsy_Membership
	 */
	private static $instance;

	/**
	 * Contains plugin option panel ID
	 *
	 * @var string
	 */
	private $option_id = 'newsy-membership-options';

	/**
	 * @return Newsy_Membership
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
			static::$instance->register_hooks();
		}

		return static::$instance;
	}

	/**
	 * Setup hooks.
	 *
	 * @return void
	 */
	private function register_hooks() {
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ), 999 );
		add_filter( 'ak-framework/product/pages', array( $this, 'register_product_pages' ), 11 );
		add_filter( 'ak-framework/register/translation', array( $this, 'register_translation_fields' ), 30 );
		add_filter( 'ak-framework/shortcode', array( $this, 'register_shortcode' ), 99 );
		add_action( 'ak-framework/option-panel/save/after', array( $this, 'option_save_hook' ), 999 );
	}

	public function get_default_plans() {
		$plans = array(
			array(
				'title'        => 'Monthly Plan',
				'desc'         => 'Plans starting at less than $9/month. Cancel anytime.',
				'icon'         => '',
				'style'        => '',
				'price'        => '9',
				'price_unit'   => '$',
				'price_tenure' => '/month',
				'features'     => '1-Month Unlimited access,Paper magazine delivered,Exclusive discount,Premium support,Cancel any time',
				'btn_code'     => '[swpm_payment_button id=5574]',
			),
			array(
				'title'        => 'Yearly Plan',
				'desc'         => 'Billed yearly at $54, Save 40% for this plan. Cancel anytime.',
				'icon'         => 'fa-star',
				'style'        => 'featured',
				'price'        => '54',
				'price_unit'   => '$',
				'price_tenure' => '/year',
				'features'     => '1-Year Unlimited access,Paper magazine delivered,Exclusive discount,Premium support,Cancel any time',
				'btn_code'     => '[swpm_payment_button id=5581]',
			),
			array(
				'title'        => 'Forever Plan',
				'desc'         => 'Billed once, Save 40% for this lifetime plan.',
				'icon'         => '',
				'style'        => 'dark',
				'price'        => '299',
				'price_unit'   => '$',
				'price_tenure' => '/once',
				'features'     => 'Lifetime Unlimited access,Paper magazine delivered,Exclusive discount,Premium support,Cancel any time',
				'btn_code'     => '[swpm_payment_button id=5573]',
			),
		);

		return apply_filters( 'newsy_membership_default_plans', $plans );
	}

	public function get_plans() {
		$plans = $this->get_option( 'plans', $this->get_default_plans() );

		return apply_filters( 'newsy_membership_plans', $plans );
	}


	public function register_assets() {
		// styles
		wp_enqueue_style( 'newsy-membership', NEWSY_MEMBERSHIP_URI . '/css/style.css', array(), NEWSY_MEMBERSHIP_VERSION );
	}

	public function register_product_pages( $pages ) {
		$pages[ NEWSY_MEMBERSHIP ] = array(
			'product'    => 'newsy',
			'page_title' => __( 'Membership Options', 'newsy-membership' ),
			'capability' => 'manage_options',
			'module'     => 'option-panel',
			'hide_tab'   => true,
			'global_css' => true,
			'position'   => 155,
			'config'     => array(
				'panel_title'   => __( 'Membership Options', 'newsy-membership' ),
				'panel_options' => array(
					'option_id'   => $this->option_id,
					'file'        => NEWSY_MEMBERSHIP_PATH . 'includes/options/panel.php',
					'panel_class' => 'ak-panel-menu-top ',
				),
			),
		);

		return $pages;
	}

	/**
	 * Register the Newsy Comments translations to framework.
	 *
	 * @return array
	 */
	public function register_translation_fields( $fields ) {
		$fields[ NEWSY_MEMBERSHIP ] = array(
			'name' => __( 'Newsy Membership', 'newsy-membership' ),
			'file' => NEWSY_MEMBERSHIP_PATH . 'includes/options/translation.php',
		);

		return $fields;
	}

	public function register_shortcode( $shortcode ) {
		$shortcode['newsy_membership_plan'] = array(
			'style'           => 'ak-block-membership-plan',
			'have_map_for_vc' => true,
			'have_widget'     => true,
			'name'            => 'Newsy Membership Plan',
			'class'           => 'MembershipPlan',
			'file'            => NEWSY_MEMBERSHIP_PATH . 'includes/shortcode/MembershipPlan.php',
			'category'        => 'Newsy',
			'icon'            => 'fa fa-star',
		);

		return $shortcode;
	}

	public function option_save_hook( $option_id ) {
		if ( $this->option_id === $option_id ) {
			Newsy_Membership_Template::get_instance()->reset_rewrite_rules();
		}
	}

	/**
	 * Used for retrieving options simply and safely for next versions
	 *
	 * @param $option_key
	 *
	 * @return mixed|null
	 */
	public function get_option( $option_key, $default_value = '' ) {
		if ( ! function_exists( 'ak_get_option' ) ) {
			return $default_value;
		}

		return ak_get_option( $this->option_id, $option_key, $default_value );
	}

	/**
	 * Used for accessing plugin directory URL
	 *
	 * @param string $address
	 *
	 * @return string
	 */
	public function dir_url( $address = '' ) {
		return NEWSY_MEMBERSHIP_URI . $address;
	}

	/**
	 * Used for accessing plugin directory path
	 *
	 * @param string $address
	 *
	 * @return string
	 */
	public function dir_path( $address = '' ) {
		return NEWSY_MEMBERSHIP_PATH . $address;
	}
}
