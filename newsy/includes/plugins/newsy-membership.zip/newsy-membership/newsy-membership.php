<?php
/*
Plugin Name: Newsy Membership
Plugin URI: http://akbilisim.com
Description: Extend Simple WordPress Membership to fit with Newsy Style
Version: 1.0.0
Author: akbilisim
Author URI: http://akbilisim.com
License: GPL2
*/

defined( 'NEWSY_MEMBERSHIP' ) or define( 'NEWSY_MEMBERSHIP', 'newsy-membership' );
defined( 'NEWSY_MEMBERSHIP_VERSION' ) or define( 'NEWSY_MEMBERSHIP_VERSION', '1.0.0' );
defined( 'NEWSY_MEMBERSHIP_URI' ) or define( 'NEWSY_MEMBERSHIP_URI', plugins_url( NEWSY_MEMBERSHIP ) );
defined( 'NEWSY_MEMBERSHIP_PATH' ) or define( 'NEWSY_MEMBERSHIP_PATH', plugin_dir_path( __FILE__ ) );

require_once 'includes/class.newsy-membership.php';
require_once 'includes/class.newsy-membership-hooks.php';
require_once 'includes/class.newsy-membership-template.php';

/**
 * Newsy Membership init.
 */
if ( ! function_exists( 'newsy_membership_load' ) ) {
	function newsy_membership_load() {
		Newsy_Membership::get_instance();
		Newsy_Membership_Hooks::get_instance();
		Newsy_Membership_Template::get_instance();

		/**
		 * Load Text Domain
		 */
		load_plugin_textdomain( NEWSY_MEMBERSHIP, false, basename( __DIR__ ) . '/languages/' );
	}
}

add_action( 'plugins_loaded', 'newsy_membership_load' );


/**
 * Activation hook
 */
function newsy_membership_activation_hook() {
	Newsy_Membership_Template::get_instance()->reset_rewrite_rules();
}

register_activation_hook( __FILE__, 'newsy_membership_activation_hook' );

/**
 * Deactivation hook
 */
function newsy_membership_deactivation_hook() {
	Newsy_Membership_Template::get_instance()->flush_rewrite_rules();
}

register_deactivation_hook( __FILE__, 'newsy_membership_deactivation_hook' );
