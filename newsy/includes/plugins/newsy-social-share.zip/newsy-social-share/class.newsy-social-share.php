<?php
/**
 * @author akbilisim
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Newsy_Social_Share {

	/**
	 * The Newsy Social Share object instance.
	 *
	 * @var Newsy_Social_Share
	 */
	private static $instance;

	/**
	 * Contains plugin option panel ID
	 *
	 * @var string
	 */
	private $option_id = 'newsy-theme-options';

	/**
	 * Contains post share  data.
	 *
	 * @var string
	 */
	private $cache_key = 'ak_post_share_data';

	/**
	 * Contains post share total count.
	 *
	 * @var string
	 */
	private $cache_total_key = 'ak_post_share_total';

	/**
	 * The name of the fields where 7 days counter are kept(in a serialized array) for the given post
	 *
	 * @var array
	 */
	private $share_sites = array( // Valid sites
		'facebook',
		'twitter',
		'pinterest',
		'whatsapp',
		'email',
		'tumblr',
		'reddit',
		'stumbleupon',
		'telegram',
		'linkedin',
		'digg',
		'vk',
		'line',
		'viber',
	);

	/**
	 * @return Newsy_Social_Share
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
			static::$instance->register_hooks();
		}

		return static::$instance;
	}

	/**
	 * Setup hooks.
	 *
	 * @return void
	 */
	private function register_hooks() {
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ), 999 );
		add_filter( 'ak-framework/post-query-args', array( $this, 'register_post_query_args' ), 11, 2 );
		add_filter( 'newsy_block_order_by_options', array( $this, 'register_order_by_options' ), 16 );
		add_filter( 'newsy_module_bottom_meta', array( $this, 'add_share_module_bottom' ), 11, 2 );
	}

	/**
	 * Get social share buttons.
	 *
	 * @param $sites
	 * @param null   $post_id
	 * @param string $style
	 * @param string $count_type
	 * @param integer    $show_count
	 *
	 * @return string
	 */
	public function get_share_buttons( $sites, $post_id = null, $style = 'style-1', $count_type = 'total', $show_count = 3 ) {
		if ( null === $post_id ) {
			$post_id = get_the_ID();
		}

		if ( is_string( $sites ) ) {
			$sites = array_flip( explode( ',', $sites ) );
		}

		$share_counts = array();
		if ( 'hide' !== $count_type ) {
			$only_total = 'total' === $count_type;

			$share_counts = $this->get_share_counts( $post_id, $only_total );
		}

		$output      = '';
		$more_buffer = '';

		$output .= '<div class="ak-share-container ak-share-' . $style . '">';

		if ( 'total' === $count_type || 'total-each' === $count_type ) {
			$output .= '<div class="ak-share-total">';
			$output .= '<div class="ak-share-count">';
			$output .= '<div class="counts">';
			$output .= apply_filters( 'newsy_number_format', $share_counts['total'] );
			$output .= '</div>';
			$output .= '<div class="shares-text">';
			$output .= newsy_get_translation( 'Shares', 'newsy', 'shares' );
			$output .= '</div>';
			$output .= '</div>';
			$output .= '</div>';
		}

		$output .= '<div class="ak-share-list">';

		$count = 0;
		foreach ( (array) $sites as $site_key => $site ) {
			$count++;

			$share_count = isset( $share_counts[ $site_key ] ) ? $share_counts[ $site_key ] : 0;

			$item = $this->get_share_item( $site_key, $post_id );

			$link  = $item[0];
			$title = $item[1];
			$icon  = $item[2];

			if ( empty( $link ) ) {
				continue;
			}

			$extra_classes = $share_count ? ' has-count' : '';
			$share_item    = '<a href="' . $link . '" target="_blank" rel="nofollow" class="ak-share-button ' . esc_attr( $site_key ) . $extra_classes . '">';

			$share_item .= '<i class="fa ' . $icon . '"></i>';

			if ( $title ) {
				$share_item .= '<span class="share-name">' . esc_html( $title ) . '</span>';
			}

			if ( 'total' !== $count_type && $share_count ) {
				$share_item .= sprintf( '<span class="number">%s</span>', apply_filters( 'newsy_number_format', $share_count ) );
			}

			$share_item .= '</a>';

			if ( $count > $show_count ) {
				$more_buffer .= $share_item;
			} else {
				$output .= $share_item;
			}
		}

		if ( ! empty( $more_buffer ) ) {
			$output .= '<div class="ak-share-more-group">';
			$output .= $more_buffer;
			$output .= '</div>';
			$output .= '<a href="javascript:void(0)" rel="nofollow" class="ak-share-button ak-share-toggle-button"><i class="ak-icon fa fa-ellipsis-h"></i></a>';
		}

		$output .= '</div>';

		$output .= '</div>';

		return $output;
	}

	public function get_share_item( $site_key, $post_id ) {

		// Disable social share in localhost
		$share_title = $this->get_share_title( $post_id );
		$share_link  = $this->get_share_permalink( $post_id );

		$link  = '';
		$title = '';
		$icon  = '';

		switch ( $site_key ) {
			case 'facebook':
				$link  = 'https://www.facebook.com/sharer.php?u=' . $share_link;
				$title = __( 'Facebook', 'newsy-social-share' );
				$icon  = 'fa-facebook';
				break;

			case 'twitter':
				$by = $this->get_option( 'twitter_username' );
				if ( ! empty( $by ) ) {
					$by = ' @' . $by;
				} else {
					$by = '';
				}

				$link  = 'https://twitter.com/share?text=' . $share_title . $by . '&url=' . $share_link;
				$title = __( 'Twitter', 'newsy-social-share' );
				$icon  = 'fa-twitter';
				break;

			case 'email':
				$link  = 'mailto:?subject=' . $share_title . '&body=' . $share_link;
				$title = __( 'Email', 'newsy-social-share' );
				$icon  = 'fa-envelope';
				break;

			case 'whatsapp':
				$link  = 'whatsapp://send?text=' . $share_link;
				$title = __( 'WhatsApp', 'newsy-social-share' );
				$icon  = 'fa-whatsapp';
				break;

			case 'pinterest':
				$img_src  = wp_get_attachment_image_src( get_post_thumbnail_id( $post_id ), 'newsy_750x536' );
				$_img_src = $img_src ? $img_src[0] : '';

				$link  = 'https://pinterest.com/pin/create/button/?url=' . $share_link . '&media=' . $_img_src . '&description=' . $share_title;
				$title = __( 'Pinterest', 'newsy-social-share' );
				$icon  = 'fa-pinterest';
				break;

			case 'linkedin':
				$link  = 'https://www.linkedin.com/shareArticle?mini=true&url=' . $share_link . '&title=' . $share_title;
				$title = __( 'Linkedin', 'newsy-social-share' );
				$icon  = 'fa-linkedin';
				break;

			case 'tumblr':
				$link  = 'https://www.tumblr.com/share/link?url=' . $share_link . '&name=' . $share_title;
				$title = __( 'Tumblr', 'newsy-social-share' );
				$icon  = 'fa-tumblr';
				break;

			case 'telegram':
				$link  = 'https://telegram.me/share/url?url=' . $share_link . '&text=' . $share_title;
				$title = __( 'Telegram', 'newsy-social-share' );
				$icon  = 'fa-paper-plane';
				break;

			case 'digg':
				$link  = 'https://www.digg.com/submit?url=' . $share_link;
				$title = __( 'Digg', 'newsy-social-share' );
				$icon  = 'fa-digg';
				break;

			case 'reddit':
				$link  = 'https://reddit.com/submit?url=' . $share_link . '&title=' . $share_title;
				$title = __( 'ReddIt', 'newsy-social-share' );
				$icon  = 'fa-reddit-alien';
				break;

			case 'stumbleupon':
				$link  = 'https://www.stumbleupon.com/submit?url=' . $share_link . '&title=' . $share_title;
				$title = __( 'StumbleUpon', 'newsy-social-share' );
				$icon  = 'fa-stumbleupon';
				break;

			case 'vk':
				$link  = 'https://vkontakte.ru/share.php?url=' . $share_link;
				$title = __( 'VK', 'newsy-social-share' );
				$icon  = 'fa-vk';
				break;

			case 'line':
				$link  = 'https://line.me/R/msg/text/?' . $share_title . '%0D%0A' . $share_link;
				$title = __( 'LINE', 'newsy-social-share' );
				$icon  = 'fa-commenting';
				break;

			case 'viber':
				$link  = 'viber://forward?text=' . $share_title . ' ' . $share_link;
				$title = __( 'Viber', 'newsy-social-share' );
				$icon  = 'fa-vimeo';
				break;
		}

		return array( $link, $title, $icon );
	}

	/**
	* Get social share counts.
	*
	* @param int   $post_id
	* @param boolean $only_total
	* @param boolean $force_update
	*
	* @return array
	*/
	public function get_share_counts( $post_id, $only_total = false, $force_update = false ) {
		$share_data = array();

		if ( ! $only_total ) {
			$share_data = get_post_meta( $post_id, $this->cache_key, true );
		}

		if ( $force_update ) {
			$share_data = $this->update_share_counts( $post_id );
		}

		$total = get_post_meta( $post_id, $this->cache_total_key, true );

		if ( ! $share_data || ! is_array( $share_data ) ) {
			$share_data = array();
		}

		$share_data['total'] = ! empty( $total ) ? (int) $total : 0;

		return apply_filters( 'newsy_get_post_share_counts', $share_data, $post_id, $this->share_sites );
	}

	/**
	 * @param $post_id
	 *
	 * @return array
	 */
	protected function update_share_counts( $post_id ) {
		$post = get_post( $post_id );

		if ( ! $post ) {
			return;
		}

		$share_data    = get_post_meta( $post_id, $this->cache_key, true );
		$current_time  = current_time( 'timestamp' );
		$cache_expired = absint( $this->get_option( 'share_cache_expired', '60' ) );
		$cache_expired = $current_time - ( $cache_expired * 60 );
		$total_count   = 0;

		if ( empty( $share_data ) || ! empty( $share_data ) && $share_data['expired'] < $cache_expired ) {
			$share_data = array();
			$permalink  = $this->get_share_permalink( $post_id );

			foreach ( $this->share_sites as $site_id ) {
				$count_number = $this->fetch_count( $site_id, $permalink );

				if ( $count_number > 0 ) {
					$share_data[ $site_id ] = (int) $count_number;

					$total_count += (int) $count_number;
				}
			}

			$share_data['expired'] = $current_time;

			update_post_meta( $post_id, $this->cache_key, $share_data );
			if ( $total_count > 0 ) {
				update_post_meta( $post_id, $this->cache_total_key, $total_count );
			}
		}

		return $share_data;
	}

	/**
	 * Fetches share count for URL.
	 *
	 * @param $site_id
	 * @param $url
	 *
	 * @return int
	 */
	protected function fetch_count( $site_id, $url ) {
		$count       = 0;
		$remote_args = array(
			'sslverify' => false,
		);

		switch ( $site_id ) {
			case 'facebook':
				$fb_token = apply_filters( 'newsy_facebook_access_token', '' );
				$fb_token = ! empty( $fb_token ) ? '&access_token=' . $fb_token : '';

				$response = $this->make_request( 'https://graph.facebook.com/?fields=engagement&id=' . $url . $fb_token, $remote_args );

				if ( $response && isset( $response['engagement']['share_count'] ) ) {
					$count = $response['engagement']['share_count'];
				}
				break;

			case 'twitter':
				$response = $this->make_request( 'https://counts.twitcount.com/counts.php?url=' . $url, $remote_args );

				if ( $response && isset( $response['count'] ) ) {
					$count = $response['count'];
				}
				break;

			case 'pinterest':
				$response = wp_remote_get( 'http://api.pinterest.com/v1/urls/count.json?callback=CALLBACK&url=' . $url, $remote_args );

				if ( ! is_wp_error( $response ) ) {
					if ( preg_match( '/^\s*CALLBACK\s*\((.+)\)\s*$/', wp_remote_retrieve_body( $response ), $match ) ) {
						$response = json_decode( $match[1], true );

						if ( $response && isset( $response['count'] ) ) {
							$count = $response['count'];
						}
					}
				}
				break;

			case 'linkedin':
				$response = $this->make_request( 'https://www.linkedin.com/countserv/count/share?format=json&url=' . $url, $remote_args );

				if ( $response && isset( $response['count'] ) ) {
					$count = $response['count'];
				}
				break;

			case 'tumblr':
				$response = $this->make_request( 'http://api.tumblr.com/v2/share/stats?url=' . $url, $remote_args );

				if ( $response && isset( $response['response']['note_count'] ) ) {
					$count = $response['response']['note_count'];
				}
				break;

			case 'reddit':
				$response = $this->make_request( 'http://www.reddit.com/api/info.json?url=' . $url, $remote_args );

				if ( $response && isset( $response['data']['children']['0']['data']['score'] ) ) {
					$count = $response['data']['children']['0']['data']['score'];
				}
				break;

			case 'stumbleupon':
				$response = $this->make_request( 'http://www.stumbleupon.com/services/1.01/badge.getinfo?url=' . $url, $remote_args );

				if ( $response && isset( $response['result']['views'] ) ) {
					$count = $response['result']['views'];
				}
				break;
		}

		return $count;
	}

	/**
	 * Make request.
	 *
	 * @param string $url
	 *
	 * @return bool|array (default:bool)
	 */
	protected function make_request( $url, $remote_args ) {
		$response = wp_remote_get( $url, $remote_args );

		if ( ! is_wp_error( $response ) && '200' == $response['response']['code'] ) {
			$result = json_decode( $response['body'], true );

			return $result;
		}

		return false;
	}

	public function get_share_title( $post_id ) {
		$title = get_the_title( $post_id );
		$title = html_entity_decode( $title, ENT_QUOTES, 'UTF-8' );
		$title = urlencode( $title );
		$title = str_replace( '#', '%23', $title );
		return esc_html( $title );
	}

	public function get_share_permalink( $post_id ) {
		return urlencode( esc_url( get_permalink( $post_id ) ) );
	}


	public function register_assets() {
		wp_enqueue_script( 'newsy-social-share', NEWSY_SOCIAL_SHARE_URI . '/js/plugin.js', array( 'jquery' ), NEWSY_SOCIAL_SHARE_VERSION, true );
	}

	/**
	 * Register the Newsy view counter post query args to framework.
	 *
	 * @return array
	 */
	public function register_post_query_args( $args, $atts ) {
		// orderby
		if ( ! empty( $atts['order_by'] ) ) {
			switch ( $atts['order_by'] ) {
				case 'share_count':
					$args['orderby']  = 'meta_value_num';
					$args['meta_key'] = $this->cache_total_key;
					$args['order']    = 'DESC';
					break;
			}
		}

		return $args;
	}

	/**
	 * Register the Newsy view counter post query args to framework.
	 *
	 * @return array
	 */
	public function register_order_by_options( $options ) {
		$options['share_count'] = __( 'Most Shared', 'buzz-share-counter' );

		return $options;
	}

	/**
	 * Add share button
	 */
	public function add_share_module_bottom( $output, $post_id ) {
		$sites            = $this->get_option( 'module_social_share_sites', 'facebook,twitter,pinterest' );
		$share_style      = $this->get_option( 'module_social_share_style', 'style-2' );
		$share_count_type = $this->get_option( 'module_social_share_count', 'each' );
		$share_show_count = $this->get_option( 'module_social_share_show_count', 2 );

		return $this->get_share_buttons( $sites, $post_id, $share_style, $share_count_type, $share_show_count );
	}

	/**
	 * Used for retrieving options simply and safely for next versions
	 *
	 * @param $option_key
	 *
	 * @return mixed|null
	 */
	public function get_option( $option_key, $default_value = '' ) {
		if ( ! function_exists( 'ak_get_option' ) ) {
			return $default_value;
		}

		return ak_get_option( $this->option_id, $option_key, $default_value );
	}

	/**
	 * Used for accessing plugin directory URL
	 *
	 * @param string $address
	 *
	 * @return string
	 */
	public function dir_url( $address = '' ) {
		return NEWSY_SOCIAL_SHARE_URI . $address;
	}

	/**
	 * Used for accessing plugin directory path
	 *
	 * @param string $address
	 *
	 * @return string
	 */
	public function dir_path( $address = '' ) {
		return NEWSY_SOCIAL_SHARE_PATH . $address;
	}
}
