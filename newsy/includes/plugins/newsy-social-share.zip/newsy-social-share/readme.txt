Change Log :

== 1.0.2 ==
- [IMPROVEMENT] Facebook access token

== 1.0.1 ==
- [IMPROVEMENT] Share counters counts for all providers
- [FIX] Missing Share count expire time option

== 1.0.0 ==
- First Release
