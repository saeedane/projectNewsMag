<?php
/*
Plugin Name:    Newsy Fake Counter
Plugin URI:     http://themeforest.net/user/akbilisim
Description:    Boost your views, share counts, like, reaction votes with Fake Counter.
Author:         akbilisim
Version:        2.0.0
Author URI:     http://akbilisim.com
Text Domain:    newsy-fake-counter
*/

defined( 'NEWSY_FAKE_COUNTER' ) or define( 'NEWSY_FAKE_COUNTER', 'newsy-fake-counter' );
defined( 'NEWSY_FAKE_COUNTER_URI' ) or define( 'NEWSY_FAKE_COUNTER_URI', plugins_url( NEWSY_FAKE_COUNTER ) );
defined( 'NEWSY_FAKE_COUNTER_PATH' ) or define( 'NEWSY_FAKE_COUNTER_PATH', plugin_dir_path( __FILE__ ) );

if ( ! function_exists( 'newsy_fake_counter_load' ) ) {
	function newsy_fake_counter_load() {
		require_once 'class.newsy-fake-counter.php';
		Newsy_Fake_Counter::get_instance();

		/**
		 * Load Text Domain
		 */
		load_plugin_textdomain( NEWSY_FAKE_COUNTER, false, basename( __DIR__ ) . '/languages/' );
	}
}

add_action( 'plugins_loaded', 'newsy_fake_counter_load' );
