<?php
$fields[] = array(
	'heading' => __( 'Override Settings', 'newsy-fake-counter' ),
	'id'      => 'settings',
	'type'    => 'section',
	'icon'    => 'fa-eye',
);
$fields[] = array(
	'id'          => 'enable_fake_counter',
	'type'        => 'switcher',
	'heading'     => esc_html__( 'Enable Override', 'newsy-fake-counter' ),
	'description' => esc_html__( 'Here you can override fake count options for this post.', 'newsy-fake-counter' ),
	'options'     => array(
		'off' => '',
		'on'  => 'on',
	),
	'section'     => 'settings',
);

$fields[] = array(
	'id'          => 'fake_post_view_base_count',
	'type'        => 'slider',
	'heading'     => __( 'Initial View Count', 'newsy-fake-counter' ),
	'description' => __( 'This value will increase your initial view counter. This value will affect social share, post voting, reaction voting values.', 'newsy-fake-counter' ),
	'input_desc'  => __( 'Leave empty for no fake count', 'newsy-fake-counter' ),
	'min'         => 0,
	'max'         => 9999,
	'step'        => 5,
	'unit'        => 'views',
	'section'     => 'settings',
	'dependency'  => array(
		'element' => 'enable_fake_counter',
		'value'   => array( 'on' ),
	),
);

$fields[] = array(
	'id'          => 'fake_post_share_view_percentage',
	'type'        => 'slider',
	'heading'     => __( 'Social Share Value base on View', 'newsy-fake-counter' ),
	'description' => __( 'We increase your social share value base on percentage of your view.', 'newsy-fake-counter' ),
	'input_desc'  => __( 'Leave empty for no fake count', 'newsy-fake-counter' ),
	'default'     => '0',
	'min'         => 0,
	'max'         => 100,
	'unit'        => '%',
	'section'     => 'settings',
	'dependency'  => array(
		'element' => 'enable_fake_counter',
		'value'   => array( 'on' ),
	),
);

$fields[] = array(
	'id'          => 'fake_post_reaction_view_percentage',
	'type'        => 'slider',
	'heading'     => __( 'Reaction Value base on View', 'newsy-fake-counter' ),
	'description' => __( 'We increase your reaction voting value base on percentage of your view.', 'newsy-fake-counter' ),
	'input_desc'  => __( 'Leave empty for no fake count', 'newsy-fake-counter' ),
	'default'     => '0',
	'min'         => 0,
	'max'         => 100,
	'unit'        => '%',
	'section'     => 'settings',
	'dependency'  => array(
		'element' => 'enable_fake_counter',
		'value'   => array( 'on' ),
	),
);

$fields[] = array(
	'id'          => 'fake_post_vote_up_view_percentage',
	'type'        => 'slider',
	'heading'     => __( 'Up/Like Voting Value base on View', 'newsy-fake-counter' ),
	'description' => __( 'We increase your post voting value base on percentage of post view.', 'newsy-fake-counter' ),
	'input_desc'  => __( 'Leave empty for no fake count', 'newsy-fake-counter' ),
	'default'     => '0',
	'min'         => 0,
	'max'         => 100,
	'unit'        => '%',
	'section'     => 'settings',
	'dependency'  => array(
		'element' => 'enable_fake_counter',
		'value'   => array( 'on' ),
	),
);

$fields[] = array(
	'id'          => 'fake_post_vote_down_view_percentage',
	'type'        => 'slider',
	'heading'     => __( 'Down/Dislike Voting Value base on View', 'newsy-fake-counter' ),
	'description' => __( 'We increase your post voting value base on percentage of post view.', 'newsy-fake-counter' ),
	'input_desc'  => __( 'Leave empty for no fake count', 'newsy-fake-counter' ),
	'default'     => '0',
	'min'         => 0,
	'max'         => 100,
	'unit'        => '%',
	'section'     => 'settings',
	'dependency'  => array(
		'element' => 'enable_fake_counter',
		'value'   => array( 'on' ),
	),
);
