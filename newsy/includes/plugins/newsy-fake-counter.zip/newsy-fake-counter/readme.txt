Change Log :

== 1.0.2 ==
- [NEW] Added option to edit fake counts per post

== 1.0.1 ==
- [IMPOVEMENT] Added all share providers

== 1.0.0 ==
- First Release
