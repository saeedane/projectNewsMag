<?php
/*
Plugin Name:    Newsy Voting
Plugin URI:     http://themeforest.net/user/akbilisim
Description:    Receiving feedback is crucial as a content creator. Get more feedback from your audience with Up/Down buttons.
Author:         akbilisim
Version:        2.0.0
Author URI:     http://akbilisim.com
Text Domain:    newsy-voting
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

defined( 'NEWSY_VOTING' ) or define( 'NEWSY_VOTING', 'newsy-voting' );
defined( 'NEWSY_VOTING_VERSION' ) or define( 'NEWSY_VOTING_VERSION', '2.0.0' );
defined( 'NEWSY_VOTING_URI' ) or define( 'NEWSY_VOTING_URI', plugins_url( NEWSY_VOTING ) );
defined( 'NEWSY_VOTING_PATH' ) or define( 'NEWSY_VOTING_PATH', plugin_dir_path( __FILE__ ) );

require_once 'class.newsy-voting.php';

if ( ! function_exists( 'newsy_voting_load' ) ) {
	function newsy_voting_load() {
		require_once 'class.newsy-voting-hooks.php';
		Newsy_Voting_Hooks::get_instance();

		/**
		 * Load Text Domain
		 */
		load_plugin_textdomain( 'newsy-voting', false, basename( __DIR__ ) . '/languages/' );
	}
}

add_action( 'plugins_loaded', 'newsy_voting_load' );

/**
 * Activation hook
 */
register_activation_hook( __FILE__, array( Newsy_Voting::get_instance(), 'activation_hook' ) );

if ( ! function_exists( 'newsy_get_voting_counts' ) ) {
	/**
	 * Helper function to get voting counts.
	 */
	function newsy_get_voting_counts( $post_id, $up_count = null, $down_count = null ) {
		return Newsy_Voting::get_instance()->get_average_count( $post_id, $up_count, $down_count );
	}
}
