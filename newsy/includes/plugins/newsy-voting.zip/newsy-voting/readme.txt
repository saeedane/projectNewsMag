Change Log :

== 1.0.5 ==
- [IMPROVEMENT] Theme compatibility

== 1.0.4 ==
- [IMPROVEMENT] Theme compatibility

== 1.0.3 ==
- [FIX] Issue on translations

== 1.0.2 ==
- [FIX] Issue on Guest Voting option

== 1.0.1 ==
- [IMPROVEMENT] Plugin translation

== 1.0.0 ==
- First Release
