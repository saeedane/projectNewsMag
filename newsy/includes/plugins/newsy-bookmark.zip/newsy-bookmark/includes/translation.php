<?php

/**
 * Block
 */
$fields[] = array(
	'heading' => 'Bookmarks',
	'id'      => 'bookmarks_group_start',
	'type'    => 'group_start',
	'section' => 'translation',
	'state'   => 'open',
);
$fields[] = array(
	'heading' => 'Bookmarks',
	'default' => 'Bookmarks',
	'id'      => 'bookmarks',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Add Bookmark',
	'default' => 'Add Bookmark',
	'id'      => 'add_bookmark',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Remove Bookmark',
	'default' => 'Remove Bookmark',
	'id'      => 'remove_bookmark',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Bookmark Added!',
	'default' => 'Bookmark Added!',
	'id'      => 'bookmark_added',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Bookmark Removed!',
	'default' => 'Bookmark Removed!',
	'id'      => 'bookmark_removed',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'You must login to add bookmark!',
	'default' => 'You must login to add bookmark!',
	'id'      => 'must_login_bookmark',
	'type'    => 'text',
	'section' => 'translation',
);
$fields[] = array(
	'heading' => 'Failed to send request!',
	'default' => 'Failed to send request!',
	'id'      => 'request_failed',
	'type'    => 'text',
	'section' => 'translation',
);
