<?php
/*
Plugin Name:    Newsy Bookmark
Plugin URI:     http://themeforest.net/user/akbilisim
Description:    Easily add bookmark/favorite or wishlist functionality for your posts.
Author:         akbilisim
Version:        2.0.0
Author URI:     http://akbilisim.com
Text Domain:    newsy-bookmark
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

defined( 'NEWSY_BOOKMARK' ) or define( 'NEWSY_BOOKMARK', 'newsy-bookmark' );
defined( 'NEWSY_BOOKMARK_VERSION' ) or define( 'NEWSY_BOOKMARK_VERSION', '2.0.0' );
defined( 'NEWSY_BOOKMARK_URI' ) or define( 'NEWSY_BOOKMARK_URI', plugins_url( NEWSY_BOOKMARK ) );
defined( 'NEWSY_BOOKMARK_PATH' ) or define( 'NEWSY_BOOKMARK_PATH', plugin_dir_path( __FILE__ ) );

if ( ! function_exists( 'newsy_bookmark_load' ) ) {
	function newsy_bookmark_load() {
		require_once 'class.newsy-bookmark-hooks.php';
		require_once 'class.newsy-bookmark-bp.php';
		Newsy_Bookmark_Hooks::get_instance();
		Newsy_Bookmark_Bp::get_instance();

		/**
		 * Load Text Domain
		 */
		load_plugin_textdomain( 'newsy-bookmark', false, basename( __DIR__ ) . '/languages/' );
	}
}

add_action( 'plugins_loaded', 'newsy_bookmark_load' );
