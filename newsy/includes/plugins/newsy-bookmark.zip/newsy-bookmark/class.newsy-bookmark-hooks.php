<?php
/**
 * @author akbilisim
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Newsy Bookmark Hooks
 */
class Newsy_Bookmark_Hooks {

	/**
	 * @var Newsy_Bookmark_Hooks
	 */
	private static $instance;

	/**
	 * @return Newsy_Bookmark_Hooks
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}
		return static::$instance;
	}

	/**
	 * Newsy_Bookmark_Hooks constructor.
	 */
	private function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ), 999 );
		add_action( 'ak-framework/frontend/ajax', array( $this, 'register_ajax_post_bookmark' ) );
		add_action( 'ak-framework/frontend/ajax', array( $this, 'register_ajax_user_bookmarks' ) );
		add_filter( 'ak-framework/register/translation', array( $this, 'register_translation_fields' ), 80 );

		add_filter( 'newsy_single_post_social_share_top', array( $this, 'add_bookmark_button' ), 20, 2 );
		add_filter( 'newsy_single_post_social_share_bottom', array( $this, 'add_bookmark_button' ), 20, 2 );
	}

	/**
	 * Load plugin assest
	 */
	public function register_assets() {
		wp_enqueue_script( NEWSY_BOOKMARK, NEWSY_BOOKMARK_URI . '/js/plugin.js', null, NEWSY_BOOKMARK_VERSION, true );
	}

	/**
	 * Main function for ajax
	 */
	public function register_ajax_post_bookmark( $action ) {
		if ( 'ajax_post_bookmark' === $action ) {
			try {
				if ( empty( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'newsy_nonce' ) || empty( $_POST['post_id'] ) ) {
					throw new \Exception( ak_get_translation( 'Failed to send request!', 'newsy-bookmark', 'request_failed' ) );
				}

				if ( ! is_user_logged_in() ) {
					wp_send_json(
						array(
							'response' => -1,
							'message'  => ak_get_translation( 'You must login to add bookmark!', 'newsy-bookmark', 'must_login_bookmark' ),
						)
					);
				}

				$user_id       = get_current_user_id();
				$user_bookmark = ak_get_user_meta( 'newsy_post_bookmark', $user_id );
				$user_bookmark = is_array( $user_bookmark ) ? $user_bookmark : array();
				$post_id       = sanitize_text_field( wp_unslash( $_POST['post_id'] ) );
				$action_type   = sanitize_text_field( wp_unslash( $_POST['type'] ) );

				switch ( $action_type ) {
					case 'add':
						$user_bookmark[ $post_id ] = 1;

						$status       = true;
						$message      = ak_get_translation( 'Bookmark Added!', 'newsy-bookmark', 'bookmark_added' );
						$button_title = ak_get_translation( 'Remove Bookmark', 'newsy-bookmark', 'remove_bookmark' );
						break;
					case 'remove':
						unset( $user_bookmark[ $post_id ] );
						$status       = false;
						$message      = ak_get_translation( 'Bookmark Removed!', 'newsy-bookmark', 'bookmark_removed' );
						$button_title = ak_get_translation( 'Add Bookmark', 'newsy-bookmark', 'add_bookmark' );
						break;
				}

				ak_update_user_meta( 'newsy_post_bookmark', $user_id, $user_bookmark );

				wp_send_json(
					array(
						'success'      => 1,
						'message'      => $message,
						'bookmark'     => $status,
						'button_title' => $button_title,
					)
				);
			} catch ( \Exception $e ) {
				wp_send_json(
					array(
						'success' => 0,
						'message' => $e->getMessage(),
					)
				);
			}
		}
	}

	/**
	 * Main function for ajax
	 */
	public function register_ajax_user_bookmarks( $action ) {
		if ( 'ajax_user_bookmarks' === $action ) {
			try {
				if ( empty( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'newsy_nonce' ) ) {
					throw new \Exception( ak_get_translation( 'Failed to send request!', 'newsy-bookmark', 'request_failed' ) );
				}

				if ( ! is_user_logged_in() ) {
					wp_send_json(
						array(
							'response' => -1,
							'message'  => ak_get_translation( 'You must login to add bookmark!', 'newsy-bookmark', 'must_login_bookmark' ),
						)
					);
				}

				$user_id       = get_current_user_id();
				$user_bookmark = ak_get_user_meta( 'newsy_post_bookmark', $user_id );
				$user_bookmark = is_array( $user_bookmark ) ? $user_bookmark : array();

				$block = ak_get_shortcode(
					'newsy_list_1_small_square'
				);

				$html = $block->render_shortcode(
					array(
						'count'               => 5,
						'post'                => array_reverse( array_keys( $user_bookmark ) ),
						'pagination'          => 'load_more',
						'custom_enabled'      => 'yes',
						'custom_parts'        => 'show_excerpt=hide&show_meta=hide',
						'block_width'         => 1,
						'title'               => ak_get_translation( 'Bookmarks', 'newsy-bookmark', 'bookmarks' ),
						'header_style'        => 'style-11',
						'block_extra_classes' => 'ak-block-module-seperator-line',
					), null
				);

				wp_send_json(
					array(
						'success' => 1,
						'message' => '',
						'html'    => $html,
						'total'   => count( $user_bookmark ),
					)
				);
			} catch ( \Exception $e ) {
				wp_send_json(
					array(
						'success' => 0,
						'message' => $e->getMessage(),
					)
				);
			}
		}
	}

	/**
	 * Register translations to framework.
	 *
	 * @return array
	 */
	public function register_translation_fields( $fields ) {
		$fields['newsy-bookmark'] = array(
			'name' => __( 'Newsy Bookmark', 'newsy-bookmark' ),
			'file' => NEWSY_BOOKMARK_PATH . 'includes/translation.php',
		);

		return $fields;
	}

	/**
	 * Load plugin assest
	 */
	public function add_bookmark_button( $output, $post_id ) {
		$user_bookmark = ak_get_user_meta( 'newsy_post_bookmark', get_current_user_id() );
		$user_bookmark = is_array( $user_bookmark ) ? $user_bookmark : array();
		$btn_class     = 'ak-bookmark-button';
		$class         = 'fa fa-bookmark-o';
		$button_title  = ak_get_translation( 'Add Bookmark', 'newsy-bookmark', 'add_bookmark' );

		if ( array_key_exists( $post_id, (array) $user_bookmark ) ) {
			$class        = 'fa fa-bookmark';
			$btn_class   .= ' added';
			$button_title = ak_get_translation( 'Remove Bookmark', 'newsy-bookmark', 'remove_bookmark' );
		}

		$output .= '<div class="ak-post-bookmark">
					<a href="#" data-post-id="' . $post_id . '" title="' . esc_attr( $button_title ) . '" class="' . esc_attr( $btn_class ) . '">
						<i class="ak-icon ' . $class . '"></i>
					</a>
				</div>';

		return $output;
	}
}
