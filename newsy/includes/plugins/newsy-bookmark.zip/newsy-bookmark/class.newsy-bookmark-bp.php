<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Newsy Bookmark BuddyPress
 */
class Newsy_Bookmark_Bp {
	private static $instance;

	/**
	 * @return BuzzEditor_Bp
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}

		return static::$instance;
	}

	private function __construct() {
		$this->setup_hook();
	}

	protected function setup_hook() {
		add_action( 'bp_setup_nav', array( $this, 'bp_add_nav' ), 25 );
	}

	/**
	 * Add playlist tab on nav BuddyPress
	 */
	public function bp_add_nav() {
		bp_core_new_nav_item(
			array(
				'name'                    => ak_get_translation( 'Bookmarks', 'newsy-bookmark', 'bookmarks' ),
				'slug'                    => 'bookmarks',
				'position'                => 35,
				'screen_function'         => array( $this, 'bookmarks_screen' ),
				'show_for_displayed_user' => false,
			)
		);
	}

	// show feedback when ‘Feedback’ tab is clicked
	public function bookmarks_screen() {
		add_action( 'bp_template_content', array( $this, 'bookmarks_page' ) );
		bp_core_load_template( apply_filters( 'bp_core_template_plugin', 'members/single/plugins' ) );
	}

	/**
	 * Set public playlist screen function
	 */
	public function bookmarks_page() {
		$user_bookmark = ak_get_user_meta( 'newsy_post_bookmark', get_current_user_id() );

		ak_do_shortcode(
			'newsy_list_1_medium', array(
				'count'               => 10,
				'post'                => array_reverse( array_keys( $user_bookmark ) ),
				'pagination'          => 'next_prev',
				'block_width'         => 2,
				'block_extra_classes' => 'ak-block-module-boxed',
			)
		);
	}
}
