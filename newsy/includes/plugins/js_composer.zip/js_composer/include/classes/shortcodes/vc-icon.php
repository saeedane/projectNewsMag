<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class WPBakeryShortCode_Vc_Icon
 * @since 4.4
 */
class WPBakeryShortCode_Vc_Icon extends WPBakeryShortCode {
}
