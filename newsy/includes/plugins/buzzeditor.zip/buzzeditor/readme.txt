Change Log :

== 1.7.2 ==
- [NEW] GIF block
- [FIX] Php warning in start page.
- [FIX] Minor Style issues

== 1.7.1 ==
- [FIX] Issue on Frontend editor color picker

== 1.7.0 ==
- [IMPROVEMENT] Minor style & code changes

== 1.6.3 ==
- [NEW] Added ability to redirect admin editor on block posts
- [FIX] Issue on Checklist quiz new answer adding

== 1.6.2 ==
- [FIX] Minor Style issues

== 1.6.1 ==
- [IMPROVEMENT] WordPress 5.9 compatibility
- [IMPROVEMENT] Added category selection for each post format
- [IMPROVEMENT] Added layout option for post formats page

== 1.6.0 ==
- [NEW] Added Review block.
- [NEW] Added Review post format.
- [FIX] Issue on custom post formats selection

== 1.5.0 ==
- [NEW] Classic Frontend Post Editor option
- [NEW] Create button with post format dropdown
- [NEW] Start page with post formats
- [NEW] Ability to create own post formats
- [IMPROVEMENT] Buzzeditor Block Settings
- [IMPROVEMENT] Added Frontend Editor Block translations to theme translation panel

== 1.0.5 ==
- [IMPROVEMENT] Plugin translation
- [IMPROVEMENT] RTL style
- [FIX] Issue on User permissions options

== 1.0.3 ==
- [IMPROVEMENT] Dark Mode

== 1.0.2 ==
- [IMPROVEMENT] Flush rewrite rules on endpoint change
- [FIX] Issue on AMP content filter

== 1.0.1 ==
- [FIX] Issue on poll guest voting

== 1.0.0 ==
- First Release
