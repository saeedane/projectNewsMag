<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BuzzEditor Editor
 *
 * @since 1.5.0
 */
class BuzzEditor_Editor {
	private static $instance;

	public $format_meta_key = 'buzzeditor_post_format';

	/**
	 * @return BuzzEditor_Editor
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
			static::$instance->setup_hook();
		}

		return static::$instance;
	}

	protected function setup_hook() {
		if ( ! function_exists( 'register_block_type' ) ) {
			return;
		}
		add_action( 'init', array( $this, 'register_meta' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'register_front_assets' ) );
		add_action( 'buzzeditor_frontend_enqueue_scripts', array( $this, 'register_editor_assets' ) );
		add_filter( 'buzzeditor_editor_settings', array( $this, 'editor_settings' ), 999, 2 );
	}

	public function register_meta() {
		register_post_meta(
			'post', $this->format_meta_key, array(
				'show_in_rest' => true,
				'single'       => true,
				'type'         => 'string',
			)
		);
	}

	/**
	 * Enqueue Gutenberg block assets for frontend.
	 */
	public function register_front_assets() {
		// Register block styles for both frontend + backend.
		wp_enqueue_style( 'buzzeditor-style', BUZZEDITOR_URL . '/css/style.css', array(), BUZZEDITOR_VERSION );
		wp_style_add_data( 'buzzeditor-style', 'rtl', 'replace' );
	}

	/**
	 * Enqueue Gutenberg block assets for backend.
	 */
	public function register_editor_assets() {
		wp_enqueue_style(
			'buzzeditor-editor', BUZZEDITOR_URL . '/css/editor-style.css', array(
				'dashicons',
				'common',
				'forms',
				'dashboard',
				'media',
				'admin-menu',
				'admin-bar',
				'nav-menus',
				'buttons',
			), BUZZEDITOR_VERSION
		);
		wp_style_add_data( 'buzzeditor-editor', 'rtl', 'replace' );

		wp_enqueue_script(
			'buzzeditor-frontend-editor-js', BUZZEDITOR_URL . '/js/frontend-editor.js', array(
				'selectize',
				'wp-blocks',
				'wp-element',
				'wp-components',
				'wp-editor',
				'wp-i18n',
			), BUZZEDITOR_VERSION, true
		);

		wp_localize_script(
			'buzzeditor-frontend-editor-js', 'buzzeditor_frontend_editor_loc', array(
				'redirect_to_post' => buzzeditor_get_option( 'enable_frontend_post_redirect' ) === 'yes',
			)
		);

		if ( buzzeditor_is_classic() ) {
			wp_enqueue_style( 'buzzeditor-editor-classic', BUZZEDITOR_URL . '/css/editor-classic-style.css', array( 'selectize', 'fontawesome' ), BUZZEDITOR_VERSION );
			wp_style_add_data( 'buzzeditor-editor-classic', 'rtl', 'replace' );

			wp_enqueue_script(
				'buzzeditor-classic-js', BUZZEDITOR_URL . '/js/classic-editor.js', array(
					'selectize',
					'wp-blocks',
					'wp-element',
					'wp-components',
					'wp-editor',
					'wp-i18n',
				), BUZZEDITOR_VERSION, true
			);

			wp_localize_script(
				'buzzeditor-classic-js', 'buzzeditor_classic_loc', array(
					'data' => $this->get_classic_editor_settings(),
					'lang' => array(
						'title_category'          => ak_get_translation( 'Title & Category', 'buzzeditor', 'editor_title_category' ),
						'categories'              => ak_get_translation( 'Categories', 'buzzeditor', 'editor_categories' ),
						'description'             => ak_get_translation( 'Description', 'buzzeditor', 'editor_description' ),
						'description_placeholder' => ak_get_translation( 'Enter a short description...', 'buzzeditor', 'editor_description_placeholder' ),
						'blocks'                  => ak_get_translation( 'Blocks', 'buzzeditor', 'editor_blocks' ),
						'add_new_block'           => ak_get_translation( 'Add New Block', 'buzzeditor', 'editor_add_new_block' ),
						'preview_image'           => ak_get_translation( 'Preview Image', 'buzzeditor', 'editor_preview_image' ),
						'tags'                    => ak_get_translation( 'Tags', 'buzzeditor', 'editor_tags' ),
						'publish_date'            => ak_get_translation( 'Publish Date', 'buzzeditor', 'editor_publish_date' ),
						'text_editor'             => ak_get_translation( 'Text Editor', 'buzzeditor', 'editor_text_editor' ),
					),
				)
			);
		}
	}

	/**
	* Classic Editor settings
	*
	* @todo clean this up
	*
	* @return array
	*/
	public function get_classic_editor_settings() {
		$post_types   = $this->get_post_formats();
		$current_type = filter_input( INPUT_GET, 'type', FILTER_SANITIZE_STRING );
		$post         = filter_input( INPUT_GET, 'post', FILTER_SANITIZE_NUMBER_INT );

		if ( $post ) {
			$post = get_post( absint( $post ) );
		}

		if ( empty( $current_type ) ) {
			$current_type = 'story';
		}

		$selected_categories = array();
		foreach ( $post_types as $key => $post_type ) {
			if ( empty( $post_type['icon'] ) ) {
				unset( $post_types[ $key ] );
				continue;
			}
			$post_types[ $key ]['icon']            = ak_get_icon( $post_type['icon'] );
			$post_types[ $key ]['selected']        = $post_type['type'] === $current_type;
			$post_types[ $key ]['accepted_blocks'] = ! empty( $post_type['accepted_blocks'] ) ? explode( ',', $post_type['accepted_blocks'] ) : null;
			$post_types[ $key ]['categories']      = ! empty( $post_type['categories'] ) ? explode( ',', $post_type['categories'] ) : null;
			$post_types[ $key ]['show_in_editor']  = ! $post && empty( $post_type['show_in_editor'] ) ? true : false;

			if ( $post_types[ $key ]['selected'] ) {
				$selected_categories = $post_types[ $key ]['categories'];
			}
		}

		$term_args = array(
			'taxonomy'   => 'category',
			'orderby'    => 'name',
			'order'      => 'asc',
			'hide_empty' => false,
			'per_page'   => 100,
			'_fields'    => 'id,name,parent',
		);

		if ( ! empty( $selected_categories ) ) {
			$term_args['include'] = $selected_categories;
		}

		$post_format = $post ? $this->get_post_format( $post->ID ) : null;

		return array(
			'post_types'      => $post_types,
			'current_type'    => ! empty( $post_format ) ? $post_format : $current_type,
			'format_meta_key' => $this->format_meta_key,
			'categories'      => get_terms( $term_args ),
		);
	}

	public function editor_settings( $settings, $post ) {
		$type = filter_input( INPUT_GET, 'type', FILTER_SANITIZE_STRING );

		if ( ! empty( $post )
		&& 'auto-draft' === $post->post_status
		&& 'post' === $post->post_type ) {
			if ( buzzeditor_is_classic() ) {
				$default_blocks = array( 'buzzeditor/text' );
				$post_types     = $this->get_post_formats();

				foreach ( $post_types as $post_type ) {
					if ( ! empty( $post_type['type'] ) && ! empty( $post_type['starter_blocks'] ) && $post_type['type'] === $type ) {
						$default_blocks = explode( ',', $post_type['starter_blocks'] );
						break;
					}
				}
			} else {
				switch ( $type ) {
					case 'audio':
						$default_blocks = array( 'core/audio' );
						break;
					case 'gallery':
						$default_blocks = array( 'core/gallery' );
						break;
					case 'image':
						$default_blocks = array( 'core/image' );
						break;
					case 'quote':
						$default_blocks = array( 'core/quote' );
						break;
					case 'video':
						$default_blocks = array( 'core/video' );
						break;
					case 'embed':
						$default_blocks = array( 'core/video' );
						break;
					case 'personality':
						$default_blocks = array( 'buzzeditor/personality' );
						break;
					case 'trivia':
						$default_blocks = array( 'buzzeditor/trivia' );
						break;
					case 'checklist':
						$default_blocks = array( 'buzzeditor/checklist' );
						break;
					case 'flipcard':
						$default_blocks = array( 'buzzeditor/flipcard' );
						break;
					case 'beforeafter':
						$default_blocks = array( 'buzzeditor/beforeafter' );
						break;
					case 'poll':
						$default_blocks = array( 'buzzeditor/poll' );
						break;
					case 'versus':
						$default_blocks = array( 'buzzeditor/versus' );
						break;
					case 'convo':
						$default_blocks = array( 'buzzeditor/convo' );
						break;
					case 'list':
						$default_blocks = array( 'buzzeditor/list' );
						break;
					case 'story':
						$default_blocks = array( 'buzzeditor/text' );
						break;
					default:
						$default_blocks = array( 'core/paragrapth' );
						break;
				}
			}

			$settings['template'] = array( $default_blocks );
		}

		return $settings;
	}

	public function get_default_post_types() {
		$post_types = array(
			array(
				'type'            => 'story',
				'name'            => 'Story',
				'desc'            => 'Create your own story with texts, images, and embeds',
				'icon'            => 'akfi-story',
				'starter_blocks'  => 'buzzeditor/text',
				'accepted_blocks' => 'buzzeditor/text,core/image,core/video,core/embed,buzzeditor/poll,buzzeditor/beforeafter,buzzeditor/convo,buzzeditor/list,buzzeditor/review,buzzeditor/flipcard,core/cover,buzzeditor/gif',
			),
			array(
				'type'           => 'list',
				'name'           => 'Viral List',
				'desc'           => 'Create your own viral list to share awesome stories.',
				'icon'           => 'akfi-virallist',
				'starter_blocks' => 'buzzeditor/list',
			),
			array(
				'type'            => 'personality',
				'name'            => 'Personality Quiz',
				'desc'            => 'Create "What do you know about ...?" type of quizzes.',
				'icon'            => 'akfi-personality',
				'starter_blocks'  => 'buzzeditor/personality',
				'accepted_blocks' => 'buzzeditor/personality',
				'show_in_editor'  => 'no',
			),
			array(
				'type'            => 'trivia',
				'name'            => 'Trivia Quiz',
				'desc'            => 'Create "What type of person are you?" type of quizzes.',
				'icon'            => 'akfi-trivia',
				'starter_blocks'  => 'buzzeditor/trivia',
				'accepted_blocks' => 'buzzeditor/trivia',
				'show_in_editor'  => 'no',
			),
			array(
				'type'             => 'checklist',
				'name'             => 'Checklist Quiz',
				'desc'             => 'Create "How much do you know about ...?" type of quizzes.',
				'icon'             => 'akfi-checklist',
				'starter_blocks'   => 'buzzeditor/checklist',
				'accepted_blocks'  => 'buzzeditor/checklist',
				'show_in_editor'   => 'no',
				'show_in_dropdown' => 'no',
			),
			array(
				'type'             => 'quiz',
				'name'             => 'Quiz',
				'desc'             => 'Create your own quiz with awesome blocks',
				'icon'             => 'akfi-personality',
				'starter_blocks'   => 'buzzeditor/personality',
				'accepted_blocks'  => 'buzzeditor/personality,buzzeditor/trivia,buzzeditor/checklist',
				'show_in_start'    => 'no',
				'show_in_dropdown' => 'no',
			),
			array(
				'type'            => 'poll',
				'name'            => 'Poll',
				'desc'            => 'Creating your own poll never been easy like this.',
				'icon'            => 'akfi-poll',
				'starter_blocks'  => 'buzzeditor/poll',
				'accepted_blocks' => 'buzzeditor/poll',
			),
			array(
				'type'            => 'convo',
				'name'            => 'Convo',
				'desc'            => "Create a dialogue that fits today's communication habits.",
				'icon'            => 'akfi-convo',
				'starter_blocks'  => 'buzzeditor/convo',
				'accepted_blocks' => 'buzzeditor/convo',
				'show_in_editor'  => 'no',
			),
			array(
				'type'             => 'flipcard',
				'name'             => 'FlipCard',
				'desc'             => "What's hiding on the other side? Click to reveal!",
				'icon'             => 'akfi-flipcard',
				'starter_blocks'   => 'buzzeditor/flipcard',
				'accepted_blocks'  => 'buzzeditor/flipcard,buzzeditor/text',
				'show_in_editor'   => 'no',
				'show_in_dropdown' => 'no',
			),
			array(
				'type'             => 'beforeafter',
				'name'             => 'BeforeAfter',
				'desc'             => "Create the perfect 'before and after' experience.",
				'icon'             => 'akfi-beforeafter',
				'starter_blocks'   => 'buzzeditor/beforeafter',
				'accepted_blocks'  => 'buzzeditor/beforeafter',
				'show_in_editor'   => 'no',
				'show_in_dropdown' => 'no',
			),
			array(
				'type'             => 'versus',
				'name'             => 'Versus',
				'desc'             => 'A poll that allows voting between two competing answers.',
				'icon'             => 'akfi-versus',
				'starter_blocks'   => 'buzzeditor/versus',
				'accepted_blocks'  => 'buzzeditor/versus',
				'show_in_editor'   => 'no',
				'show_in_dropdown' => 'no',
			),
			array(
				'type'             => 'review',
				'name'             => 'Review',
				'desc'             => 'Creating your own review never been easy like this.',
				'icon'             => 'akfi-review',
				'starter_blocks'   => 'buzzeditor/review',
				'accepted_blocks'  => 'buzzeditor/text,buzzeditor/review',
				'show_in_editor'   => 'no',
				'show_in_dropdown' => 'no',
			),
			array(
				'type'             => 'image',
				'name'             => 'Image',
				'desc'             => 'Upload an image file, or add one with a URL.',
				'icon'             => 'akfi-collections',
				'starter_blocks'   => 'core/image',
				'accepted_blocks'  => 'core/image',
				'show_in_editor'   => 'no',
				'show_in_dropdown' => 'no',
			),
			array(
				'type'             => 'video',
				'name'             => 'Video',
				'desc'             => 'Embed a video from your provider or upload a new one.',
				'icon'             => 'akfi-video_library',
				'starter_blocks'   => 'core/video',
				'accepted_blocks'  => 'core/video,core/embed,buzzeditor/text',
				'show_in_dropdown' => 'no',
			),
			array(
				'type'             => 'embed',
				'name'             => 'Embed',
				'desc'             => 'Embed a Facebook post, Intagram post, tiktok video, or a tweet.',
				'icon'             => 'akfi-collections_bookmark',
				'starter_blocks'   => 'core/embed',
				'accepted_blocks'  => 'core/embed,buzzeditor/text',
				'show_in_editor'   => 'no',
				'show_in_dropdown' => 'no',
			),
			array(
				'type'             => 'audio',
				'name'             => 'Audio',
				'desc'             => 'Embed a audio from your provider or upload a new one.',
				'icon'             => 'akfi-library_music',
				'starter_blocks'   => 'core/audio',
				'accepted_blocks'  => 'core/audio',
				'show_in_editor'   => 'no',
				'show_in_dropdown' => 'no',
			),
			array(
				'type'             => 'gallery',
				'name'             => 'Gallery',
				'desc'             => 'Display multiple images in a rich gallery.',
				'icon'             => 'akfi-perm_media',
				'starter_blocks'   => 'core/gallery',
				'accepted_blocks'  => 'core/image,core/gallery,core/paragraph',
				'show_in_editor'   => 'no',
				'show_in_dropdown' => 'no',
			),
			array(
				'type'             => 'file',
				'name'             => 'File',
				'desc'             => 'Add a link to a downloadable file.',
				'icon'             => 'akfi-picture_as_pdf',
				'starter_blocks'   => 'core/file',
				'accepted_blocks'  => 'core/file,core/text,core/video,core/paragraph',
				'show_in_start'    => 'no',
				'show_in_editor'   => 'no',
				'show_in_dropdown' => 'no',
			),
		);

		return apply_filters( 'buzzeditor_classic_default_post_types', $post_types );
	}

	public function get_post_format( $post_id ) {
		$post_format = get_post_meta( $post_id, $this->format_meta_key, true );

		return apply_filters( 'buzzeditor_get_post_format', $post_format );
	}

	public function get_post_formats() {
		$post_formats = buzzeditor_get_option( 'frontend_classic_types', $this->get_default_post_types() );

		return apply_filters( 'buzzeditor_classic_post_formats', $post_formats );
	}

	public function get_editor_post_formats() {
		$post_formats = array_filter(
			$this->get_post_formats(), function( $post_type ) {
				return empty( $post_type['show_in_editor'] );
			}
		);

		return apply_filters( 'buzzeditor_classic_editor_post_formats', $post_formats );
	}

	public function get_start_post_formats() {
		$post_formats = array_filter(
			$this->get_post_formats(), function( $post_type ) {
				return empty( $post_type['show_in_start'] );
			}
		);

		return apply_filters( 'buzzeditor_classic_start_post_formats', $post_formats );
	}

	public function get_dropdown_post_formats() {
		$post_formats = array_filter(
			$this->get_post_formats(), function( $post_format ) {
				return empty( $post_format['show_in_dropdown'] );
			}
		);

		return apply_filters( 'buzzeditor_classic_dropdown_post_formats', $post_formats );
	}

	public function get_dropdown_content() {
		if ( 'hide' === buzzeditor_get_option( 'show_dropdown' ) ) {
			return false;
		}
		$post_types          = $this->get_dropdown_post_formats();
		$buzzeditor_endpoint = home_url( '/' . buzzeditor_get_editor_endpoint() );

		$output = '';
		if ( $post_types ) {
			$output .= '<div class="buzzeditor-post-format-list">';
			foreach ( $post_types as $post_type ) {
				$type = ! empty( $post_type['type'] ) ? '?type=' . $post_type['type'] : '';

				$output .= '<a href="' . esc_url( $buzzeditor_endpoint . $type ) . '" class="buzzeditor-post-format-item ak_require_login_button">';
				if ( ! empty( $post_type['icon'] ) ) {
					$output .= ak_get_icon( $post_type['icon'] );
				}
				if ( ! empty( $post_type['name'] ) ) {
					$output .= '<h5 class="buzzeditor-post-format-name">' . esc_html( $post_type['name'] ) . '</h5>';
				}
				$output .= '</a>';
			}

			if ( 'hide' !== buzzeditor_get_option( 'show_dropdown_all_button' ) ) {
				$text = ak_get_translation( 'View All Formats', 'buzzeditor', 'view_all_formats' );

				$output .= '<a href="' . esc_url( $buzzeditor_endpoint ) . '" class="buzzeditor-post-format-more">' . esc_html( $text ) . ' <i class="ak-icon fa fa-angle-double-right"></i></a>';
			}
			$output .= '</div>';
		}

		return $output;
	}
}
