<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BuzzEditor Poll
 * Block Ajax Voting Hook
 */
class BuzzEditor_Poll {

	/**
	 * @var BuzzEditor_Poll
	 */
	private static $instance;

	/**
	 * @var string
	 */
	private $table_name = 'buzzeditor_poll_votes';

	/**
	 * @return BuzzEditor_Poll
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}
		return static::$instance;
	}

	/**
	 * Newsy_Like constructor.
	 */
	private function __construct() {
		$this->setup_hook();
	}

	/**
	 * Create table for post like count
	 */
	public function check_table() {
		global $wpdb;
		$table_name = $wpdb->prefix . $this->table_name;

		if ( $wpdb->get_var( "show tables like '$table_name'" ) !== $table_name ) {
			$sql = 'CREATE TABLE ' . $table_name . " (
                    `id` bigint(11) NOT NULL AUTO_INCREMENT,
                    `poll_id` varchar(255) NOT NULL,
                    `answer_id` varchar(255) NOT NULL,
                    `date_time` datetime NOT NULL,
                    `user_id` int(11) NOT NULL DEFAULT '0',
					`user_ip` varchar(100) NULL DEFAULT '',
                    PRIMARY KEY (`id`), INDEX (`poll_id`)
                )";

			require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
			dbDelta( $sql );
		}
	}

	/**
	 * Activation hook plugin
	 */
	public function activation_hook() {
		$this->check_table();
	}

	/**
	 * Setup hook function
	 */
	public function setup_hook() {
		add_action( 'ak-framework/frontend/ajax', array( $this, 'register_ajax' ) );
	}

	/**
	 * Get total like and dislike
	 *
	 * @param  integer $post_id
	 * @param  string  $type
	 *
	 * @return string  $result
	 *
	 */
	public function get_total_count( $poll_id ) {
		global $wpdb;
		$table_name = $wpdb->prefix . $this->table_name;

		$result = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(id) FROM $table_name WHERE poll_id = %s",
				$poll_id
			)
		);

		return $result;
	}

	/**
	 * Get total like and dislike
	 *
	 * @param  integer $post_id
	 * @param  string  $type
	 *
	 * @return string  $result
	 *
	 */
	public function get_answer_total_count( $poll_id, $answer_id ) {
		global $wpdb;
		$table_name = $wpdb->prefix . $this->table_name;

		$result = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(id) FROM $table_name WHERE poll_id = %s AND answer_id = %s",
				$poll_id,
				$answer_id
			)
		);

		return $result;
	}

	/**
	 * Get status if have liked or disliked
	 *
	 * @param  integer $post_id
	 *
	 * @return int  $status
	 *
	 */
	public function get_status( $poll_id, $author_id = 0 ) {

		if ( 0 === $author_id ) {
			$author_id = get_current_user_id();
		}

		// User not logged in, guest voting enabled.
		if ( 0 === $author_id ) {
			$vote_cookie = filter_input( INPUT_COOKIE, 'buzzeditor_poll_' . $poll_id, FILTER_SANITIZE_STRING );

			if ( $vote_cookie ) {
				return $vote_cookie;
			}
		}

		global $wpdb;
		$table_name = $wpdb->prefix . $this->table_name;

		if ( 0 === $author_id ) {
			$status = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT answer_id FROM $table_name WHERE user_ip = %s AND poll_id = %s",
					ak_get_ip_address(),
					$poll_id
				)
			);
		} else {
			$status = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT answer_id FROM $table_name WHERE user_id = %d AND poll_id = %s",
					$author_id,
					$poll_id
				)
			);
		}

		return $status;
	}

	/**
	 * Get total like and dislike
	 *
	 * @param  integer $post_id
	 * @param  string  $type
	 *
	 * @return string  $result
	 *
	 */
	public function get_poll_votes( $poll_id, $answers, $total ) {
		$votes = array();

		foreach ( $answers as $answer_id ) {

			$count = $this->get_answer_total_count( $poll_id, $answer_id );

			if ( $count > 0 ) {
				$percentage = round( ( $count / $total ) * 100 );

				$votes[ $answer_id ] = array(
					'number'  => sprintf( ak_get_translation( '%s Votes', 'buzzeditor', 'number_votes' ), apply_filters( 'newsy_number_format', $count ) ),
					'percent' => $percentage,
				);
			} else {
				$votes[ $answer_id ] = array(
					'number'  => 0,
					'percent' => 0,
				);
			}
		}

		return $votes;
	}

	/**
	 * Insert data into database
	 *
	 * @param  integer $post_id
	 * @param  string  $value
	 *
	 * @return bool
	 *
	 */
	public function send_success( $voted, $poll_id, $answers ) {
		$total = $this->get_total_count( $poll_id );

		wp_send_json(
			array(
				'success' => 1,
				'message' => ak_get_translation( 'Thanks for your vote!', 'buzzeditor', 'thanks_for_vote' ),
				'voted'   => $voted,
				'votes'   => $this->get_poll_votes( $poll_id, $answers, $total ),
				'total'   => sprintf( ak_get_translation( 'Total: %s Votes', 'buzzeditor', 'total_number_votes' ), apply_filters( 'newsy_number_format', $total ) ),
			)
		);
	}

	/**
	 * Main function
	 *
	 * @param  integer $post_id
	 * @param  string  $type
	 *
	 * @return json
	 *
	 */
	public function do_action_type( $poll_id, $answer_id, $answers ) {
		$status = $this->get_status( $poll_id );

		if ( null === $status ) {
			$result = $this->insert_value( $poll_id, $answer_id );

			if ( $result ) {

				$this->send_success( $answer_id, $poll_id, $answers );

			} else {
				wp_send_json(
					array(
						'success' => 0,
						'message' => ak_get_translation( 'Failed to send request!', 'buzzeditor', 'failed_request' ),
					)
				);
			}
		} else {

			wp_send_json(
				array(
					'success' => 0,
					'message' => ak_get_translation( 'You already voted on this poll!', 'buzzeditor', 'must_login_poll_vote' ),
				)
			);

		}
	}

	/**
	 * Main function for ajax
	 */
	public function register_ajax( $action ) {
		if ( 'be_vote_poll' === $action ) {
			$guest = filter_input( INPUT_POST, 'guest_voting', FILTER_SANITIZE_STRING );

			if ( is_user_logged_in() || 'yes' === $guest ) {
				$poll_id   = filter_input( INPUT_POST, 'poll_id', FILTER_SANITIZE_STRING );
				$answer_id = filter_input( INPUT_POST, 'answer_id', FILTER_SANITIZE_STRING );
				$answers   = filter_var_array( $_POST['answers'], FILTER_SANITIZE_STRING );

				$this->do_action_type( $poll_id, $answer_id, $answers );
			} else {
				wp_send_json(
					array(
						'success'    => 1,
						'status'     => 'login',
						'show_login' => 1,
						'message'    => ak_get_translation( 'You must login to vote!', 'buzzeditor', 'login_to_vote' ),
					)
				);
			}

			die();
		}

		if ( 'be_get_poll_votes' === $action ) {
			$guest = filter_input( INPUT_POST, 'guest_voting', FILTER_SANITIZE_STRING );

			if ( is_user_logged_in() || 'yes' === $guest ) {
				$poll_id   = filter_input( INPUT_POST, 'poll_id', FILTER_SANITIZE_STRING );
				$answer_id = filter_input( INPUT_POST, 'answer_id', FILTER_SANITIZE_STRING );
				$answers   = filter_var_array( $_POST['answers'], FILTER_SANITIZE_STRING );

				$status = $this->get_status( $poll_id );

				if ( null !== $status ) {
					$this->send_success( $status, $poll_id, $answers );
				} else {
					wp_send_json(
						array(
							'success' => 0,
							'status'  => 'can_vote',
							'message' => '',
						)
					);
				}
			} else {
				wp_send_json(
					array(
						'success'    => 0,
						'status'     => 'login',
						'show_login' => 0,
						'message'    => ak_get_translation( 'You must login to vote!', 'buzzeditor', 'login_to_vote' ),
					)
				);
			}

			die();
		}
	}

	/**
	 * Insert data into database
	 *
	 * @param  integer $post_id
	 * @param  string  $value
	 *
	 * @return bool
	 *
	 */
	public function insert_value( $poll_id, $answer_id ) {
		global $wpdb;
		$table_name = $wpdb->prefix . $this->table_name;

		$user_id = get_current_user_id();
		$user_ip = ak_get_ip_address();

		$result = $wpdb->insert(
			$table_name,
			array(
				'poll_id'   => $poll_id,
				'answer_id' => $answer_id,
				'user_id'   => $user_id,
				'user_ip'   => $user_ip ? $user_ip : '',
				'date_time' => date( 'Y-m-d H:i:s' ),
			),
			array(
				'%s',
				'%s',
				'%d',
				'%s',
				'%s',
			)
		);

		return $result;
	}
}
