<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BuzzEditor Video
 */
class BuzzEditor_Video {
	private static $instance;

	/**
	 * @return BuzzEditor_Video
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}

		return static::$instance;
	}

	private function __construct() {
		if ( function_exists( 'register_block_type' ) ) {
			$this->setup_hook();
		}
	}

	private function setup_hook() {
		add_action( 'wp_after_insert_post', array( $this, 'parse_video_block' ), 100, 2 );
	}

	public function parse_video_block( $post_id, $post ) {
		$post_format = BuzzEditor_Editor::get_instance()->get_post_format( $post_id );

		if ( 'video' === $post_format ) {
			$blocks = parse_blocks( $post->post_content );

			$media_url      = '';
			$media_provider = '';
			foreach ( $blocks as $block ) {
				if ( 'core/embed' === $block['blockName'] ) {
					$media_url      = isset( $block['attrs']['url'] ) ? $block['attrs']['url'] : '';
					$media_provider = isset( $block['attrs']['providerNameSlug'] ) ? $block['attrs']['providerNameSlug'] : '';

					break;
				}
				if ( 'core/video' === $block['blockName'] ) {
					$media_url      = isset( $block['attrs']['id'] ) ? wp_get_attachment_url( $block['attrs']['id'] ) : '';
					$media_provider = 'upload';

					break;
				}
			}

			if ( ! empty( $media_url ) && in_array( $media_provider, array( 'upload', 'youtube', 'vimeo', 'dailymotion' ), true ) ) {
				if ( empty( get_post_meta( $post_id, 'ak_featured_video', true ) ) ) {
					if ( 'upload' === $media_provider ) {
						$mime           = substr( $media_url, -3 );
						$featured_video = array(
							'type' => 'upload',
							$mime  => $media_url,
						);
					} else {
						$featured_video = array(
							'type' => 'url',
							'url'  => $media_url,
						);
					}

					update_post_meta( $post_id, 'ak_featured_video', $featured_video );
					set_post_format( $post_id, 'video' );
					update_post_meta( $post_id, 'ak_post_show_featured_image', 'hide' );
				}
			}
		} else {
			$blocks = parse_blocks( $post->post_content );

			foreach ( $blocks as $block ) {
				if ( 'core/embed' === $block['blockName'] || 'core/video' === $block['blockName'] ) {
					if ( empty( get_post_meta( $post_id, 'ak_featured_video', true ) ) ) {
						update_post_meta( $post_id, 'ak_featured_video', array( 'type' => 'auto' ) );
					}
					break;
				}
			}
		}
	}
}
