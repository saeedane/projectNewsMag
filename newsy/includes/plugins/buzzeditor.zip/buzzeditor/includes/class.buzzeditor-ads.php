<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BuzzEditor Ads
 *
 * @since 2.0.0
 */
class BuzzEditor_Ads {
	private static $instance;

	private $question_count = 1;

	private $listitem_count = 1;

	/**
	 * @return BuzzEditor_Ads
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
			static::$instance->setup_hook();
		}

		return static::$instance;
	}

	protected function setup_hook() {
		add_filter( 'render_block_buzzeditor/personality', array( $this, 'reset_question_count' ), 10, 2 );
		add_filter( 'render_block_buzzeditor/trivia', array( $this, 'reset_question_count' ), 10, 2 );
		add_filter( 'render_block_buzzeditor/list', array( $this, 'reset_list_count' ), 10, 2 );
		add_filter( 'render_block_buzzeditor/personality-question', array( $this, 'add_question_ad_place' ), 10, 2 );
		add_filter( 'render_block_buzzeditor/trivia-question', array( $this, 'add_question_ad_place' ), 10, 2 );
		add_filter( 'render_block_buzzeditor/list-item', array( $this, 'add_virallist_ad_place' ), 10, 2 );
	}

	public function reset_question_count( $content, $block ) {
		$this->question_count = 1;
		return $content;
	}

	public function reset_list_count( $content, $block ) {
		$this->listitem_count = 1;
		return $content;
	}

	public function add_question_ad_place( $content, $block ) {
		if ( function_exists( 'amp_is_request' ) && amp_is_request() ) {
			return $content;
		}

		if ( is_single() ) {
			$ads = buzzeditor_get_option( 'quiz_ads' );

			if ( ! empty( $ads ) && is_array( $ads ) ) {

				foreach ( $ads as  $ad ) {
					if ( empty( $ad['type'] ) || empty( $ad['ad_position'] ) ) {
						continue;
					}

					$ad_position = absint( $ad['ad_position'] );

					if ( $ad_position !== $this->question_count ) {
						continue;
					}

					$ad_align = ! empty( $ad['ad_align'] ) ? $ad['ad_align'] : 'center';

					$ad_instance = ak_get_shortcode( 'newsy_ad' );

					$ad_code = $ad_instance->render_shortcode(
						array_merge(
							$ad,
							array(
								'block_width' => 'center' === $ad_align ? 2 : 1,
								'classes'     => 'ak-ad-article ad-position-' . $ad_position . ' align' . $ad_align,
							)
						), null
					);

					$content .= $ad_code;
				}
			}
		}

		$this->question_count++;

		return $content;
	}

	public function add_virallist_ad_place( $content, $block ) {
		if ( function_exists( 'amp_is_request' ) && amp_is_request() ) {
			return $content;
		}

		if ( is_single() ) {
			$ads = buzzeditor_get_option( 'virallist_ads' );

			if ( ! empty( $ads ) && is_array( $ads ) ) {

				foreach ( $ads as  $ad ) {
					if ( empty( $ad['type'] ) || empty( $ad['ad_position'] ) ) {
						continue;
					}

					$ad_position = absint( $ad['ad_position'] );

					if ( $ad_position !== $this->listitem_count ) {
						continue;
					}

					$ad_align = ! empty( $ad['ad_align'] ) ? $ad['ad_align'] : 'center';

					$ad_instance = ak_get_shortcode( 'newsy_ad' );

					$ad_code = $ad_instance->render_shortcode(
						array_merge(
							$ad,
							array(
								'block_width' => 'center' === $ad_align ? 2 : 1,
								'classes'     => 'ak-ad-article ad-position-' . $ad_position . ' align' . $ad_align,
							)
						), null
					);

					$content .= $ad_code;
				}
			}
		}

		$this->listitem_count++;

		return $content;
	}
}
