<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BuzzEditor Review
 */
class BuzzEditor_Review {
	private static $instance;

	/**
	 * @return BuzzEditor_Review
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}

		return static::$instance;
	}

	private function __construct() {
		if ( function_exists( 'register_block_type' ) ) {
			$this->setup_hook();
		}
	}

	private function setup_hook() {
		add_action( 'save_post', array( $this, 'parse_review_block' ), 10, 2 );
	}

	public function parse_review_block( $post_id, $post ) {
		$blocks = parse_blocks( $post->post_content );
		if ( count( $blocks ) > 0 ) {
			$review = array();
			foreach ( $blocks as $block ) {
				if ( 'buzzeditor/review' === $block['blockName'] ) {
					$review = array(
						'score'    => isset( $block['attrs']['overallScore'] ) ? $block['attrs']['overallScore'] : 0,
						'template' => isset( $block['attrs']['template'] ) ? $block['attrs']['template'] : 'percentage',
					);

					break;
				}
			}

			if ( ! empty( $review ) ) {
				update_post_meta( $post_id, 'buzzeditor_review_score', $review['score'] );
				update_post_meta( $post_id, 'buzzeditor_review_template', $review['template'] );
			} else {
				delete_post_meta( $post_id, 'buzzeditor_review_score' );
				delete_post_meta( $post_id, 'buzzeditor_review_template' );
			}
		}
	}
}
