<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BuzzEditor Endpoint
 */
class BuzzEditor_Endpoint {
	private static $instance;

	/**
	 * @return BuzzEditor_Endpoint
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}

		return static::$instance;
	}

	private function __construct() {
		if ( $this->is_frontend_active() ) {
			$this->setup_hook();
		}
	}

	public function setup_hook() {
		add_action( 'init', array( $this, 'add_rewrite_rule' ) );
		add_action( 'admin_bar_menu', array( $this, 'add_toolbar_link' ), 999 );

		add_filter( 'post_row_actions', array( $this, 'add_action_link' ), 10, 2 );
		add_filter( 'newsy_module_edit_btn_link', array( $this, 'module_edit_btn_link' ), 9, 2 );
		add_action( 'ak-framework/option-panel/save/after', array( $this, 'option_save_hook' ), 999 );
	}

	public function option_save_hook( $option_id ) {
		if ( BUZZEDITOR_OPTIONS === $option_id ) {
			$this->activation_hook();
		}
	}

	public function activation_hook() {
		$this->add_rewrite_rule();
		$this->flush_rewrite_rules();
	}

	public function add_rewrite_rule() {
		$endpoint = trim( buzzeditor_get_editor_endpoint(), '/' );
		add_rewrite_endpoint( $endpoint, EP_ROOT | EP_PAGES );
		add_rewrite_rule( '^' . $endpoint . '/?([0-9]{1,})/?$', 'index.php?&page=$matches[1]&' . $endpoint, 'top' );
	}

	public function flush_rewrite_rules() {
		global $wp_rewrite;
		$wp_rewrite->flush_rules();
	}

	public function is_frontend_active() {
		return buzzeditor_get_option( 'enable_frontend' ) !== 'no';
	}

	public function get_edit_url() {
		$endpoint = buzzeditor_get_editor_endpoint();
		return home_url( '/' . $endpoint );
	}

	public function get_edit_post_url( $post_id ) {
		return esc_url( add_query_arg( 'action', 'edit', add_query_arg( 'post', $post_id, $this->get_edit_url() ) ) );
	}

	public function add_toolbar_link( $wp_admin_bar ) {
		if ( ! is_admin() && is_singular( 'post' ) && is_user_logged_in() || is_admin() && get_post_type() === 'post' ) {
			$url = $this->get_edit_post_url( get_the_ID() );

			$args = array(
				'id'    => 'be-edit-post',
				'title' => ak_get_translation( 'Edit with BuzzEditor', 'buzzeditor', 'edit_with_buzzeditor' ),
				'href'  => $url,
				'meta'  => array(
					'title' => ak_get_translation( 'Edit with BuzzEditor', 'buzzeditor', 'edit_with_buzzeditor' ),
				),
			);

			$wp_admin_bar->add_node( $args );
		}
	}

	public function add_action_link( $actions, $id ) {
		global $post;

		$post_type_object = get_post_type_object( $post->post_type );

		if ( 'post' !== $post_type_object->name ) {
			return $actions;
		}
		if ( ! current_user_can( $post_type_object->cap->edit_post, $post->ID ) ) {
			return $actions;
		}

		$url                   = $this->get_edit_post_url( $post->ID );
		$text                  = ak_get_translation( 'Edit with BuzzEditor ', 'buzzeditor', 'edit_with_buzzeditor' );
		$actions['buzzeditor'] = '<a href="' . $url . '" title="' . esc_attr( $text ) . '" target="_blank">' . esc_html( $text ) . '</a>';
		return $actions;
	}

	public function module_edit_btn_link( $url, $post_id ) {
		if ( ! $this->is_frontend_active() || buzzeditor_get_option( 'enable_frontend_post_edit_button' ) === 'no' ) {
			return $url;
		}
		return $this->get_edit_post_url( $post_id );
	}
}
