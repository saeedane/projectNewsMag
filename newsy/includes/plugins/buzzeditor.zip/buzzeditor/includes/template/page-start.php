<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

defined( 'BUZZEDITOR_FRONTEND_PAGE' ) or define( 'BUZZEDITOR_FRONTEND_PAGE', true );

// template
$template_id = 'start_page';

$classes = apply_filters(
	'newsy_content_wrap_class', array(
		'ak-' . $template_id . '-wrap',
		'ak-layout-' . buzzeditor_get_option( 'start_page_layout_style', 'full-width' ),
	), $template_id, null
);

get_header();
?>
<div class="ak-content-wrap <?php echo esc_attr( implode( ' ', $classes ) ); ?>">
	<div class="ak-container">
		<div class="ak-content">
		<div class="buzzeditor-start-wrapper">
			<div class="buzzeditor-start-header">
				<div class="container">
					<h2 class="buzzeditor-start-header-title"><?php ak_echo_translation( 'Frontend Post Submission', 'buzzeditor', 'start_page_heading' ); ?></h2>
					<p class="buzzeditor-start-header-desc"><?php ak_echo_translation( 'We\'ve got you covered for all the best post formats from Story to Viral List, Quiz to Poll, and Image Gallery to Video Embed. Choose a post format to start creating your awesome post.', 'buzzeditor', 'start_page_description' ); ?></p>
				</div>
			</div>
			<div class="container">
					<div class="buzzeditor-start-format-list">
					<?php
					$buzzeditor_endpoint = buzzeditor_get_editor_endpoint();
					$post_types          = BuzzEditor_Editor::get_instance()->get_start_post_formats();

					$output = '';
					foreach ( $post_types as $post_type ) {
						$type = ! empty( $post_type['type'] ) ? '?type=' . $post_type['type'] : '';

						$output .= '<div class="buzzeditor-post-format-list-item">';
						$output .= '<a href="' . esc_url( home_url( $buzzeditor_endpoint . $type ) ) . '" class="ak_require_login_button">';
						if ( ! empty( $post_type['icon'] ) ) {
							$output .= '<div class="buzzeditor-post-format-icon">' . ak_get_icon( $post_type['icon'] ) . '</div>';
						}
						if ( ! empty( $post_type['name'] ) ) {
							$output .= '<h4 class="buzzeditor-post-format-name">' . esc_html( $post_type['name'] ) . '</h4>';
						}
						if ( ! empty( $post_type['desc'] ) ) {
							$output .= '<p class="buzzeditor-post-format-desc">' . esc_html( $post_type['desc'] ) . '</p>';
						}
						$output .= '</a>';
						$output .= '</div>';
					}

					echo $output;
					?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php get_footer(); ?>
