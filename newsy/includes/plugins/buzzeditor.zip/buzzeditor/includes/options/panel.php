<?php
function buzzeditor_get_block_names() {
	if ( ! class_exists( 'WP_Block_Type_Registry' ) ) {
		return array();
	}
	$block_registry = WP_Block_Type_Registry::get_instance();

	$blocks = array();
	foreach ( $block_registry->get_all_registered() as $block_name => $block_type ) {
		if ( ! isset( $blocks[ $block_name ] ) ) {
			$blocks[ $block_name ] = ! empty( $block_type->title ) ? $block_type->title : $block_name;
		}
	}

	return array_reverse( $blocks );
}

/**
 * General Settings Tab
 */
$fields[] = array(
	'id'      => 'general',
	'type'    => 'section',
	'heading' => esc_html__( 'Frontend Editor', 'buzzeditor' ),
);

if ( ! BuzzEditor_Template::get_instance()->is_gutenberg_active() ) {
	$fields[] = array(
		'id'          => 'gutenberg_warning',
		'type'        => 'info',
		'info_type'   => 'warning',
		'heading'     => esc_html__( 'Gutenberg editor is disabled!', 'buzzeditor' ),
		'description' => wp_kses( __( 'Frontend post editor requires WordPress Block Editor to be enabled. Check your list of plugins to see if there is a plugin called “Classic Editor” or “Disable Gutenberg”. If there is, disable the plugin.', 'buzzeditor' ), ak_trans_allowed_html() ),
		'section'     => 'general',
	);
}

$fields[] = array(
	'id'          => 'enable_frontend',
	'type'        => 'switcher',
	'heading'     => esc_html__( 'Enable Frontend Editor', 'buzzeditor' ),
	'description' => esc_html__( 'Here you can enabled/disable frontend editor. BuzzEditor blocks will always available for backend.', 'buzzeditor' ),
	'options'     => array(
		'off' => 'no',
		'on'  => '',
	),
	'section'     => 'general',
);

$fields[] = array(
	'id'          => 'frontend_style',
	'type'        => 'visual_select',
	'heading'     => esc_html__( 'Frontend Editor Style', 'buzzeditor' ),
	'description' => esc_html__( 'Here you can choose frontend editor style. Advanced: More options and complex design. Classic: Less options and simple design.', 'buzzeditor' ),
	'options'     => array(
		'classic'  => __( 'Classic', 'buzzeditor' ),
		'advanced' => __( 'Advanced', 'buzzeditor' ),
	),
	'default'     => 'classic',
	'section'     => 'general',
);

$fields[] = array(
	'id'                 => 'frontend_classic_types',
	'type'               => 'repeater',
	'heading'            => esc_html__( 'Frontend Editor Post Formats', 'buzzeditor' ),
	'repeat_heading'     => esc_html__( 'Post Format', 'buzzeditor' ),
	'repeat_title_field' => 'name',
	'description'        => esc_html__( 'Here you can choose classic frontend editor post formats. Each type has starter blocks and accepted blocks and you can enable for editor, start page and dropdown.', 'buzzeditor' ),
	'fields'             => array(
		array(
			'id'      => 'type',
			'type'    => 'text',
			'heading' => esc_html__( 'Type', 'buzzeditor' ),
		),
		array(
			'id'      => 'name',
			'type'    => 'text',
			'heading' => esc_html__( 'Name', 'buzzeditor' ),
		),
		array(
			'id'      => 'desc',
			'type'    => 'text',
			'heading' => esc_html__( 'Description', 'buzzeditor' ),
		),
		array(
			'id'      => 'icon',
			'type'    => 'icon_select',
			'heading' => esc_html__( 'Icon', 'buzzeditor' ),
		),
		array(
			'id'          => 'starter_blocks',
			'type'        => 'select',
			'multiple'    => 50,
			'options'     => buzzeditor_get_block_names(),
			'heading'     => esc_html__( 'Starter Blocks', 'buzzeditor' ),
			'description' => esc_html__( 'Select default blocks for this format.', 'buzzeditor' ),
		),
		array(
			'id'          => 'accepted_blocks',
			'type'        => 'select',
			'multiple'    => 50,
			'options'     => buzzeditor_get_block_names(),
			'heading'     => esc_html__( 'Accepted Blocks', 'buzzeditor' ),
			'description' => esc_html__( 'Select accepted blocks for this format. Leave emtpy for no new blocks', 'buzzeditor' ),
		),
		array(
			'id'            => 'categories',
			'type'          => 'ajax_select',
			'heading'       => esc_html__( 'Categories', 'buzzeditor' ),
			'description'   => esc_html__( 'Select specific categories for this format. Leave emtpy for all categories', 'buzzeditor' ),
			'multiple'      => 100,
			'ajax_callback' => 'Ak\Form\FormCallback::get_categories',
			'return_string' => true,
		),
		array(
			'id'      => 'show_in_start',
			'type'    => 'switcher',
			'heading' => esc_html__( 'Show in Start Page', 'buzzeditor' ),
			'options' => array(
				'off' => 'no',
				'on'  => '',
			),
		),
		array(
			'id'      => 'show_in_dropdown',
			'type'    => 'switcher',
			'heading' => esc_html__( 'Show in Dropdown', 'buzzeditor' ),
			'options' => array(
				'off' => 'no',
				'on'  => '',
			),
		),
		array(
			'id'      => 'show_in_editor',
			'type'    => 'switcher',
			'heading' => esc_html__( 'Show in Editor Top Navigation', 'buzzeditor' ),
			'options' => array(
				'off' => 'no',
				'on'  => '',
			),
		),
	),
	'default'            => BuzzEditor_Editor::get_instance()->get_default_post_types(),
	'filter_default'     => false,
	'defaults_on_empty'  => true,
	'section'            => 'general',
);

$fields[] = array(
	'id'      => 'show_dropdown',
	'type'    => 'switcher',
	'heading' => esc_html__( 'Show Create Dropdown', 'buzzeditor' ),
	'section' => 'general',
	'options' => array(
		'off' => 'hide',
		'on'  => '',
	),
);

$fields[] = array(
	'id'         => 'show_dropdown_all_button',
	'type'       => 'switcher',
	'heading'    => esc_html__( 'Show Create Button All Formats Button', 'buzzeditor' ),
	'section'    => 'general',
	'options'    => array(
		'off' => 'hide',
		'on'  => '',
	),
	'dependency' => array(
		'element' => 'show_dropdown',
		'value'   => array( '' ),
	),
);

$fields[] = array(
	'id'          => 'create_page_layout_style',
	'heading'     => esc_html__( 'Frontend Editor Layout Style', 'buzzeditor' ),
	'description' => esc_html__( 'Select whether you want a boxed or a full width layout.', 'buzzeditor' ),
	'type'        => 'visual_select',
	'options'     => array(
		'full-width'    => esc_html__( 'Full Width', 'buzzeditor' ),
		'boxed'         => esc_html__( 'Full Boxed', 'buzzeditor' ),
		'content-boxed' => esc_html__( 'Boxed Content', 'buzzeditor' ),
	),
	'default'     => 'content-boxed',
	'section'     => 'general',
);
$fields[] = array(
	'id'          => 'start_page_layout_style',
	'heading'     => esc_html__( 'Editor Start Page Layout Style', 'buzzeditor' ),
	'description' => esc_html__( 'Select whether you want a boxed or a full width layout.', 'buzzeditor' ),
	'type'        => 'visual_select',
	'options'     => array(
		'full-width'    => esc_html__( 'Full Width', 'buzzeditor' ),
		'boxed'         => esc_html__( 'Full Boxed', 'buzzeditor' ),
		'content-boxed' => esc_html__( 'Boxed Content', 'buzzeditor' ),
	),
	'default'     => 'full-width',
	'section'     => 'general',
);

$fields[] = array(
	'id'      => 'user',
	'type'    => 'section',
	'heading' => esc_html__( 'User Permissions', 'buzzeditor' ),
);

$fields[] = array(
	'id'               => 'accepted_user_roles',
	'type'             => 'visual_checkbox',
	'heading'          => esc_html__( 'Enable  Frontend Editor for User Roles', 'buzzeditor' ),
	'description'      => esc_html__( 'Choose Frontend editor access by user roles. You may want to allow access only for Editor user role.', 'buzzeditor' ),
	'default'          => 'administrator,editor,author,contributor,subscriber',
	'options_callback' => 'Ak\Form\FormCallback::get_roles',
	'section'          => 'user',
);

$fields[] = array(
	'id'          => 'user_info',
	'type'        => 'info',
	'heading'     => esc_html__( 'Tip', 'buzzeditor' ),
	'description' => esc_html__( 'Please select non-admin users capabilities.', 'buzzeditor' ),
	'info_type'   => 'tip',
	'section'     => 'user',
);

$fields[] = array(
	'id'      => 'user_can_edit_posts',
	'type'    => 'switcher',
	'heading' => esc_html__( 'User can add and edit draft/pending posts', 'buzzeditor' ),
	'options' => array(
		'off' => 'no',
		'on'  => 'yes',
	),
	'default' => 'yes',
	'section' => 'user',
);

$fields[] = array(
	'id'      => 'user_can_delete_posts',
	'type'    => 'switcher',
	'heading' => esc_html__( 'User can delete draft/pending posts', 'buzzeditor' ),
	'options' => array(
		'off' => 'no',
		'on'  => 'yes',
	),
	'default' => 'yes',
	'section' => 'user',
);

$fields[] = array(
	'id'      => 'user_can_publish_posts',
	'type'    => 'switcher',
	'heading' => esc_html__( 'User can publish posts', 'buzzeditor' ),
	'default' => 'no',
	'options' => array(
		'off' => 'no',
		'on'  => 'yes',
	),
	'section' => 'user',
);

$fields[] = array(
	'id'      => 'user_can_edit_published_posts',
	'type'    => 'switcher',
	'heading' => esc_html__( 'User can edit published posts', 'buzzeditor' ),
	'default' => 'no',
	'options' => array(
		'off' => 'no',
		'on'  => 'yes',
	),
	'section' => 'user',
);

$fields[] = array(
	'id'      => 'user_can_delete_published_posts',
	'type'    => 'switcher',
	'heading' => esc_html__( 'User can delete published posts', 'buzzeditor' ),
	'default' => 'no',
	'options' => array(
		'off' => 'no',
		'on'  => 'yes',
	),
	'section' => 'user',
);

$fields[] = array(
	'id'          => 'user_always_edit_draft_post',
	'type'        => 'switcher',
	'heading'     => esc_html__( 'User can always add latest draft post', 'buzzeditor' ),
	'description' => esc_html__( 'Force users to edit latest draft post when adding post if there is any draft post. If disabled, user starts with new blank post.', 'buzzeditor' ),
	'options'     => array(
		'off' => 'no',
		'on'  => '',
	),
	'section'     => 'user',
);

$fields[] = array(
	'id'          => 'user_max_upload_file_size',
	'type'        => 'number',
	'heading'     => esc_html__( 'User Max Upload File Size', 'buzzeditor' ),
	'description' => esc_html__( 'Default is 5 MB.', 'buzzeditor' ),
	'default'     => 5,
	'section'     => 'user',
);


$fields[] = array(
	'id'      => 'blocks',
	'type'    => 'section',
	'heading' => esc_html__( 'User Blocks', 'buzzeditor' ),
);


$fields[] = array(
	'id'          => 'user_enabled_blocks',
	'type'        => 'visual_checkbox',
	'heading'     => esc_html__( 'Enable User Blocks', 'buzzeditor' ),
	'description' => esc_html__( 'Here you can select frontend blocks. User will be able to add only selected blocks. Do not select any to allow all blocks. Core blocks may depends on another core block, please make sure that you have selected both. Ex: core/column block works with core/columns block.', 'buzzeditor' ),
	'options'     => buzzeditor_get_block_names(),
	'section'     => 'blocks',
);

$fields[] = array(
	'id'      => 'ads',
	'type'    => 'section',
	'heading' => esc_html__( 'Ads', 'buzzeditor' ),
);

if ( function_exists( 'newsy_get_ad_fields' ) ) {
	$fields[] = array(
		'heading' => esc_html__( 'Quizzes', 'buzzeditor' ),
		'id'      => 'quiz_ad_heading',
		'type'    => 'group_start',
		'section' => 'ads',
	);

	$fields[] = array(
		'id'                 => 'quiz_ads',
		'heading'            => 'Question Place',
		'type'               => 'repeater',
		'container_class'    => 'ak-mix-fields-full control-heading-hide',
		'repeat_title_field' => 'ad_position',
		'fields'             => array_merge(
			array(
				array(
					'id'          => 'ad_position',
					'heading'     => esc_html__( 'Ad Position', 'buzzeditor' ),
					'description' => esc_html__( 'Here you can choose the position of the question.', 'buzzeditor' ),
					'input_desc'  => esc_html__( 'Show this ad after # question.', 'buzzeditor' ),
					'type'        => 'slider',
					'default'     => 2,
					'min'         => 1,
					'max'         => 100,
				),
				array(
					'id'          => 'ad_align',
					'heading'     => esc_html__( 'Ad Align', 'buzzeditor' ),
					'description' => esc_html__( 'Here you can choose the alignment of the ad within the post content.', 'buzzeditor' ),
					'type'        => 'radio_button',
					'default'     => 'center',
					'options'     => array(
						'left'   => esc_html__( 'Left', 'buzzeditor' ),
						'center' => esc_html__( 'Center', 'buzzeditor' ),
						'right'  => esc_html__( 'Right', 'buzzeditor' ),
					),
				),
			),
			newsy_get_ad_fields()
		),
		'section'            => 'ads',
	);

	$fields[] = array(
		'heading' => esc_html__( 'Viral List', 'buzzeditor' ),
		'id'      => 'virallist_ad_heading',
		'type'    => 'group_start',
		'section' => 'ads',
	);

	$fields[] = array(
		'id'                 => 'virallist_ads',
		'heading'            => 'Viral List Item Place',
		'type'               => 'repeater',
		'container_class'    => 'ak-mix-fields-full control-heading-hide',
		'repeat_title_field' => 'ad_position',
		'fields'             => array_merge(
			array(
				array(
					'id'          => 'ad_position',
					'heading'     => esc_html__( 'Ad Position', 'buzzeditor' ),
					'description' => esc_html__( 'Here you can choose the position of the viral list item.', 'buzzeditor' ),
					'input_desc'  => esc_html__( 'Show this ad after # viral list item.', 'buzzeditor' ),
					'type'        => 'slider',
					'default'     => 2,
					'min'         => 1,
					'max'         => 100,
				),
				array(
					'id'          => 'ad_align',
					'heading'     => esc_html__( 'Ad Align', 'buzzeditor' ),
					'description' => esc_html__( 'Here you can choose the alignment of the ad within the post content.', 'buzzeditor' ),
					'type'        => 'radio_button',
					'default'     => 'center',
					'options'     => array(
						'left'   => esc_html__( 'Left', 'buzzeditor' ),
						'center' => esc_html__( 'Center', 'buzzeditor' ),
						'right'  => esc_html__( 'Right', 'buzzeditor' ),
					),
				),
			),
			newsy_get_ad_fields()
		),
		'section'            => 'ads',
	);
}


$fields[] = array(
	'id'      => 'advanced',
	'type'    => 'section',
	'heading' => esc_html__( 'Advanced', 'buzzeditor' ),
);

$fields[] = array(
	'id'          => 'editor_url_slug',
	'type'        => 'text',
	'heading'     => esc_html__( 'Frontend Endpoint', 'buzzeditor' ),
	'description' => esc_html__( 'Choose Frontend editor access endpoint. You may want to change url for editor page with this option. Default is "editor"', 'buzzeditor' ),
	'default'     => 'editor',
	'section'     => 'advanced',
);

$fields[] = array(
	'id'          => 'editor_autosave_interval',
	'type'        => 'number',
	'heading'     => esc_html__( 'Editor Autosave Interval', 'buzzeditor' ),
	'description' => esc_html__( 'Default is 60 seconds.', 'buzzeditor' ),
	'default'     => AUTOSAVE_INTERVAL,
	'section'     => 'advanced',
);

$fields[] = array(
	'id'          => 'enable_frontend_post_edit_button',
	'type'        => 'switcher',
	'heading'     => esc_html__( 'Redirect to Frontend Editor on Post Edit Button', 'buzzeditor' ),
	'description' => esc_html__( 'If disabled, the post edit button on posts will open the admin post editor.', 'buzzeditor' ),
	'options'     => array(
		'off' => 'no',
		'on'  => '',
	),
	'section'     => 'advanced',
);
$fields[] = array(
	'id'          => 'enable_frontend_post_redirect',
	'type'        => 'switcher',
	'heading'     => esc_html__( 'Redirect to Published Post', 'buzzeditor' ),
	'description' => esc_html__( 'If enabled, the user will be redirected to the post page after the post is published in the front-end editor.', 'buzzeditor' ),
	'options'     => array(
		'off' => '',
		'on'  => 'yes',
	),
	'section'     => 'advanced',
);


$fields[] = array(
	'id'          => 'hide_admin_bar',
	'type'        => 'switcher',
	'heading'     => esc_html__( 'Remove Admin Bar For Non-Admins', 'buzzeditor' ),
	'description' => esc_html__( 'Force hide admin bar for users.', 'buzzeditor' ),
	'options'     => array(
		'off' => 'hide',
		'on'  => 'show',
	),
	'default'     => 'show',
	'section'     => 'advanced',
);
