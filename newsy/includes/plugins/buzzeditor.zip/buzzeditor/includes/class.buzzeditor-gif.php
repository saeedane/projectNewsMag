<?php

use Ak\Importer\ImporterMedia;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class BuzzEditor gif
 */
class BuzzEditor_Gif {
	private static $instance;

	/**
	 * @return BuzzEditor_Gif
	 */
	public static function get_instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}

		return static::$instance;
	}

	private function __construct() {
		if ( function_exists( 'register_block_type' ) ) {
			$this->setup_hook();
		}
	}

	private function setup_hook() {
		add_action( 'wp_after_insert_post', array( $this, 'parse_gif_block' ), 100, 2 );
	}

	public function parse_gif_block( $post_id, $post ) {
		$post_format = BuzzEditor_Editor::get_instance()->get_post_format( $post_id );

		if ( has_post_thumbnail( $post_id ) || 'gif' !== $post_format ) {
			return;
		}

		$blocks = parse_blocks( $post->post_content );
		if ( count( $blocks ) > 0 ) {
			$media_url = '';
			foreach ( $blocks as $block ) {
				if ( 'buzzeditor/gif' === $block['blockName'] ) {
					$media_url = isset( $block['attrs']['url'] ) ? $block['attrs']['url'] : '';
					break;
				}
			}

			if ( ! empty( $media_url ) ) {
				$maybe_attachment_id = ImporterMedia::create(
					array(
						'the_ID' => $post_id,
						'file'   => $media_url,
						'resize' => false,
					)
				);

				if ( ! is_wp_error( $maybe_attachment_id ) ) {
					set_post_thumbnail( $post_id, $maybe_attachment_id );
					update_post_meta( $post_id, 'ak_post_show_featured_image', 'hide' );
				}
			}
		}
	}
}
